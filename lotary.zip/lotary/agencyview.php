<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agency_view = new agency_view();

// Run the page
$agency_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agency_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$agency_view->isExport()) { ?>
<script>
var fagencyview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fagencyview = currentForm = new ew.Form("fagencyview", "view");
	loadjs.done("fagencyview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$agency_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $agency_view->ExportOptions->render("body") ?>
<?php $agency_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $agency_view->showPageHeader(); ?>
<?php
$agency_view->showMessage();
?>
<?php if (!$agency_view->IsModal) { ?>
<?php if (!$agency_view->isExport()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $agency_view->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<?php } ?>
<form name="fagencyview" id="fagencyview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agency">
<input type="hidden" name="modal" value="<?php echo (int)$agency_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($agency_view->slno->Visible) { // slno ?>
	<tr id="r_slno">
		<td class="<?php echo $agency_view->TableLeftColumnClass ?>"><span id="elh_agency_slno"><?php echo $agency_view->slno->caption() ?></span></td>
		<td data-name="slno" <?php echo $agency_view->slno->cellAttributes() ?>>
<span id="el_agency_slno">
<span<?php echo $agency_view->slno->viewAttributes() ?>><?php echo $agency_view->slno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_view->agency_name->Visible) { // agency_name ?>
	<tr id="r_agency_name">
		<td class="<?php echo $agency_view->TableLeftColumnClass ?>"><span id="elh_agency_agency_name"><?php echo $agency_view->agency_name->caption() ?></span></td>
		<td data-name="agency_name" <?php echo $agency_view->agency_name->cellAttributes() ?>>
<span id="el_agency_agency_name">
<span<?php echo $agency_view->agency_name->viewAttributes() ?>><?php echo $agency_view->agency_name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_view->agency_number->Visible) { // agency_number ?>
	<tr id="r_agency_number">
		<td class="<?php echo $agency_view->TableLeftColumnClass ?>"><span id="elh_agency_agency_number"><?php echo $agency_view->agency_number->caption() ?></span></td>
		<td data-name="agency_number" <?php echo $agency_view->agency_number->cellAttributes() ?>>
<span id="el_agency_agency_number">
<span<?php echo $agency_view->agency_number->viewAttributes() ?>><?php echo $agency_view->agency_number->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$agency_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$agency_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$agency_view->terminate();
?>