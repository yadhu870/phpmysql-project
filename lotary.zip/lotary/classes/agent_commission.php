<?php namespace PHPMaker2020\project5; ?>
<?php

/**
 * Table class for agent_commission
 */
class agent_commission extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $slno;
	public $date;
	public $time;
	public $dc_number;
	public $customer_name;
	public $ticket_name;
	public $draw_date;
	public $ticket_catagory;
	public $dc_type;
	public $serial_number;
	public $priced_serial_and_amount;
	public $commission_amount;
	public $agency_dc;
	public $total_dc;
	public $add_user;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'agent_commission';
		$this->TableName = 'agent_commission';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`agent_commission`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = ""; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// slno
		$this->slno = new DbField('agent_commission', 'agent_commission', 'x_slno', 'slno', '`slno`', '`slno`', 3, 10, -1, FALSE, '`slno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->slno->IsAutoIncrement = TRUE; // Autoincrement field
		$this->slno->IsPrimaryKey = TRUE; // Primary key field
		$this->slno->Sortable = TRUE; // Allow sort
		$this->slno->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['slno'] = &$this->slno;

		// date
		$this->date = new DbField('agent_commission', 'agent_commission', 'x_date', 'date', '`date`', CastDateFieldForLike("`date`", 7, "DB"), 133, 10, 7, FALSE, '`date`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->date->Sortable = TRUE; // Allow sort
		$this->date->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_SEPARATOR"], $Language->phrase("IncorrectDateDMY"));
		$this->fields['date'] = &$this->date;

		// time
		$this->time = new DbField('agent_commission', 'agent_commission', 'x_time', 'time', '`time`', CastDateFieldForLike("`time`", 4, "DB"), 134, 10, 4, FALSE, '`time`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->time->Nullable = FALSE; // NOT NULL field
		$this->time->Sortable = TRUE; // Allow sort
		$this->time->DefaultErrorMessage = str_replace("%s", $GLOBALS["TIME_SEPARATOR"], $Language->phrase("IncorrectTime"));
		$this->fields['time'] = &$this->time;

		// dc_number
		$this->dc_number = new DbField('agent_commission', 'agent_commission', 'x_dc_number', 'dc_number', '`dc_number`', '`dc_number`', 3, 20, -1, FALSE, '`dc_number`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->dc_number->Nullable = FALSE; // NOT NULL field
		$this->dc_number->Required = TRUE; // Required field
		$this->dc_number->Sortable = TRUE; // Allow sort
		$this->dc_number->Lookup = new Lookup('dc_number', 'saled_book', FALSE, 'slno', ["slno","","",""], [], ["x_serial_number"], [], [], ["customer_name","ticket_name","draw_date","ticket_catagory","serial_no","dc-type"], ["x_customer_name","x_ticket_name","x_draw_date","x_ticket_catagory","x_serial_number","x_dc_type"], '`slno` DESC', '');
		$this->dc_number->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['dc_number'] = &$this->dc_number;

		// customer_name
		$this->customer_name = new DbField('agent_commission', 'agent_commission', 'x_customer_name', 'customer_name', '`customer_name`', '`customer_name`', 200, 20, -1, FALSE, '`customer_name`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->customer_name->Nullable = FALSE; // NOT NULL field
		$this->customer_name->Required = TRUE; // Required field
		$this->customer_name->Sortable = TRUE; // Allow sort
		$this->customer_name->Lookup = new Lookup('customer_name', 'customer', FALSE, 'customer_name', ["customer_name","","",""], [], ["x_draw_date"], [], [], [], [], '`customer_name` ASC', '');
		$this->fields['customer_name'] = &$this->customer_name;

		// ticket_name
		$this->ticket_name = new DbField('agent_commission', 'agent_commission', 'x_ticket_name', 'ticket_name', '`ticket_name`', '`ticket_name`', 200, 20, -1, FALSE, '`ticket_name`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ticket_name->Nullable = FALSE; // NOT NULL field
		$this->ticket_name->Required = TRUE; // Required field
		$this->ticket_name->Sortable = TRUE; // Allow sort
		$this->ticket_name->Lookup = new Lookup('ticket_name', 'serial_details', FALSE, 'ticket_name', ["ticket_name","","",""], [], ["x_ticket_catagory"], [], [], [], [], '', '');
		$this->fields['ticket_name'] = &$this->ticket_name;

		// draw_date
		$this->draw_date = new DbField('agent_commission', 'agent_commission', 'x_draw_date', 'draw_date', '`draw_date`', '`draw_date`', 200, 20, 7, FALSE, '`draw_date`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->draw_date->Sortable = TRUE; // Allow sort
		$this->draw_date->Lookup = new Lookup('draw_date', 'saled_book', FALSE, 'draw_date', ["draw_date","","",""], ["x_customer_name"], ["x_ticket_catagory"], ["customer_name"], ["x_customer_name"], [], [], '`draw_date` DESC', '');
		$this->fields['draw_date'] = &$this->draw_date;

		// ticket_catagory
		$this->ticket_catagory = new DbField('agent_commission', 'agent_commission', 'x_ticket_catagory', 'ticket_catagory', '`ticket_catagory`', '`ticket_catagory`', 200, 11, -1, FALSE, '`ticket_catagory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ticket_catagory->Nullable = FALSE; // NOT NULL field
		$this->ticket_catagory->Required = TRUE; // Required field
		$this->ticket_catagory->Sortable = TRUE; // Allow sort
		$this->ticket_catagory->Lookup = new Lookup('ticket_catagory', 'saled_book', FALSE, 'ticket_catagory', ["ticket_catagory","","",""], ["x_ticket_name","x_draw_date"], [], ["ticket_name","draw_date"], ["x_ticket_name","x_draw_date"], ["slno","customer_name","serial_no"], ["x_dc_number","x_customer_name","x_serial_number"], '', '');
		$this->fields['ticket_catagory'] = &$this->ticket_catagory;

		// dc_type
		$this->dc_type = new DbField('agent_commission', 'agent_commission', 'x_dc_type', 'dc_type', '`dc_type`', '`dc_type`', 200, 20, -1, FALSE, '`dc_type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->dc_type->Nullable = FALSE; // NOT NULL field
		$this->dc_type->Required = TRUE; // Required field
		$this->dc_type->Sortable = TRUE; // Allow sort
		$this->fields['dc_type'] = &$this->dc_type;

		// serial_number
		$this->serial_number = new DbField('agent_commission', 'agent_commission', 'x_serial_number', 'serial_number', '`serial_number`', '`serial_number`', 201, 300, -1, FALSE, '`serial_number`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->serial_number->Nullable = FALSE; // NOT NULL field
		$this->serial_number->Required = TRUE; // Required field
		$this->serial_number->Sortable = TRUE; // Allow sort
		$this->fields['serial_number'] = &$this->serial_number;

		// priced_serial_and_amount
		$this->priced_serial_and_amount = new DbField('agent_commission', 'agent_commission', 'x_priced_serial_and_amount', 'priced_serial_and_amount', '`priced_serial_and_amount`', '`priced_serial_and_amount`', 201, 300, -1, FALSE, '`priced_serial_and_amount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->priced_serial_and_amount->Nullable = FALSE; // NOT NULL field
		$this->priced_serial_and_amount->Required = TRUE; // Required field
		$this->priced_serial_and_amount->Sortable = TRUE; // Allow sort
		$this->fields['priced_serial_and_amount'] = &$this->priced_serial_and_amount;

		// commission_amount
		$this->commission_amount = new DbField('agent_commission', 'agent_commission', 'x_commission_amount', 'commission_amount', '`commission_amount`', '`commission_amount`', 3, 10, -1, FALSE, '`commission_amount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->commission_amount->Nullable = FALSE; // NOT NULL field
		$this->commission_amount->Required = TRUE; // Required field
		$this->commission_amount->Sortable = TRUE; // Allow sort
		$this->commission_amount->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['commission_amount'] = &$this->commission_amount;

		// agency_dc
		$this->agency_dc = new DbField('agent_commission', 'agent_commission', 'x_agency_dc', 'agency_dc', '`agency_dc`', '`agency_dc`', 3, 20, -1, FALSE, '`agency_dc`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->agency_dc->Nullable = FALSE; // NOT NULL field
		$this->agency_dc->Required = TRUE; // Required field
		$this->agency_dc->Sortable = TRUE; // Allow sort
		$this->agency_dc->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['agency_dc'] = &$this->agency_dc;

		// total_dc
		$this->total_dc = new DbField('agent_commission', 'agent_commission', 'x_total_dc', 'total_dc', '`total_dc`', '`total_dc`', 3, 20, -1, FALSE, '`total_dc`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->total_dc->Nullable = FALSE; // NOT NULL field
		$this->total_dc->Required = TRUE; // Required field
		$this->total_dc->Sortable = TRUE; // Allow sort
		$this->total_dc->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['total_dc'] = &$this->total_dc;

		// add_user
		$this->add_user = new DbField('agent_commission', 'agent_commission', 'x_add_user', 'add_user', '`add_user`', '`add_user`', 200, 20, -1, FALSE, '`add_user`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->add_user->Nullable = FALSE; // NOT NULL field
		$this->add_user->Sortable = TRUE; // Allow sort
		$this->fields['add_user'] = &$this->add_user;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`agent_commission`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "`slno` DESC";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter)
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = Config("USER_ID_ALLOW");
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " ($names) VALUES ($values)";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->slno->setDbValue($conn->insert_ID());
			$rs['slno'] = $this->slno->DbValue;
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('slno', $rs))
				AddFilter($where, QuotedName('slno', $this->Dbid) . '=' . QuotedValue($rs['slno'], $this->slno->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->slno->DbValue = $row['slno'];
		$this->date->DbValue = $row['date'];
		$this->time->DbValue = $row['time'];
		$this->dc_number->DbValue = $row['dc_number'];
		$this->customer_name->DbValue = $row['customer_name'];
		$this->ticket_name->DbValue = $row['ticket_name'];
		$this->draw_date->DbValue = $row['draw_date'];
		$this->ticket_catagory->DbValue = $row['ticket_catagory'];
		$this->dc_type->DbValue = $row['dc_type'];
		$this->serial_number->DbValue = $row['serial_number'];
		$this->priced_serial_and_amount->DbValue = $row['priced_serial_and_amount'];
		$this->commission_amount->DbValue = $row['commission_amount'];
		$this->agency_dc->DbValue = $row['agency_dc'];
		$this->total_dc->DbValue = $row['total_dc'];
		$this->add_user->DbValue = $row['add_user'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`slno` = @slno@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('slno', $row) ? $row['slno'] : NULL;
		else
			$val = $this->slno->OldValue !== NULL ? $this->slno->OldValue : $this->slno->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@slno@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "agent_commissionlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "agent_commissionview.php")
			return $Language->phrase("View");
		elseif ($pageName == "agent_commissionedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "agent_commissionadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "agent_commissionlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("agent_commissionview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("agent_commissionview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "agent_commissionadd.php?" . $this->getUrlParm($parm);
		else
			$url = "agent_commissionadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("agent_commissionedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("agent_commissionadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("agent_commissiondelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "slno:" . JsonEncode($this->slno->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->slno->CurrentValue != NULL) {
			$url .= "slno=" . urlencode($this->slno->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("slno") !== NULL)
				$arKeys[] = Param("slno");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->slno->CurrentValue = $key;
			else
				$this->slno->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->slno->setDbValue($rs->fields('slno'));
		$this->date->setDbValue($rs->fields('date'));
		$this->time->setDbValue($rs->fields('time'));
		$this->dc_number->setDbValue($rs->fields('dc_number'));
		$this->customer_name->setDbValue($rs->fields('customer_name'));
		$this->ticket_name->setDbValue($rs->fields('ticket_name'));
		$this->draw_date->setDbValue($rs->fields('draw_date'));
		$this->ticket_catagory->setDbValue($rs->fields('ticket_catagory'));
		$this->dc_type->setDbValue($rs->fields('dc_type'));
		$this->serial_number->setDbValue($rs->fields('serial_number'));
		$this->priced_serial_and_amount->setDbValue($rs->fields('priced_serial_and_amount'));
		$this->commission_amount->setDbValue($rs->fields('commission_amount'));
		$this->agency_dc->setDbValue($rs->fields('agency_dc'));
		$this->total_dc->setDbValue($rs->fields('total_dc'));
		$this->add_user->setDbValue($rs->fields('add_user'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// slno
		// date
		// time
		// dc_number
		// customer_name
		// ticket_name
		// draw_date
		// ticket_catagory
		// dc_type
		// serial_number
		// priced_serial_and_amount
		// commission_amount
		// agency_dc
		// total_dc
		// add_user
		// slno

		$this->slno->ViewValue = $this->slno->CurrentValue;
		$this->slno->ViewCustomAttributes = "";

		// date
		$this->date->ViewValue = $this->date->CurrentValue;
		$this->date->ViewValue = FormatDateTime($this->date->ViewValue, 7);
		$this->date->ViewCustomAttributes = "";

		// time
		$this->time->ViewValue = $this->time->CurrentValue;
		$this->time->ViewValue = FormatDateTime($this->time->ViewValue, 4);
		$this->time->ViewCustomAttributes = "";

		// dc_number
		$this->dc_number->ViewValue = $this->dc_number->CurrentValue;
		$curVal = strval($this->dc_number->CurrentValue);
		if ($curVal != "") {
			$this->dc_number->ViewValue = $this->dc_number->lookupCacheOption($curVal);
			if ($this->dc_number->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`slno`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
				$sqlWrk = $this->dc_number->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->dc_number->ViewValue = $this->dc_number->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->dc_number->ViewValue = $this->dc_number->CurrentValue;
				}
			}
		} else {
			$this->dc_number->ViewValue = NULL;
		}
		$this->dc_number->ViewCustomAttributes = "";

		// customer_name
		$this->customer_name->ViewValue = $this->customer_name->CurrentValue;
		$curVal = strval($this->customer_name->CurrentValue);
		if ($curVal != "") {
			$this->customer_name->ViewValue = $this->customer_name->lookupCacheOption($curVal);
			if ($this->customer_name->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`customer_name`" . SearchString("=", $curVal, DATATYPE_STRING, "");
				$sqlWrk = $this->customer_name->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->customer_name->ViewValue = $this->customer_name->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->customer_name->ViewValue = $this->customer_name->CurrentValue;
				}
			}
		} else {
			$this->customer_name->ViewValue = NULL;
		}
		$this->customer_name->ViewCustomAttributes = "";

		// ticket_name
		$this->ticket_name->ViewValue = $this->ticket_name->CurrentValue;
		$curVal = strval($this->ticket_name->CurrentValue);
		if ($curVal != "") {
			$this->ticket_name->ViewValue = $this->ticket_name->lookupCacheOption($curVal);
			if ($this->ticket_name->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`ticket_name`" . SearchString("=", $curVal, DATATYPE_STRING, "");
				$sqlWrk = $this->ticket_name->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->ticket_name->ViewValue = $this->ticket_name->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->ticket_name->ViewValue = $this->ticket_name->CurrentValue;
				}
			}
		} else {
			$this->ticket_name->ViewValue = NULL;
		}
		$this->ticket_name->ViewCustomAttributes = "";

		// draw_date
		$this->draw_date->ViewValue = $this->draw_date->CurrentValue;
		$curVal = strval($this->draw_date->CurrentValue);
		if ($curVal != "") {
			$this->draw_date->ViewValue = $this->draw_date->lookupCacheOption($curVal);
			if ($this->draw_date->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`draw_date`" . SearchString("=", $curVal, DATATYPE_STRING, "");
				$sqlWrk = $this->draw_date->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->draw_date->ViewValue = $this->draw_date->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->draw_date->ViewValue = $this->draw_date->CurrentValue;
				}
			}
		} else {
			$this->draw_date->ViewValue = NULL;
		}
		$this->draw_date->ViewCustomAttributes = "";

		// ticket_catagory
		$this->ticket_catagory->ViewValue = $this->ticket_catagory->CurrentValue;
		$curVal = strval($this->ticket_catagory->CurrentValue);
		if ($curVal != "") {
			$this->ticket_catagory->ViewValue = $this->ticket_catagory->lookupCacheOption($curVal);
			if ($this->ticket_catagory->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`ticket_catagory`" . SearchString("=", $curVal, DATATYPE_STRING, "");
				$sqlWrk = $this->ticket_catagory->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->ticket_catagory->ViewValue = $this->ticket_catagory->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->ticket_catagory->ViewValue = $this->ticket_catagory->CurrentValue;
				}
			}
		} else {
			$this->ticket_catagory->ViewValue = NULL;
		}
		$this->ticket_catagory->ViewCustomAttributes = "";

		// dc_type
		$this->dc_type->ViewValue = $this->dc_type->CurrentValue;
		$this->dc_type->ViewCustomAttributes = "";

		// serial_number
		$this->serial_number->ViewValue = $this->serial_number->CurrentValue;
		$this->serial_number->ViewCustomAttributes = "";

		// priced_serial_and_amount
		$this->priced_serial_and_amount->ViewValue = $this->priced_serial_and_amount->CurrentValue;
		$this->priced_serial_and_amount->ViewCustomAttributes = "";

		// commission_amount
		$this->commission_amount->ViewValue = $this->commission_amount->CurrentValue;
		$this->commission_amount->ViewValue = FormatNumber($this->commission_amount->ViewValue, 0, -2, -2, -2);
		$this->commission_amount->ViewCustomAttributes = "";

		// agency_dc
		$this->agency_dc->ViewValue = $this->agency_dc->CurrentValue;
		$this->agency_dc->ViewValue = FormatNumber($this->agency_dc->ViewValue, 0, -2, -2, -2);
		$this->agency_dc->ViewCustomAttributes = "";

		// total_dc
		$this->total_dc->ViewValue = $this->total_dc->CurrentValue;
		$this->total_dc->ViewValue = FormatNumber($this->total_dc->ViewValue, 0, -2, -2, -2);
		$this->total_dc->ViewCustomAttributes = "";

		// add_user
		$this->add_user->ViewValue = $this->add_user->CurrentValue;
		$this->add_user->ViewCustomAttributes = "";

		// slno
		$this->slno->LinkCustomAttributes = "";
		$this->slno->HrefValue = "";
		$this->slno->TooltipValue = "";

		// date
		$this->date->LinkCustomAttributes = "";
		$this->date->HrefValue = "";
		$this->date->TooltipValue = "";

		// time
		$this->time->LinkCustomAttributes = "";
		$this->time->HrefValue = "";
		$this->time->TooltipValue = "";

		// dc_number
		$this->dc_number->LinkCustomAttributes = "";
		$this->dc_number->HrefValue = "";
		$this->dc_number->TooltipValue = "";

		// customer_name
		$this->customer_name->LinkCustomAttributes = "";
		$this->customer_name->HrefValue = "";
		$this->customer_name->TooltipValue = "";

		// ticket_name
		$this->ticket_name->LinkCustomAttributes = "";
		$this->ticket_name->HrefValue = "";
		$this->ticket_name->TooltipValue = "";

		// draw_date
		$this->draw_date->LinkCustomAttributes = "";
		$this->draw_date->HrefValue = "";
		$this->draw_date->TooltipValue = "";

		// ticket_catagory
		$this->ticket_catagory->LinkCustomAttributes = "";
		$this->ticket_catagory->HrefValue = "";
		$this->ticket_catagory->TooltipValue = "";

		// dc_type
		$this->dc_type->LinkCustomAttributes = "";
		$this->dc_type->HrefValue = "";
		$this->dc_type->TooltipValue = "";

		// serial_number
		$this->serial_number->LinkCustomAttributes = "";
		$this->serial_number->HrefValue = "";
		$this->serial_number->TooltipValue = "";

		// priced_serial_and_amount
		$this->priced_serial_and_amount->LinkCustomAttributes = "";
		$this->priced_serial_and_amount->HrefValue = "";
		$this->priced_serial_and_amount->TooltipValue = "";

		// commission_amount
		$this->commission_amount->LinkCustomAttributes = "";
		$this->commission_amount->HrefValue = "";
		$this->commission_amount->TooltipValue = "";

		// agency_dc
		$this->agency_dc->LinkCustomAttributes = "";
		$this->agency_dc->HrefValue = "";
		$this->agency_dc->TooltipValue = "";

		// total_dc
		$this->total_dc->LinkCustomAttributes = "";
		$this->total_dc->HrefValue = "";
		$this->total_dc->TooltipValue = "";

		// add_user
		$this->add_user->LinkCustomAttributes = "";
		$this->add_user->HrefValue = "";
		$this->add_user->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// slno
		$this->slno->EditAttrs["class"] = "form-control";
		$this->slno->EditCustomAttributes = "";
		$this->slno->EditValue = $this->slno->CurrentValue;
		$this->slno->ViewCustomAttributes = "";

		// date
		// time
		// dc_number

		$this->dc_number->EditAttrs["class"] = "form-control";
		$this->dc_number->EditCustomAttributes = "";
		$this->dc_number->EditValue = $this->dc_number->CurrentValue;
		$this->dc_number->PlaceHolder = RemoveHtml($this->dc_number->caption());

		// customer_name
		$this->customer_name->EditAttrs["class"] = "form-control";
		$this->customer_name->EditCustomAttributes = "";
		if (!$this->customer_name->Raw)
			$this->customer_name->CurrentValue = HtmlDecode($this->customer_name->CurrentValue);
		$this->customer_name->EditValue = $this->customer_name->CurrentValue;
		$this->customer_name->PlaceHolder = RemoveHtml($this->customer_name->caption());

		// ticket_name
		$this->ticket_name->EditAttrs["class"] = "form-control";
		$this->ticket_name->EditCustomAttributes = "";
		if (!$this->ticket_name->Raw)
			$this->ticket_name->CurrentValue = HtmlDecode($this->ticket_name->CurrentValue);
		$this->ticket_name->EditValue = $this->ticket_name->CurrentValue;
		$this->ticket_name->PlaceHolder = RemoveHtml($this->ticket_name->caption());

		// draw_date
		$this->draw_date->EditAttrs["class"] = "form-control";
		$this->draw_date->EditCustomAttributes = "";
		if (!$this->draw_date->Raw)
			$this->draw_date->CurrentValue = HtmlDecode($this->draw_date->CurrentValue);
		$this->draw_date->EditValue = $this->draw_date->CurrentValue;
		$this->draw_date->PlaceHolder = RemoveHtml($this->draw_date->caption());

		// ticket_catagory
		$this->ticket_catagory->EditAttrs["class"] = "form-control";
		$this->ticket_catagory->EditCustomAttributes = "";
		if (!$this->ticket_catagory->Raw)
			$this->ticket_catagory->CurrentValue = HtmlDecode($this->ticket_catagory->CurrentValue);
		$this->ticket_catagory->EditValue = $this->ticket_catagory->CurrentValue;
		$this->ticket_catagory->PlaceHolder = RemoveHtml($this->ticket_catagory->caption());

		// dc_type
		$this->dc_type->EditAttrs["class"] = "form-control";
		$this->dc_type->EditCustomAttributes = "";
		if (!$this->dc_type->Raw)
			$this->dc_type->CurrentValue = HtmlDecode($this->dc_type->CurrentValue);
		$this->dc_type->EditValue = $this->dc_type->CurrentValue;
		$this->dc_type->PlaceHolder = RemoveHtml($this->dc_type->caption());

		// serial_number
		$this->serial_number->EditAttrs["class"] = "form-control";
		$this->serial_number->EditCustomAttributes = "";
		$this->serial_number->EditValue = $this->serial_number->CurrentValue;
		$this->serial_number->PlaceHolder = RemoveHtml($this->serial_number->caption());

		// priced_serial_and_amount
		$this->priced_serial_and_amount->EditAttrs["class"] = "form-control";
		$this->priced_serial_and_amount->EditCustomAttributes = "";
		$this->priced_serial_and_amount->EditValue = $this->priced_serial_and_amount->CurrentValue;
		$this->priced_serial_and_amount->PlaceHolder = RemoveHtml($this->priced_serial_and_amount->caption());

		// commission_amount
		$this->commission_amount->EditAttrs["class"] = "form-control";
		$this->commission_amount->EditCustomAttributes = "";
		$this->commission_amount->EditValue = $this->commission_amount->CurrentValue;
		$this->commission_amount->PlaceHolder = RemoveHtml($this->commission_amount->caption());

		// agency_dc
		$this->agency_dc->EditAttrs["class"] = "form-control";
		$this->agency_dc->EditCustomAttributes = "";
		$this->agency_dc->EditValue = $this->agency_dc->CurrentValue;
		$this->agency_dc->PlaceHolder = RemoveHtml($this->agency_dc->caption());

		// total_dc
		$this->total_dc->EditAttrs["class"] = "form-control";
		$this->total_dc->EditCustomAttributes = "";
		$this->total_dc->EditValue = $this->total_dc->CurrentValue;
		$this->total_dc->PlaceHolder = RemoveHtml($this->total_dc->caption());

		// add_user
		// Call Row Rendered event

		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
			$this->slno->Count++; // Increment count
			if (is_numeric($this->commission_amount->CurrentValue))
				$this->commission_amount->Total += $this->commission_amount->CurrentValue; // Accumulate total
			if (is_numeric($this->agency_dc->CurrentValue))
				$this->agency_dc->Total += $this->agency_dc->CurrentValue; // Accumulate total
			if (is_numeric($this->total_dc->CurrentValue))
				$this->total_dc->Total += $this->total_dc->CurrentValue; // Accumulate total
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{
			$this->slno->CurrentValue = $this->slno->Count;
			$this->slno->ViewValue = $this->slno->CurrentValue;
			$this->slno->ViewCustomAttributes = "";
			$this->slno->HrefValue = ""; // Clear href value
			$this->commission_amount->CurrentValue = $this->commission_amount->Total;
			$this->commission_amount->ViewValue = $this->commission_amount->CurrentValue;
			$this->commission_amount->ViewValue = FormatNumber($this->commission_amount->ViewValue, 0, -2, -2, -2);
			$this->commission_amount->ViewCustomAttributes = "";
			$this->commission_amount->HrefValue = ""; // Clear href value
			$this->agency_dc->CurrentValue = $this->agency_dc->Total;
			$this->agency_dc->ViewValue = $this->agency_dc->CurrentValue;
			$this->agency_dc->ViewValue = FormatNumber($this->agency_dc->ViewValue, 0, -2, -2, -2);
			$this->agency_dc->ViewCustomAttributes = "";
			$this->agency_dc->HrefValue = ""; // Clear href value
			$this->total_dc->CurrentValue = $this->total_dc->Total;
			$this->total_dc->ViewValue = $this->total_dc->CurrentValue;
			$this->total_dc->ViewValue = FormatNumber($this->total_dc->ViewValue, 0, -2, -2, -2);
			$this->total_dc->ViewCustomAttributes = "";
			$this->total_dc->HrefValue = ""; // Clear href value

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->slno);
					$doc->exportCaption($this->date);
					$doc->exportCaption($this->time);
					$doc->exportCaption($this->dc_number);
					$doc->exportCaption($this->customer_name);
					$doc->exportCaption($this->ticket_name);
					$doc->exportCaption($this->draw_date);
					$doc->exportCaption($this->ticket_catagory);
					$doc->exportCaption($this->dc_type);
					$doc->exportCaption($this->serial_number);
					$doc->exportCaption($this->priced_serial_and_amount);
					$doc->exportCaption($this->commission_amount);
					$doc->exportCaption($this->agency_dc);
					$doc->exportCaption($this->total_dc);
					$doc->exportCaption($this->add_user);
				} else {
					$doc->exportCaption($this->slno);
					$doc->exportCaption($this->date);
					$doc->exportCaption($this->time);
					$doc->exportCaption($this->dc_number);
					$doc->exportCaption($this->customer_name);
					$doc->exportCaption($this->ticket_name);
					$doc->exportCaption($this->draw_date);
					$doc->exportCaption($this->ticket_catagory);
					$doc->exportCaption($this->dc_type);
					$doc->exportCaption($this->commission_amount);
					$doc->exportCaption($this->agency_dc);
					$doc->exportCaption($this->total_dc);
					$doc->exportCaption($this->add_user);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);
				$this->aggregateListRowValues(); // Aggregate row values

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->slno);
						$doc->exportField($this->date);
						$doc->exportField($this->time);
						$doc->exportField($this->dc_number);
						$doc->exportField($this->customer_name);
						$doc->exportField($this->ticket_name);
						$doc->exportField($this->draw_date);
						$doc->exportField($this->ticket_catagory);
						$doc->exportField($this->dc_type);
						$doc->exportField($this->serial_number);
						$doc->exportField($this->priced_serial_and_amount);
						$doc->exportField($this->commission_amount);
						$doc->exportField($this->agency_dc);
						$doc->exportField($this->total_dc);
						$doc->exportField($this->add_user);
					} else {
						$doc->exportField($this->slno);
						$doc->exportField($this->date);
						$doc->exportField($this->time);
						$doc->exportField($this->dc_number);
						$doc->exportField($this->customer_name);
						$doc->exportField($this->ticket_name);
						$doc->exportField($this->draw_date);
						$doc->exportField($this->ticket_catagory);
						$doc->exportField($this->dc_type);
						$doc->exportField($this->commission_amount);
						$doc->exportField($this->agency_dc);
						$doc->exportField($this->total_dc);
						$doc->exportField($this->add_user);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}

		// Export aggregates (horizontal format only)
		if ($doc->Horizontal) {
			$this->RowType = ROWTYPE_AGGREGATE;
			$this->resetAttributes();
			$this->aggregateListRow();
			if (!$doc->ExportCustom) {
				$doc->beginExportRow(-1);
				$doc->exportAggregate($this->slno, 'COUNT');
				$doc->exportAggregate($this->date, '');
				$doc->exportAggregate($this->time, '');
				$doc->exportAggregate($this->dc_number, '');
				$doc->exportAggregate($this->customer_name, '');
				$doc->exportAggregate($this->ticket_name, '');
				$doc->exportAggregate($this->draw_date, '');
				$doc->exportAggregate($this->ticket_catagory, '');
				$doc->exportAggregate($this->dc_type, '');
				$doc->exportAggregate($this->commission_amount, 'TOTAL');
				$doc->exportAggregate($this->agency_dc, 'TOTAL');
				$doc->exportAggregate($this->total_dc, 'TOTAL');
				$doc->exportAggregate($this->add_user, '');
				$doc->endExportRow();
			}
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>