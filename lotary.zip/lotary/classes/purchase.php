<?php namespace PHPMaker2020\project5; ?>
<?php

/**
 * Table class for purchase
 */
class purchase extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $slno;
	public $agent;
	public $Invoice_no;
	public $purchase_date;
	public $ticket_name;
	public $draw_date;
	public $draw_code;
	public $serial_numbers;
	public $total_amount;
	public $add_user;
	public $add_date;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'purchase';
		$this->TableName = 'purchase';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`purchase`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = ""; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// slno
		$this->slno = new DbField('purchase', 'purchase', 'x_slno', 'slno', '`slno`', '`slno`', 3, 10, -1, FALSE, '`slno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->slno->IsAutoIncrement = TRUE; // Autoincrement field
		$this->slno->IsPrimaryKey = TRUE; // Primary key field
		$this->slno->Sortable = TRUE; // Allow sort
		$this->slno->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['slno'] = &$this->slno;

		// agent
		$this->agent = new DbField('purchase', 'purchase', 'x_agent', 'agent', '`agent`', '`agent`', 200, 20, -1, FALSE, '`agent`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->agent->Nullable = FALSE; // NOT NULL field
		$this->agent->Required = TRUE; // Required field
		$this->agent->Sortable = TRUE; // Allow sort
		$this->agent->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->agent->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->agent->Lookup = new Lookup('agent', 'agency', FALSE, 'agency_name', ["agency_name","","",""], [], [], [], [], [], [], '', '');
		$this->fields['agent'] = &$this->agent;

		// Invoice_no
		$this->Invoice_no = new DbField('purchase', 'purchase', 'x_Invoice_no', 'Invoice_no', '`Invoice_no`', '`Invoice_no`', 200, 20, -1, FALSE, '`Invoice_no`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Invoice_no->Nullable = FALSE; // NOT NULL field
		$this->Invoice_no->Required = TRUE; // Required field
		$this->Invoice_no->Sortable = TRUE; // Allow sort
		$this->fields['Invoice_no'] = &$this->Invoice_no;

		// purchase_date
		$this->purchase_date = new DbField('purchase', 'purchase', 'x_purchase_date', 'purchase_date', '`purchase_date`', CastDateFieldForLike("`purchase_date`", 7, "DB"), 133, 10, 7, FALSE, '`purchase_date`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchase_date->Nullable = FALSE; // NOT NULL field
		$this->purchase_date->Required = TRUE; // Required field
		$this->purchase_date->Sortable = TRUE; // Allow sort
		$this->purchase_date->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_SEPARATOR"], $Language->phrase("IncorrectDateDMY"));
		$this->fields['purchase_date'] = &$this->purchase_date;

		// ticket_name
		$this->ticket_name = new DbField('purchase', 'purchase', 'x_ticket_name', 'ticket_name', '`ticket_name`', '`ticket_name`', 200, 20, -1, FALSE, '`ticket_name`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->ticket_name->Nullable = FALSE; // NOT NULL field
		$this->ticket_name->Required = TRUE; // Required field
		$this->ticket_name->Sortable = TRUE; // Allow sort
		$this->ticket_name->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->ticket_name->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->ticket_name->Lookup = new Lookup('ticket_name', 'draw_info', FALSE, 'ticket_name', ["ticket_name","","",""], [], [], [], [], ["draw_date","draw_code"], ["x_draw_date","x_draw_code"], '', '');
		$this->fields['ticket_name'] = &$this->ticket_name;

		// draw_date
		$this->draw_date = new DbField('purchase', 'purchase', 'x_draw_date', 'draw_date', '`draw_date`', CastDateFieldForLike("`draw_date`", 0, "DB"), 133, 10, 0, FALSE, '`draw_date`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->draw_date->Nullable = FALSE; // NOT NULL field
		$this->draw_date->Required = TRUE; // Required field
		$this->draw_date->Sortable = TRUE; // Allow sort
		$this->draw_date->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['draw_date'] = &$this->draw_date;

		// draw_code
		$this->draw_code = new DbField('purchase', 'purchase', 'x_draw_code', 'draw_code', '`draw_code`', '`draw_code`', 200, 20, 7, FALSE, '`draw_code`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->draw_code->Nullable = FALSE; // NOT NULL field
		$this->draw_code->Required = TRUE; // Required field
		$this->draw_code->Sortable = TRUE; // Allow sort
		$this->fields['draw_code'] = &$this->draw_code;

		// serial_numbers
		$this->serial_numbers = new DbField('purchase', 'purchase', 'x_serial_numbers', 'serial_numbers', '`serial_numbers`', '`serial_numbers`', 201, 300, -1, FALSE, '`serial_numbers`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->serial_numbers->Nullable = FALSE; // NOT NULL field
		$this->serial_numbers->Required = TRUE; // Required field
		$this->serial_numbers->Sortable = TRUE; // Allow sort
		$this->fields['serial_numbers'] = &$this->serial_numbers;

		// total_amount
		$this->total_amount = new DbField('purchase', 'purchase', 'x_total_amount', 'total_amount', '`total_amount`', '`total_amount`', 3, 10, -1, FALSE, '`total_amount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->total_amount->Nullable = FALSE; // NOT NULL field
		$this->total_amount->Required = TRUE; // Required field
		$this->total_amount->Sortable = TRUE; // Allow sort
		$this->total_amount->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['total_amount'] = &$this->total_amount;

		// add_user
		$this->add_user = new DbField('purchase', 'purchase', 'x_add_user', 'add_user', '`add_user`', '`add_user`', 200, 20, -1, FALSE, '`add_user`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->add_user->Nullable = FALSE; // NOT NULL field
		$this->add_user->Sortable = TRUE; // Allow sort
		$this->fields['add_user'] = &$this->add_user;

		// add_date
		$this->add_date = new DbField('purchase', 'purchase', 'x_add_date', 'add_date', '`add_date`', CastDateFieldForLike("`add_date`", 7, "DB"), 135, 19, 7, FALSE, '`add_date`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->add_date->Nullable = FALSE; // NOT NULL field
		$this->add_date->Sortable = TRUE; // Allow sort
		$this->add_date->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_SEPARATOR"], $Language->phrase("IncorrectDateDMY"));
		$this->fields['add_date'] = &$this->add_date;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`purchase`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "`slno` DESC";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter)
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = Config("USER_ID_ALLOW");
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " ($names) VALUES ($values)";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->slno->setDbValue($conn->insert_ID());
			$rs['slno'] = $this->slno->DbValue;
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('slno', $rs))
				AddFilter($where, QuotedName('slno', $this->Dbid) . '=' . QuotedValue($rs['slno'], $this->slno->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->slno->DbValue = $row['slno'];
		$this->agent->DbValue = $row['agent'];
		$this->Invoice_no->DbValue = $row['Invoice_no'];
		$this->purchase_date->DbValue = $row['purchase_date'];
		$this->ticket_name->DbValue = $row['ticket_name'];
		$this->draw_date->DbValue = $row['draw_date'];
		$this->draw_code->DbValue = $row['draw_code'];
		$this->serial_numbers->DbValue = $row['serial_numbers'];
		$this->total_amount->DbValue = $row['total_amount'];
		$this->add_user->DbValue = $row['add_user'];
		$this->add_date->DbValue = $row['add_date'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`slno` = @slno@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('slno', $row) ? $row['slno'] : NULL;
		else
			$val = $this->slno->OldValue !== NULL ? $this->slno->OldValue : $this->slno->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@slno@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "purchaselist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "purchaseview.php")
			return $Language->phrase("View");
		elseif ($pageName == "purchaseedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "purchaseadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "purchaselist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("purchaseview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("purchaseview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "purchaseadd.php?" . $this->getUrlParm($parm);
		else
			$url = "purchaseadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("purchaseedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("purchaseadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("purchasedelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "slno:" . JsonEncode($this->slno->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->slno->CurrentValue != NULL) {
			$url .= "slno=" . urlencode($this->slno->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("slno") !== NULL)
				$arKeys[] = Param("slno");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->slno->CurrentValue = $key;
			else
				$this->slno->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->slno->setDbValue($rs->fields('slno'));
		$this->agent->setDbValue($rs->fields('agent'));
		$this->Invoice_no->setDbValue($rs->fields('Invoice_no'));
		$this->purchase_date->setDbValue($rs->fields('purchase_date'));
		$this->ticket_name->setDbValue($rs->fields('ticket_name'));
		$this->draw_date->setDbValue($rs->fields('draw_date'));
		$this->draw_code->setDbValue($rs->fields('draw_code'));
		$this->serial_numbers->setDbValue($rs->fields('serial_numbers'));
		$this->total_amount->setDbValue($rs->fields('total_amount'));
		$this->add_user->setDbValue($rs->fields('add_user'));
		$this->add_date->setDbValue($rs->fields('add_date'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// slno
		// agent
		// Invoice_no
		// purchase_date
		// ticket_name
		// draw_date
		// draw_code
		// serial_numbers
		// total_amount
		// add_user
		// add_date
		// slno

		$this->slno->ViewValue = $this->slno->CurrentValue;
		$this->slno->ViewCustomAttributes = "";

		// agent
		$curVal = strval($this->agent->CurrentValue);
		if ($curVal != "") {
			$this->agent->ViewValue = $this->agent->lookupCacheOption($curVal);
			if ($this->agent->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`agency_name`" . SearchString("=", $curVal, DATATYPE_STRING, "");
				$sqlWrk = $this->agent->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->agent->ViewValue = $this->agent->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->agent->ViewValue = $this->agent->CurrentValue;
				}
			}
		} else {
			$this->agent->ViewValue = NULL;
		}
		$this->agent->ViewCustomAttributes = "";

		// Invoice_no
		$this->Invoice_no->ViewValue = $this->Invoice_no->CurrentValue;
		$this->Invoice_no->ViewCustomAttributes = "";

		// purchase_date
		$this->purchase_date->ViewValue = $this->purchase_date->CurrentValue;
		$this->purchase_date->ViewValue = FormatDateTime($this->purchase_date->ViewValue, 7);
		$this->purchase_date->ViewCustomAttributes = "";

		// ticket_name
		$curVal = strval($this->ticket_name->CurrentValue);
		if ($curVal != "") {
			$this->ticket_name->ViewValue = $this->ticket_name->lookupCacheOption($curVal);
			if ($this->ticket_name->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`ticket_name`" . SearchString("=", $curVal, DATATYPE_STRING, "");
				$sqlWrk = $this->ticket_name->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->ticket_name->ViewValue = $this->ticket_name->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->ticket_name->ViewValue = $this->ticket_name->CurrentValue;
				}
			}
		} else {
			$this->ticket_name->ViewValue = NULL;
		}
		$this->ticket_name->ViewCustomAttributes = "";

		// draw_date
		$this->draw_date->ViewValue = $this->draw_date->CurrentValue;
		$this->draw_date->ViewValue = FormatDateTime($this->draw_date->ViewValue, 0);
		$this->draw_date->ViewCustomAttributes = "";

		// draw_code
		$this->draw_code->ViewValue = $this->draw_code->CurrentValue;
		$this->draw_code->ViewCustomAttributes = "";

		// serial_numbers
		$this->serial_numbers->ViewValue = $this->serial_numbers->CurrentValue;
		$this->serial_numbers->ViewCustomAttributes = "";

		// total_amount
		$this->total_amount->ViewValue = $this->total_amount->CurrentValue;
		$this->total_amount->ViewValue = FormatNumber($this->total_amount->ViewValue, 0, -2, -2, -2);
		$this->total_amount->ViewCustomAttributes = "";

		// add_user
		$this->add_user->ViewValue = $this->add_user->CurrentValue;
		$this->add_user->ViewCustomAttributes = "";

		// add_date
		$this->add_date->ViewValue = $this->add_date->CurrentValue;
		$this->add_date->ViewValue = FormatDateTime($this->add_date->ViewValue, 7);
		$this->add_date->ViewCustomAttributes = "";

		// slno
		$this->slno->LinkCustomAttributes = "";
		$this->slno->HrefValue = "";
		$this->slno->TooltipValue = "";

		// agent
		$this->agent->LinkCustomAttributes = "";
		$this->agent->HrefValue = "";
		$this->agent->TooltipValue = "";

		// Invoice_no
		$this->Invoice_no->LinkCustomAttributes = "";
		$this->Invoice_no->HrefValue = "";
		$this->Invoice_no->TooltipValue = "";

		// purchase_date
		$this->purchase_date->LinkCustomAttributes = "";
		$this->purchase_date->HrefValue = "";
		$this->purchase_date->TooltipValue = "";

		// ticket_name
		$this->ticket_name->LinkCustomAttributes = "";
		$this->ticket_name->HrefValue = "";
		$this->ticket_name->TooltipValue = "";

		// draw_date
		$this->draw_date->LinkCustomAttributes = "";
		$this->draw_date->HrefValue = "";
		$this->draw_date->TooltipValue = "";

		// draw_code
		$this->draw_code->LinkCustomAttributes = "";
		$this->draw_code->HrefValue = "";
		$this->draw_code->TooltipValue = "";

		// serial_numbers
		$this->serial_numbers->LinkCustomAttributes = "";
		$this->serial_numbers->HrefValue = "";
		$this->serial_numbers->TooltipValue = "";

		// total_amount
		$this->total_amount->LinkCustomAttributes = "";
		$this->total_amount->HrefValue = "";
		$this->total_amount->TooltipValue = "";

		// add_user
		$this->add_user->LinkCustomAttributes = "";
		$this->add_user->HrefValue = "";
		$this->add_user->TooltipValue = "";

		// add_date
		$this->add_date->LinkCustomAttributes = "";
		$this->add_date->HrefValue = "";
		$this->add_date->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// slno
		$this->slno->EditAttrs["class"] = "form-control";
		$this->slno->EditCustomAttributes = "";
		$this->slno->EditValue = $this->slno->CurrentValue;
		$this->slno->ViewCustomAttributes = "";

		// agent
		$this->agent->EditAttrs["class"] = "form-control";
		$this->agent->EditCustomAttributes = "";

		// Invoice_no
		$this->Invoice_no->EditAttrs["class"] = "form-control";
		$this->Invoice_no->EditCustomAttributes = "";
		if (!$this->Invoice_no->Raw)
			$this->Invoice_no->CurrentValue = HtmlDecode($this->Invoice_no->CurrentValue);
		$this->Invoice_no->EditValue = $this->Invoice_no->CurrentValue;
		$this->Invoice_no->PlaceHolder = RemoveHtml($this->Invoice_no->caption());

		// purchase_date
		$this->purchase_date->EditAttrs["class"] = "form-control";
		$this->purchase_date->EditCustomAttributes = "";
		$this->purchase_date->EditValue = FormatDateTime($this->purchase_date->CurrentValue, 7);
		$this->purchase_date->PlaceHolder = RemoveHtml($this->purchase_date->caption());

		// ticket_name
		$this->ticket_name->EditAttrs["class"] = "form-control";
		$this->ticket_name->EditCustomAttributes = "";

		// draw_date
		$this->draw_date->EditAttrs["class"] = "form-control";
		$this->draw_date->EditCustomAttributes = "";
		$this->draw_date->EditValue = FormatDateTime($this->draw_date->CurrentValue, 8);
		$this->draw_date->PlaceHolder = RemoveHtml($this->draw_date->caption());

		// draw_code
		$this->draw_code->EditAttrs["class"] = "form-control";
		$this->draw_code->EditCustomAttributes = "";
		if (!$this->draw_code->Raw)
			$this->draw_code->CurrentValue = HtmlDecode($this->draw_code->CurrentValue);
		$this->draw_code->EditValue = $this->draw_code->CurrentValue;
		$this->draw_code->PlaceHolder = RemoveHtml($this->draw_code->caption());

		// serial_numbers
		$this->serial_numbers->EditAttrs["class"] = "form-control";
		$this->serial_numbers->EditCustomAttributes = "";
		$this->serial_numbers->EditValue = $this->serial_numbers->CurrentValue;
		$this->serial_numbers->PlaceHolder = RemoveHtml($this->serial_numbers->caption());

		// total_amount
		$this->total_amount->EditAttrs["class"] = "form-control";
		$this->total_amount->EditCustomAttributes = "";
		$this->total_amount->EditValue = $this->total_amount->CurrentValue;
		$this->total_amount->PlaceHolder = RemoveHtml($this->total_amount->caption());

		// add_user
		// add_date
		// Call Row Rendered event

		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
			$this->slno->Count++; // Increment count
			if (is_numeric($this->total_amount->CurrentValue))
				$this->total_amount->Total += $this->total_amount->CurrentValue; // Accumulate total
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{
			$this->slno->CurrentValue = $this->slno->Count;
			$this->slno->ViewValue = $this->slno->CurrentValue;
			$this->slno->ViewCustomAttributes = "";
			$this->slno->HrefValue = ""; // Clear href value
			$this->total_amount->CurrentValue = $this->total_amount->Total;
			$this->total_amount->ViewValue = $this->total_amount->CurrentValue;
			$this->total_amount->ViewValue = FormatNumber($this->total_amount->ViewValue, 0, -2, -2, -2);
			$this->total_amount->ViewCustomAttributes = "";
			$this->total_amount->HrefValue = ""; // Clear href value

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->slno);
					$doc->exportCaption($this->agent);
					$doc->exportCaption($this->Invoice_no);
					$doc->exportCaption($this->purchase_date);
					$doc->exportCaption($this->ticket_name);
					$doc->exportCaption($this->draw_date);
					$doc->exportCaption($this->draw_code);
					$doc->exportCaption($this->serial_numbers);
					$doc->exportCaption($this->total_amount);
					$doc->exportCaption($this->add_user);
					$doc->exportCaption($this->add_date);
				} else {
					$doc->exportCaption($this->slno);
					$doc->exportCaption($this->agent);
					$doc->exportCaption($this->Invoice_no);
					$doc->exportCaption($this->purchase_date);
					$doc->exportCaption($this->ticket_name);
					$doc->exportCaption($this->draw_date);
					$doc->exportCaption($this->draw_code);
					$doc->exportCaption($this->serial_numbers);
					$doc->exportCaption($this->total_amount);
					$doc->exportCaption($this->add_user);
					$doc->exportCaption($this->add_date);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);
				$this->aggregateListRowValues(); // Aggregate row values

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->slno);
						$doc->exportField($this->agent);
						$doc->exportField($this->Invoice_no);
						$doc->exportField($this->purchase_date);
						$doc->exportField($this->ticket_name);
						$doc->exportField($this->draw_date);
						$doc->exportField($this->draw_code);
						$doc->exportField($this->serial_numbers);
						$doc->exportField($this->total_amount);
						$doc->exportField($this->add_user);
						$doc->exportField($this->add_date);
					} else {
						$doc->exportField($this->slno);
						$doc->exportField($this->agent);
						$doc->exportField($this->Invoice_no);
						$doc->exportField($this->purchase_date);
						$doc->exportField($this->ticket_name);
						$doc->exportField($this->draw_date);
						$doc->exportField($this->draw_code);
						$doc->exportField($this->serial_numbers);
						$doc->exportField($this->total_amount);
						$doc->exportField($this->add_user);
						$doc->exportField($this->add_date);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}

		// Export aggregates (horizontal format only)
		if ($doc->Horizontal) {
			$this->RowType = ROWTYPE_AGGREGATE;
			$this->resetAttributes();
			$this->aggregateListRow();
			if (!$doc->ExportCustom) {
				$doc->beginExportRow(-1);
				$doc->exportAggregate($this->slno, 'COUNT');
				$doc->exportAggregate($this->agent, '');
				$doc->exportAggregate($this->Invoice_no, '');
				$doc->exportAggregate($this->purchase_date, '');
				$doc->exportAggregate($this->ticket_name, '');
				$doc->exportAggregate($this->draw_date, '');
				$doc->exportAggregate($this->draw_code, '');
				$doc->exportAggregate($this->serial_numbers, '');
				$doc->exportAggregate($this->total_amount, 'TOTAL');
				$doc->exportAggregate($this->add_user, '');
				$doc->exportAggregate($this->add_date, '');
				$doc->endExportRow();
			}
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>