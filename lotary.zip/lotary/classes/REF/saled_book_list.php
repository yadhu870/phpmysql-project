<?php
namespace PHPMaker2020\project5;

/**
 * Page class
 */
class saled_book_list extends saled_book
{

	// Page ID
	public $PageID = "list";

	// Project ID
	public $ProjectID = "{F0A8F6B1-49EF-452D-8862-FBD7CADADF89}";

	// Table name
	public $TableName = 'saled_book';

	// Page object name
	public $PageObjName = "saled_book_list";

	// Grid form hidden field names
	public $FormName = "fsaled_booklist";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Export URLs
	public $ExportPrintUrl;
	public $ExportHtmlUrl;
	public $ExportExcelUrl;
	public $ExportWordUrl;
	public $ExportXmlUrl;
	public $ExportCsvUrl;
	public $ExportPdfUrl;

	// Custom export
	public $ExportExcelCustom = FALSE;
	public $ExportWordCustom = FALSE;
	public $ExportPdfCustom = FALSE;
	public $ExportEmailCustom = FALSE;

	// Update URLs
	public $InlineAddUrl;
	public $InlineCopyUrl;
	public $InlineEditUrl;
	public $GridAddUrl;
	public $GridEditUrl;
	public $MultiDeleteUrl;
	public $MultiUpdateUrl;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = TRUE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (saled_book)
		if (!isset($GLOBALS["saled_book"]) || get_class($GLOBALS["saled_book"]) == PROJECT_NAMESPACE . "saled_book") {
			$GLOBALS["saled_book"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["saled_book"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->pageUrl() . "export=print";
		$this->ExportExcelUrl = $this->pageUrl() . "export=excel";
		$this->ExportWordUrl = $this->pageUrl() . "export=word";
		$this->ExportPdfUrl = $this->pageUrl() . "export=pdf";
		$this->ExportHtmlUrl = $this->pageUrl() . "export=html";
		$this->ExportXmlUrl = $this->pageUrl() . "export=xml";
		$this->ExportCsvUrl = $this->pageUrl() . "export=csv";
		$this->AddUrl = "saled_bookadd.php";
		$this->InlineAddUrl = $this->pageUrl() . "action=add";
		$this->GridAddUrl = $this->pageUrl() . "action=gridadd";
		$this->GridEditUrl = $this->pageUrl() . "action=gridedit";
		$this->MultiDeleteUrl = "saled_bookdelete.php";
		$this->MultiUpdateUrl = "saled_bookupdate.php";

		// Table object (user_login)
		if (!isset($GLOBALS['user_login']))
			$GLOBALS['user_login'] = new user_login();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'list');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'saled_book');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (user_login)
		$UserTable = $UserTable ?: new user_login();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Export options
		$this->ExportOptions = new ListOptions("div");
		$this->ExportOptions->TagClassName = "ew-export-option";

		// Import options
		$this->ImportOptions = new ListOptions("div");
		$this->ImportOptions->TagClassName = "ew-import-option";

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
		$this->OtherOptions["detail"] = new ListOptions("div");
		$this->OtherOptions["detail"]->TagClassName = "ew-detail-option";
		$this->OtherOptions["action"] = new ListOptions("div");
		$this->OtherOptions["action"]->TagClassName = "ew-action-option";

		// Filter options
		$this->FilterOptions = new ListOptions("div");
		$this->FilterOptions->TagClassName = "ew-filter-option fsaled_booklistsrch";

		// List actions
		$this->ListActions = new ListActions();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $saled_book;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($saled_book);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["mimeType" => ContentType($val), "url" => $url];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$row[$fldname] = ["mimeType" => MimeContentType($val), "url" => FullUrl($fld->hrefPath() . $val)];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => FullUrl($fld->hrefPath() . $file)];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['slno'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->slno->Visible = FALSE;
		if ($this->isAddOrEdit())
			$this->date->Visible = FALSE;
		if ($this->isAddOrEdit())
			$this->time->Visible = FALSE;
		if ($this->isAddOrEdit())
			$this->add_user->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!$this->setupApiRequest())
			return FALSE;

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Get("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API request
	public function setupApiRequest()
	{
		global $Security;

		// Check security for API request
		If (ValidApiRequest()) {
			if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
			if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
			return TRUE;
		}
		return FALSE;
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $DisplayRecords = 100;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = "10,20,50,100,-1"; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (!$this->setupApiRequest()) {
			$Security = new AdvancedSecurity();
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get export parameters
		$custom = "";
		if (Param("export") !== NULL) {
			$this->Export = Param("export");
			$custom = Param("custom", "");
		} elseif (IsPost()) {
			if (Post("exporttype") !== NULL)
				$this->Export = Post("exporttype");
			$custom = Post("custom", "");
		} elseif (Get("cmd") == "json") {
			$this->Export = Get("cmd");
		} else {
			$this->setExportReturnUrl(CurrentUrl());
		}
		$ExportFileName = $this->TableVar; // Get export file, used in header

		// Get custom export parameters
		if ($this->isExport() && $custom != "") {
			$this->CustomExport = $this->Export;
			$this->Export = "print";
		}
		$CustomExportType = $this->CustomExport;
		$ExportType = $this->Export; // Get export parameter, used in header

		// Update Export URLs
		if (Config("USE_PHPEXCEL"))
			$this->ExportExcelCustom = FALSE;
		if ($this->ExportExcelCustom)
			$this->ExportExcelUrl .= "&amp;custom=1";
		if (Config("USE_PHPWORD"))
			$this->ExportWordCustom = FALSE;
		if ($this->ExportWordCustom)
			$this->ExportWordUrl .= "&amp;custom=1";
		if ($this->ExportPdfCustom)
			$this->ExportPdfUrl .= "&amp;custom=1";
		$this->CurrentAction = Param("action"); // Set up current action

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();

		// Setup export options
		$this->setupExportOptions();
		$this->slno->setVisibility();
		$this->date->setVisibility();
		$this->time->setVisibility();
		$this->customer_name->setVisibility();
		$this->contact->setVisibility();
		$this->dc_type->setVisibility();
		$this->agency->setVisibility();
		$this->serial_no->setVisibility();
		$this->book_count->Visible = FALSE;
		$this->ticket_name->setVisibility();
		$this->ticket_catagory->setVisibility();
		$this->no_of_ticket->setVisibility();
		$this->total_no_of_ticket->setVisibility();
		$this->draw_code->Visible = FALSE;
		$this->draw_date->setVisibility();
		$this->rate->Visible = FALSE;
		$this->paid_amound->setVisibility();
		$this->pending->setVisibility();
		$this->Total->setVisibility();
		$this->add_user->setVisibility();
		$this->Edit_user->setVisibility();
		$this->pending_amount_paid_date->setVisibility();
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Setup other options
		$this->setupOtherOptions();

		// Set up custom action (compatible with old version)
		foreach ($this->CustomActions as $name => $action)
			$this->ListActions->add($name, $action);

		// Show checkbox column if multiple action
		foreach ($this->ListActions->Items as $listaction) {
			if ($listaction->Select == ACTION_MULTIPLE && $listaction->Allow) {
				$this->ListOptions["checkbox"]->Visible = TRUE;
				break;
			}
		}

		// Set up lookup cache
		$this->setupLookupOptions($this->customer_name);
		$this->setupLookupOptions($this->dc_type);
		$this->setupLookupOptions($this->agency);
		$this->setupLookupOptions($this->ticket_name);
		$this->setupLookupOptions($this->ticket_catagory);
		$this->setupLookupOptions($this->no_of_ticket);
		$this->setupLookupOptions($this->draw_code);
		$this->setupLookupOptions($this->draw_date);
		$this->setupLookupOptions($this->rate);

		// Search filters
		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Process list action first
			if ($this->processListAction()) // Ajax request
				$this->terminate();

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Set up Breadcrumb
			if (!$this->isExport())
				$this->setupBreadcrumb();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Hide options
			if ($this->isExport() || $this->CurrentAction) {
				$this->ExportOptions->hideAllOptions();
				$this->FilterOptions->hideAllOptions();
				$this->ImportOptions->hideAllOptions();
			}

			// Hide other options
			if ($this->isExport())
				$this->OtherOptions->hideAllOptions();

			// Get default search criteria
			AddFilter($this->DefaultSearchWhere, $this->basicSearchWhere(TRUE));
			AddFilter($this->DefaultSearchWhere, $this->advancedSearchWhere(TRUE));

			// Get basic search values
			$this->loadBasicSearchValues();

			// Get and validate search values for advanced search
			$this->loadSearchValues(); // Get search values

			// Process filter list
			if ($this->processFilterList())
				$this->terminate();
			if (!$this->validateSearch())
				$this->setFailureMessage($SearchError);

			// Restore search parms from Session if not searching / reset / export
			if (($this->isExport() || $this->Command != "search" && $this->Command != "reset" && $this->Command != "resetall") && $this->Command != "json" && $this->checkSearchParms())
				$this->restoreSearchParms();

			// Call Recordset SearchValidated event
			$this->Recordset_SearchValidated();

			// Set up sorting order
			$this->setupSortOrder();

			// Get basic search criteria
			if ($SearchError == "")
				$srchBasic = $this->basicSearchWhere();

			// Get search criteria for advanced search
			if ($SearchError == "")
				$srchAdvanced = $this->advancedSearchWhere();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 100; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Load search default if no existing search criteria
		if (!$this->checkSearchParms()) {

			// Load basic search from default
			$this->BasicSearch->loadDefault();
			if ($this->BasicSearch->Keyword != "")
				$srchBasic = $this->basicSearchWhere();

			// Load advanced search from default
			if ($this->loadAdvancedSearchDefault()) {
				$srchAdvanced = $this->advancedSearchWhere();
			}
		}

		// Restore search settings from Session
		if ($SearchError == "")
			$this->loadAdvancedSearch();

		// Build search criteria
		AddFilter($this->SearchWhere, $srchAdvanced);
		AddFilter($this->SearchWhere, $srchBasic);

		// Call Recordset_Searching event
		$this->Recordset_Searching($this->SearchWhere);

		// Save search criteria
		if ($this->Command == "search" && !$this->RestoreSearch) {
			$this->setSearchWhere($this->SearchWhere); // Save to Session
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->Command != "json") {
			$this->SearchWhere = $this->getSearchWhere();
		}

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}

		// Export data only
		if (!$this->CustomExport && in_array($this->Export, array_keys(Config("EXPORT_CLASSES")))) {
			$this->exportData();
			$this->terminate();
		}
		if ($this->isGridAdd()) {
			$this->CurrentFilter = "0=1";
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->GridAddRowCount;
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			if ($this->DisplayRecords <= 0 || ($this->isExport() && $this->ExportAll)) // Display all records
				$this->DisplayRecords = $this->TotalRecords;
			if (!($this->isExport() && $this->ExportAll)) // Set up start record position
				$this->setupStartRecord();
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);

			// Set no record found message
			if (!$this->CurrentAction && $this->TotalRecords == 0) {
				if (!$Security->canList())
					$this->setWarningMessage(DeniedMessage());
				if ($this->SearchWhere == "0=101")
					$this->setWarningMessage($Language->phrase("EnterSearchCriteria"));
				else
					$this->setWarningMessage($Language->phrase("NoRecord"));
			}
		}

		// Search options
		$this->setupSearchOptions();

		// Set up search panel class
		if ($this->SearchWhere != "")
			AppendClass($this->SearchPanelClass, "show");

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 100; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 1) {
			$this->slno->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->slno->OldValue))
				return FALSE;
		}
		return TRUE;
	}

	// Get list of filters
	public function getFilterList()
	{
		global $UserProfile;

		// Initialize
		$filterList = "";
		$savedFilterList = "";
		$filterList = Concat($filterList, $this->slno->AdvancedSearch->toJson(), ","); // Field slno
		$filterList = Concat($filterList, $this->date->AdvancedSearch->toJson(), ","); // Field date
		$filterList = Concat($filterList, $this->time->AdvancedSearch->toJson(), ","); // Field time
		$filterList = Concat($filterList, $this->customer_name->AdvancedSearch->toJson(), ","); // Field customer_name
		$filterList = Concat($filterList, $this->contact->AdvancedSearch->toJson(), ","); // Field contact
		$filterList = Concat($filterList, $this->dc_type->AdvancedSearch->toJson(), ","); // Field dc-type
		$filterList = Concat($filterList, $this->agency->AdvancedSearch->toJson(), ","); // Field agency
		$filterList = Concat($filterList, $this->serial_no->AdvancedSearch->toJson(), ","); // Field serial_no
		$filterList = Concat($filterList, $this->book_count->AdvancedSearch->toJson(), ","); // Field book_count
		$filterList = Concat($filterList, $this->ticket_name->AdvancedSearch->toJson(), ","); // Field ticket_name
		$filterList = Concat($filterList, $this->ticket_catagory->AdvancedSearch->toJson(), ","); // Field ticket_catagory
		$filterList = Concat($filterList, $this->no_of_ticket->AdvancedSearch->toJson(), ","); // Field no_of_ticket
		$filterList = Concat($filterList, $this->total_no_of_ticket->AdvancedSearch->toJson(), ","); // Field total_no_of_ticket
		$filterList = Concat($filterList, $this->draw_code->AdvancedSearch->toJson(), ","); // Field draw_code
		$filterList = Concat($filterList, $this->draw_date->AdvancedSearch->toJson(), ","); // Field draw_date
		$filterList = Concat($filterList, $this->rate->AdvancedSearch->toJson(), ","); // Field rate
		$filterList = Concat($filterList, $this->paid_amound->AdvancedSearch->toJson(), ","); // Field paid_amound
		$filterList = Concat($filterList, $this->pending->AdvancedSearch->toJson(), ","); // Field pending
		$filterList = Concat($filterList, $this->Total->AdvancedSearch->toJson(), ","); // Field Total
		$filterList = Concat($filterList, $this->add_user->AdvancedSearch->toJson(), ","); // Field add_user
		$filterList = Concat($filterList, $this->Edit_user->AdvancedSearch->toJson(), ","); // Field Edit_user
		$filterList = Concat($filterList, $this->pending_amount_paid_date->AdvancedSearch->toJson(), ","); // Field pending_amount_paid_date
		if ($this->BasicSearch->Keyword != "") {
			$wrk = "\"" . Config("TABLE_BASIC_SEARCH") . "\":\"" . JsEncode($this->BasicSearch->Keyword) . "\",\"" . Config("TABLE_BASIC_SEARCH_TYPE") . "\":\"" . JsEncode($this->BasicSearch->Type) . "\"";
			$filterList = Concat($filterList, $wrk, ",");
		}

		// Return filter list in JSON
		if ($filterList != "")
			$filterList = "\"data\":{" . $filterList . "}";
		if ($savedFilterList != "")
			$filterList = Concat($filterList, "\"filters\":" . $savedFilterList, ",");
		return ($filterList != "") ? "{" . $filterList . "}" : "null";
	}

	// Process filter list
	protected function processFilterList()
	{
		global $UserProfile;
		if (Post("ajax") == "savefilters") { // Save filter request (Ajax)
			$filters = Post("filters");
			$UserProfile->setSearchFilters(CurrentUserName(), "fsaled_booklistsrch", $filters);
			WriteJson([["success" => TRUE]]); // Success
			return TRUE;
		} elseif (Post("cmd") == "resetfilter") {
			$this->restoreFilterList();
		}
		return FALSE;
	}

	// Restore list of filters
	protected function restoreFilterList()
	{

		// Return if not reset filter
		if (Post("cmd") !== "resetfilter")
			return FALSE;
		$filter = json_decode(Post("filter"), TRUE);
		$this->Command = "search";

		// Field slno
		$this->slno->AdvancedSearch->SearchValue = @$filter["x_slno"];
		$this->slno->AdvancedSearch->SearchOperator = @$filter["z_slno"];
		$this->slno->AdvancedSearch->SearchCondition = @$filter["v_slno"];
		$this->slno->AdvancedSearch->SearchValue2 = @$filter["y_slno"];
		$this->slno->AdvancedSearch->SearchOperator2 = @$filter["w_slno"];
		$this->slno->AdvancedSearch->save();

		// Field date
		$this->date->AdvancedSearch->SearchValue = @$filter["x_date"];
		$this->date->AdvancedSearch->SearchOperator = @$filter["z_date"];
		$this->date->AdvancedSearch->SearchCondition = @$filter["v_date"];
		$this->date->AdvancedSearch->SearchValue2 = @$filter["y_date"];
		$this->date->AdvancedSearch->SearchOperator2 = @$filter["w_date"];
		$this->date->AdvancedSearch->save();

		// Field time
		$this->time->AdvancedSearch->SearchValue = @$filter["x_time"];
		$this->time->AdvancedSearch->SearchOperator = @$filter["z_time"];
		$this->time->AdvancedSearch->SearchCondition = @$filter["v_time"];
		$this->time->AdvancedSearch->SearchValue2 = @$filter["y_time"];
		$this->time->AdvancedSearch->SearchOperator2 = @$filter["w_time"];
		$this->time->AdvancedSearch->save();

		// Field customer_name
		$this->customer_name->AdvancedSearch->SearchValue = @$filter["x_customer_name"];
		$this->customer_name->AdvancedSearch->SearchOperator = @$filter["z_customer_name"];
		$this->customer_name->AdvancedSearch->SearchCondition = @$filter["v_customer_name"];
		$this->customer_name->AdvancedSearch->SearchValue2 = @$filter["y_customer_name"];
		$this->customer_name->AdvancedSearch->SearchOperator2 = @$filter["w_customer_name"];
		$this->customer_name->AdvancedSearch->save();

		// Field contact
		$this->contact->AdvancedSearch->SearchValue = @$filter["x_contact"];
		$this->contact->AdvancedSearch->SearchOperator = @$filter["z_contact"];
		$this->contact->AdvancedSearch->SearchCondition = @$filter["v_contact"];
		$this->contact->AdvancedSearch->SearchValue2 = @$filter["y_contact"];
		$this->contact->AdvancedSearch->SearchOperator2 = @$filter["w_contact"];
		$this->contact->AdvancedSearch->save();

		// Field dc-type
		$this->dc_type->AdvancedSearch->SearchValue = @$filter["x_dc_type"];
		$this->dc_type->AdvancedSearch->SearchOperator = @$filter["z_dc_type"];
		$this->dc_type->AdvancedSearch->SearchCondition = @$filter["v_dc_type"];
		$this->dc_type->AdvancedSearch->SearchValue2 = @$filter["y_dc_type"];
		$this->dc_type->AdvancedSearch->SearchOperator2 = @$filter["w_dc_type"];
		$this->dc_type->AdvancedSearch->save();

		// Field agency
		$this->agency->AdvancedSearch->SearchValue = @$filter["x_agency"];
		$this->agency->AdvancedSearch->SearchOperator = @$filter["z_agency"];
		$this->agency->AdvancedSearch->SearchCondition = @$filter["v_agency"];
		$this->agency->AdvancedSearch->SearchValue2 = @$filter["y_agency"];
		$this->agency->AdvancedSearch->SearchOperator2 = @$filter["w_agency"];
		$this->agency->AdvancedSearch->save();

		// Field serial_no
		$this->serial_no->AdvancedSearch->SearchValue = @$filter["x_serial_no"];
		$this->serial_no->AdvancedSearch->SearchOperator = @$filter["z_serial_no"];
		$this->serial_no->AdvancedSearch->SearchCondition = @$filter["v_serial_no"];
		$this->serial_no->AdvancedSearch->SearchValue2 = @$filter["y_serial_no"];
		$this->serial_no->AdvancedSearch->SearchOperator2 = @$filter["w_serial_no"];
		$this->serial_no->AdvancedSearch->save();

		// Field book_count
		$this->book_count->AdvancedSearch->SearchValue = @$filter["x_book_count"];
		$this->book_count->AdvancedSearch->SearchOperator = @$filter["z_book_count"];
		$this->book_count->AdvancedSearch->SearchCondition = @$filter["v_book_count"];
		$this->book_count->AdvancedSearch->SearchValue2 = @$filter["y_book_count"];
		$this->book_count->AdvancedSearch->SearchOperator2 = @$filter["w_book_count"];
		$this->book_count->AdvancedSearch->save();

		// Field ticket_name
		$this->ticket_name->AdvancedSearch->SearchValue = @$filter["x_ticket_name"];
		$this->ticket_name->AdvancedSearch->SearchOperator = @$filter["z_ticket_name"];
		$this->ticket_name->AdvancedSearch->SearchCondition = @$filter["v_ticket_name"];
		$this->ticket_name->AdvancedSearch->SearchValue2 = @$filter["y_ticket_name"];
		$this->ticket_name->AdvancedSearch->SearchOperator2 = @$filter["w_ticket_name"];
		$this->ticket_name->AdvancedSearch->save();

		// Field ticket_catagory
		$this->ticket_catagory->AdvancedSearch->SearchValue = @$filter["x_ticket_catagory"];
		$this->ticket_catagory->AdvancedSearch->SearchOperator = @$filter["z_ticket_catagory"];
		$this->ticket_catagory->AdvancedSearch->SearchCondition = @$filter["v_ticket_catagory"];
		$this->ticket_catagory->AdvancedSearch->SearchValue2 = @$filter["y_ticket_catagory"];
		$this->ticket_catagory->AdvancedSearch->SearchOperator2 = @$filter["w_ticket_catagory"];
		$this->ticket_catagory->AdvancedSearch->save();

		// Field no_of_ticket
		$this->no_of_ticket->AdvancedSearch->SearchValue = @$filter["x_no_of_ticket"];
		$this->no_of_ticket->AdvancedSearch->SearchOperator = @$filter["z_no_of_ticket"];
		$this->no_of_ticket->AdvancedSearch->SearchCondition = @$filter["v_no_of_ticket"];
		$this->no_of_ticket->AdvancedSearch->SearchValue2 = @$filter["y_no_of_ticket"];
		$this->no_of_ticket->AdvancedSearch->SearchOperator2 = @$filter["w_no_of_ticket"];
		$this->no_of_ticket->AdvancedSearch->save();

		// Field total_no_of_ticket
		$this->total_no_of_ticket->AdvancedSearch->SearchValue = @$filter["x_total_no_of_ticket"];
		$this->total_no_of_ticket->AdvancedSearch->SearchOperator = @$filter["z_total_no_of_ticket"];
		$this->total_no_of_ticket->AdvancedSearch->SearchCondition = @$filter["v_total_no_of_ticket"];
		$this->total_no_of_ticket->AdvancedSearch->SearchValue2 = @$filter["y_total_no_of_ticket"];
		$this->total_no_of_ticket->AdvancedSearch->SearchOperator2 = @$filter["w_total_no_of_ticket"];
		$this->total_no_of_ticket->AdvancedSearch->save();

		// Field draw_code
		$this->draw_code->AdvancedSearch->SearchValue = @$filter["x_draw_code"];
		$this->draw_code->AdvancedSearch->SearchOperator = @$filter["z_draw_code"];
		$this->draw_code->AdvancedSearch->SearchCondition = @$filter["v_draw_code"];
		$this->draw_code->AdvancedSearch->SearchValue2 = @$filter["y_draw_code"];
		$this->draw_code->AdvancedSearch->SearchOperator2 = @$filter["w_draw_code"];
		$this->draw_code->AdvancedSearch->save();

		// Field draw_date
		$this->draw_date->AdvancedSearch->SearchValue = @$filter["x_draw_date"];
		$this->draw_date->AdvancedSearch->SearchOperator = @$filter["z_draw_date"];
		$this->draw_date->AdvancedSearch->SearchCondition = @$filter["v_draw_date"];
		$this->draw_date->AdvancedSearch->SearchValue2 = @$filter["y_draw_date"];
		$this->draw_date->AdvancedSearch->SearchOperator2 = @$filter["w_draw_date"];
		$this->draw_date->AdvancedSearch->save();

		// Field rate
		$this->rate->AdvancedSearch->SearchValue = @$filter["x_rate"];
		$this->rate->AdvancedSearch->SearchOperator = @$filter["z_rate"];
		$this->rate->AdvancedSearch->SearchCondition = @$filter["v_rate"];
		$this->rate->AdvancedSearch->SearchValue2 = @$filter["y_rate"];
		$this->rate->AdvancedSearch->SearchOperator2 = @$filter["w_rate"];
		$this->rate->AdvancedSearch->save();

		// Field paid_amound
		$this->paid_amound->AdvancedSearch->SearchValue = @$filter["x_paid_amound"];
		$this->paid_amound->AdvancedSearch->SearchOperator = @$filter["z_paid_amound"];
		$this->paid_amound->AdvancedSearch->SearchCondition = @$filter["v_paid_amound"];
		$this->paid_amound->AdvancedSearch->SearchValue2 = @$filter["y_paid_amound"];
		$this->paid_amound->AdvancedSearch->SearchOperator2 = @$filter["w_paid_amound"];
		$this->paid_amound->AdvancedSearch->save();

		// Field pending
		$this->pending->AdvancedSearch->SearchValue = @$filter["x_pending"];
		$this->pending->AdvancedSearch->SearchOperator = @$filter["z_pending"];
		$this->pending->AdvancedSearch->SearchCondition = @$filter["v_pending"];
		$this->pending->AdvancedSearch->SearchValue2 = @$filter["y_pending"];
		$this->pending->AdvancedSearch->SearchOperator2 = @$filter["w_pending"];
		$this->pending->AdvancedSearch->save();

		// Field Total
		$this->Total->AdvancedSearch->SearchValue = @$filter["x_Total"];
		$this->Total->AdvancedSearch->SearchOperator = @$filter["z_Total"];
		$this->Total->AdvancedSearch->SearchCondition = @$filter["v_Total"];
		$this->Total->AdvancedSearch->SearchValue2 = @$filter["y_Total"];
		$this->Total->AdvancedSearch->SearchOperator2 = @$filter["w_Total"];
		$this->Total->AdvancedSearch->save();

		// Field add_user
		$this->add_user->AdvancedSearch->SearchValue = @$filter["x_add_user"];
		$this->add_user->AdvancedSearch->SearchOperator = @$filter["z_add_user"];
		$this->add_user->AdvancedSearch->SearchCondition = @$filter["v_add_user"];
		$this->add_user->AdvancedSearch->SearchValue2 = @$filter["y_add_user"];
		$this->add_user->AdvancedSearch->SearchOperator2 = @$filter["w_add_user"];
		$this->add_user->AdvancedSearch->save();

		// Field Edit_user
		$this->Edit_user->AdvancedSearch->SearchValue = @$filter["x_Edit_user"];
		$this->Edit_user->AdvancedSearch->SearchOperator = @$filter["z_Edit_user"];
		$this->Edit_user->AdvancedSearch->SearchCondition = @$filter["v_Edit_user"];
		$this->Edit_user->AdvancedSearch->SearchValue2 = @$filter["y_Edit_user"];
		$this->Edit_user->AdvancedSearch->SearchOperator2 = @$filter["w_Edit_user"];
		$this->Edit_user->AdvancedSearch->save();

		// Field pending_amount_paid_date
		$this->pending_amount_paid_date->AdvancedSearch->SearchValue = @$filter["x_pending_amount_paid_date"];
		$this->pending_amount_paid_date->AdvancedSearch->SearchOperator = @$filter["z_pending_amount_paid_date"];
		$this->pending_amount_paid_date->AdvancedSearch->SearchCondition = @$filter["v_pending_amount_paid_date"];
		$this->pending_amount_paid_date->AdvancedSearch->SearchValue2 = @$filter["y_pending_amount_paid_date"];
		$this->pending_amount_paid_date->AdvancedSearch->SearchOperator2 = @$filter["w_pending_amount_paid_date"];
		$this->pending_amount_paid_date->AdvancedSearch->save();
		$this->BasicSearch->setKeyword(@$filter[Config("TABLE_BASIC_SEARCH")]);
		$this->BasicSearch->setType(@$filter[Config("TABLE_BASIC_SEARCH_TYPE")]);
	}

	// Advanced search WHERE clause based on QueryString
	protected function advancedSearchWhere($default = FALSE)
	{
		global $Security;
		$where = "";
		if (!$Security->canSearch())
			return "";
		$this->buildSearchSql($where, $this->slno, $default, FALSE); // slno
		$this->buildSearchSql($where, $this->date, $default, FALSE); // date
		$this->buildSearchSql($where, $this->time, $default, FALSE); // time
		$this->buildSearchSql($where, $this->customer_name, $default, FALSE); // customer_name
		$this->buildSearchSql($where, $this->contact, $default, FALSE); // contact
		$this->buildSearchSql($where, $this->dc_type, $default, FALSE); // dc-type
		$this->buildSearchSql($where, $this->agency, $default, FALSE); // agency
		$this->buildSearchSql($where, $this->serial_no, $default, FALSE); // serial_no
		$this->buildSearchSql($where, $this->book_count, $default, FALSE); // book_count
		$this->buildSearchSql($where, $this->ticket_name, $default, FALSE); // ticket_name
		$this->buildSearchSql($where, $this->ticket_catagory, $default, FALSE); // ticket_catagory
		$this->buildSearchSql($where, $this->no_of_ticket, $default, FALSE); // no_of_ticket
		$this->buildSearchSql($where, $this->total_no_of_ticket, $default, FALSE); // total_no_of_ticket
		$this->buildSearchSql($where, $this->draw_code, $default, FALSE); // draw_code
		$this->buildSearchSql($where, $this->draw_date, $default, FALSE); // draw_date
		$this->buildSearchSql($where, $this->rate, $default, FALSE); // rate
		$this->buildSearchSql($where, $this->paid_amound, $default, FALSE); // paid_amound
		$this->buildSearchSql($where, $this->pending, $default, FALSE); // pending
		$this->buildSearchSql($where, $this->Total, $default, FALSE); // Total
		$this->buildSearchSql($where, $this->add_user, $default, FALSE); // add_user
		$this->buildSearchSql($where, $this->Edit_user, $default, FALSE); // Edit_user
		$this->buildSearchSql($where, $this->pending_amount_paid_date, $default, FALSE); // pending_amount_paid_date

		// Set up search parm
		if (!$default && $where != "" && in_array($this->Command, ["", "reset", "resetall"])) {
			$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->slno->AdvancedSearch->save(); // slno
			$this->date->AdvancedSearch->save(); // date
			$this->time->AdvancedSearch->save(); // time
			$this->customer_name->AdvancedSearch->save(); // customer_name
			$this->contact->AdvancedSearch->save(); // contact
			$this->dc_type->AdvancedSearch->save(); // dc-type
			$this->agency->AdvancedSearch->save(); // agency
			$this->serial_no->AdvancedSearch->save(); // serial_no
			$this->book_count->AdvancedSearch->save(); // book_count
			$this->ticket_name->AdvancedSearch->save(); // ticket_name
			$this->ticket_catagory->AdvancedSearch->save(); // ticket_catagory
			$this->no_of_ticket->AdvancedSearch->save(); // no_of_ticket
			$this->total_no_of_ticket->AdvancedSearch->save(); // total_no_of_ticket
			$this->draw_code->AdvancedSearch->save(); // draw_code
			$this->draw_date->AdvancedSearch->save(); // draw_date
			$this->rate->AdvancedSearch->save(); // rate
			$this->paid_amound->AdvancedSearch->save(); // paid_amound
			$this->pending->AdvancedSearch->save(); // pending
			$this->Total->AdvancedSearch->save(); // Total
			$this->add_user->AdvancedSearch->save(); // add_user
			$this->Edit_user->AdvancedSearch->save(); // Edit_user
			$this->pending_amount_paid_date->AdvancedSearch->save(); // pending_amount_paid_date
		}
		return $where;
	}

	// Build search SQL
	protected function buildSearchSql(&$where, &$fld, $default, $multiValue)
	{
		$fldParm = $fld->Param;
		$fldVal = ($default) ? $fld->AdvancedSearch->SearchValueDefault : $fld->AdvancedSearch->SearchValue;
		$fldOpr = ($default) ? $fld->AdvancedSearch->SearchOperatorDefault : $fld->AdvancedSearch->SearchOperator;
		$fldCond = ($default) ? $fld->AdvancedSearch->SearchConditionDefault : $fld->AdvancedSearch->SearchCondition;
		$fldVal2 = ($default) ? $fld->AdvancedSearch->SearchValue2Default : $fld->AdvancedSearch->SearchValue2;
		$fldOpr2 = ($default) ? $fld->AdvancedSearch->SearchOperator2Default : $fld->AdvancedSearch->SearchOperator2;
		$wrk = "";
		if (is_array($fldVal))
			$fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
		if (is_array($fldVal2))
			$fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
		$fldOpr = strtoupper(trim($fldOpr));
		if ($fldOpr == "")
			$fldOpr = "=";
		$fldOpr2 = strtoupper(trim($fldOpr2));
		if ($fldOpr2 == "")
			$fldOpr2 = "=";
		if (Config("SEARCH_MULTI_VALUE_OPTION") == 1 || !IsMultiSearchOperator($fldOpr))
			$multiValue = FALSE;
		if ($multiValue) {
			$wrk1 = ($fldVal != "") ? GetMultiSearchSql($fld, $fldOpr, $fldVal, $this->Dbid) : ""; // Field value 1
			$wrk2 = ($fldVal2 != "") ? GetMultiSearchSql($fld, $fldOpr2, $fldVal2, $this->Dbid) : ""; // Field value 2
			$wrk = $wrk1; // Build final SQL
			if ($wrk2 != "")
				$wrk = ($wrk != "") ? "($wrk) $fldCond ($wrk2)" : $wrk2;
		} else {
			$fldVal = $this->convertSearchValue($fld, $fldVal);
			$fldVal2 = $this->convertSearchValue($fld, $fldVal2);
			$wrk = GetSearchSql($fld, $fldVal, $fldOpr, $fldCond, $fldVal2, $fldOpr2, $this->Dbid);
		}
		AddFilter($where, $wrk);
	}

	// Convert search value
	protected function convertSearchValue(&$fld, $fldVal)
	{
		if ($fldVal == Config("NULL_VALUE") || $fldVal == Config("NOT_NULL_VALUE"))
			return $fldVal;
		$value = $fldVal;
		if ($fld->isBoolean()) {
			if ($fldVal != "")
				$value = (SameText($fldVal, "1") || SameText($fldVal, "y") || SameText($fldVal, "t")) ? $fld->TrueValue : $fld->FalseValue;
		} elseif ($fld->DataType == DATATYPE_DATE || $fld->DataType == DATATYPE_TIME) {
			if ($fldVal != "")
				$value = UnFormatDateTime($fldVal, $fld->DateTimeFormat);
		}
		return $value;
	}

	// Return basic search SQL
	protected function basicSearchSql($arKeywords, $type)
	{
		$where = "";
		$this->buildBasicSearchSql($where, $this->slno, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->customer_name, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->contact, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->dc_type, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->agency, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->serial_no, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->ticket_name, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->ticket_catagory, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->draw_code, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->draw_date, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->add_user, $arKeywords, $type);
		return $where;
	}

	// Build basic search SQL
	protected function buildBasicSearchSql(&$where, &$fld, $arKeywords, $type)
	{
		$defCond = ($type == "OR") ? "OR" : "AND";
		$arSql = []; // Array for SQL parts
		$arCond = []; // Array for search conditions
		$cnt = count($arKeywords);
		$j = 0; // Number of SQL parts
		for ($i = 0; $i < $cnt; $i++) {
			$keyword = $arKeywords[$i];
			$keyword = trim($keyword);
			if (Config("BASIC_SEARCH_IGNORE_PATTERN") != "") {
				$keyword = preg_replace(Config("BASIC_SEARCH_IGNORE_PATTERN"), "\\", $keyword);
				$ar = explode("\\", $keyword);
			} else {
				$ar = [$keyword];
			}
			foreach ($ar as $keyword) {
				if ($keyword != "") {
					$wrk = "";
					if ($keyword == "OR" && $type == "") {
						if ($j > 0)
							$arCond[$j - 1] = "OR";
					} elseif ($keyword == Config("NULL_VALUE")) {
						$wrk = $fld->Expression . " IS NULL";
					} elseif ($keyword == Config("NOT_NULL_VALUE")) {
						$wrk = $fld->Expression . " IS NOT NULL";
					} elseif ($fld->IsVirtual) {
						$wrk = $fld->VirtualExpression . Like(QuotedValue("%" . $keyword . "%", DATATYPE_STRING, $this->Dbid), $this->Dbid);
					} elseif ($fld->DataType != DATATYPE_NUMBER || is_numeric($keyword)) {
						$wrk = $fld->BasicSearchExpression . Like(QuotedValue("%" . $keyword . "%", DATATYPE_STRING, $this->Dbid), $this->Dbid);
					}
					if ($wrk != "") {
						$arSql[$j] = $wrk;
						$arCond[$j] = $defCond;
						$j += 1;
					}
				}
			}
		}
		$cnt = count($arSql);
		$quoted = FALSE;
		$sql = "";
		if ($cnt > 0) {
			for ($i = 0; $i < $cnt - 1; $i++) {
				if ($arCond[$i] == "OR") {
					if (!$quoted)
						$sql .= "(";
					$quoted = TRUE;
				}
				$sql .= $arSql[$i];
				if ($quoted && $arCond[$i] != "OR") {
					$sql .= ")";
					$quoted = FALSE;
				}
				$sql .= " " . $arCond[$i] . " ";
			}
			$sql .= $arSql[$cnt - 1];
			if ($quoted)
				$sql .= ")";
		}
		if ($sql != "") {
			if ($where != "")
				$where .= " OR ";
			$where .= "(" . $sql . ")";
		}
	}

	// Return basic search WHERE clause based on search keyword and type
	protected function basicSearchWhere($default = FALSE)
	{
		global $Security;
		$searchStr = "";
		if (!$Security->canSearch())
			return "";
		$searchKeyword = ($default) ? $this->BasicSearch->KeywordDefault : $this->BasicSearch->Keyword;
		$searchType = ($default) ? $this->BasicSearch->TypeDefault : $this->BasicSearch->Type;

		// Get search SQL
		if ($searchKeyword != "") {
			$ar = $this->BasicSearch->keywordList($default);

			// Search keyword in any fields
			if (($searchType == "OR" || $searchType == "AND") && $this->BasicSearch->BasicSearchAnyFields) {
				foreach ($ar as $keyword) {
					if ($keyword != "") {
						if ($searchStr != "")
							$searchStr .= " " . $searchType . " ";
						$searchStr .= "(" . $this->basicSearchSql([$keyword], $searchType) . ")";
					}
				}
			} else {
				$searchStr = $this->basicSearchSql($ar, $searchType);
			}
			if (!$default && in_array($this->Command, ["", "reset", "resetall"]))
				$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->BasicSearch->setKeyword($searchKeyword);
			$this->BasicSearch->setType($searchType);
		}
		return $searchStr;
	}

	// Check if search parm exists
	protected function checkSearchParms()
	{

		// Check basic search
		if ($this->BasicSearch->issetSession())
			return TRUE;
		if ($this->slno->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->date->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->time->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->customer_name->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->contact->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->dc_type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->agency->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->serial_no->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->book_count->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->ticket_name->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->ticket_catagory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->no_of_ticket->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->total_no_of_ticket->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->draw_code->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->draw_date->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->rate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->paid_amound->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->pending->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->Total->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->add_user->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->Edit_user->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->pending_amount_paid_date->AdvancedSearch->issetSession())
			return TRUE;
		return FALSE;
	}

	// Clear all search parameters
	protected function resetSearchParms()
	{

		// Clear search WHERE clause
		$this->SearchWhere = "";
		$this->setSearchWhere($this->SearchWhere);

		// Clear basic search parameters
		$this->resetBasicSearchParms();

		// Clear advanced search parameters
		$this->resetAdvancedSearchParms();
	}

	// Load advanced search default values
	protected function loadAdvancedSearchDefault()
	{
		return FALSE;
	}

	// Clear all basic search parameters
	protected function resetBasicSearchParms()
	{
		$this->BasicSearch->unsetSession();
	}

	// Clear all advanced search parameters
	protected function resetAdvancedSearchParms()
	{
		$this->slno->AdvancedSearch->unsetSession();
		$this->date->AdvancedSearch->unsetSession();
		$this->time->AdvancedSearch->unsetSession();
		$this->customer_name->AdvancedSearch->unsetSession();
		$this->contact->AdvancedSearch->unsetSession();
		$this->dc_type->AdvancedSearch->unsetSession();
		$this->agency->AdvancedSearch->unsetSession();
		$this->serial_no->AdvancedSearch->unsetSession();
		$this->book_count->AdvancedSearch->unsetSession();
		$this->ticket_name->AdvancedSearch->unsetSession();
		$this->ticket_catagory->AdvancedSearch->unsetSession();
		$this->no_of_ticket->AdvancedSearch->unsetSession();
		$this->total_no_of_ticket->AdvancedSearch->unsetSession();
		$this->draw_code->AdvancedSearch->unsetSession();
		$this->draw_date->AdvancedSearch->unsetSession();
		$this->rate->AdvancedSearch->unsetSession();
		$this->paid_amound->AdvancedSearch->unsetSession();
		$this->pending->AdvancedSearch->unsetSession();
		$this->Total->AdvancedSearch->unsetSession();
		$this->add_user->AdvancedSearch->unsetSession();
		$this->Edit_user->AdvancedSearch->unsetSession();
		$this->pending_amount_paid_date->AdvancedSearch->unsetSession();
	}

	// Restore all search parameters
	protected function restoreSearchParms()
	{
		$this->RestoreSearch = TRUE;

		// Restore basic search values
		$this->BasicSearch->load();

		// Restore advanced search values
		$this->slno->AdvancedSearch->load();
		$this->date->AdvancedSearch->load();
		$this->time->AdvancedSearch->load();
		$this->customer_name->AdvancedSearch->load();
		$this->contact->AdvancedSearch->load();
		$this->dc_type->AdvancedSearch->load();
		$this->agency->AdvancedSearch->load();
		$this->serial_no->AdvancedSearch->load();
		$this->book_count->AdvancedSearch->load();
		$this->ticket_name->AdvancedSearch->load();
		$this->ticket_catagory->AdvancedSearch->load();
		$this->no_of_ticket->AdvancedSearch->load();
		$this->total_no_of_ticket->AdvancedSearch->load();
		$this->draw_code->AdvancedSearch->load();
		$this->draw_date->AdvancedSearch->load();
		$this->rate->AdvancedSearch->load();
		$this->paid_amound->AdvancedSearch->load();
		$this->pending->AdvancedSearch->load();
		$this->Total->AdvancedSearch->load();
		$this->add_user->AdvancedSearch->load();
		$this->Edit_user->AdvancedSearch->load();
		$this->pending_amount_paid_date->AdvancedSearch->load();
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->updateSort($this->slno); // slno
			$this->updateSort($this->date); // date
			$this->updateSort($this->time); // time
			$this->updateSort($this->customer_name); // customer_name
			$this->updateSort($this->contact); // contact
			$this->updateSort($this->dc_type); // dc-type
			$this->updateSort($this->agency); // agency
			$this->updateSort($this->serial_no); // serial_no
			$this->updateSort($this->ticket_name); // ticket_name
			$this->updateSort($this->ticket_catagory); // ticket_catagory
			$this->updateSort($this->no_of_ticket); // no_of_ticket
			$this->updateSort($this->total_no_of_ticket); // total_no_of_ticket
			$this->updateSort($this->draw_date); // draw_date
			$this->updateSort($this->paid_amound); // paid_amound
			$this->updateSort($this->pending); // pending
			$this->updateSort($this->Total); // Total
			$this->updateSort($this->add_user); // add_user
			$this->updateSort($this->Edit_user); // Edit_user
			$this->updateSort($this->pending_amount_paid_date); // pending_amount_paid_date
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
				$this->slno->setSort("DESC");
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset search criteria
			if ($this->Command == "reset" || $this->Command == "resetall")
				$this->resetSearchParms();

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
				$this->setSessionOrderByList($orderBy);
				$this->slno->setSort("");
				$this->date->setSort("");
				$this->time->setSort("");
				$this->customer_name->setSort("");
				$this->contact->setSort("");
				$this->dc_type->setSort("");
				$this->agency->setSort("");
				$this->serial_no->setSort("");
				$this->ticket_name->setSort("");
				$this->ticket_catagory->setSort("");
				$this->no_of_ticket->setSort("");
				$this->total_no_of_ticket->setSort("");
				$this->draw_date->setSort("");
				$this->paid_amound->setSort("");
				$this->pending->setSort("");
				$this->Total->setSort("");
				$this->add_user->setSort("");
				$this->Edit_user->setSort("");
				$this->pending_amount_paid_date->setSort("");
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->add("view");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canView();
		$item->OnLeft = FALSE;

		// "edit"
		$item = &$this->ListOptions->add("edit");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canEdit();
		$item->OnLeft = FALSE;

		// "copy"
		$item = &$this->ListOptions->add("copy");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canAdd();
		$item->OnLeft = FALSE;

		// "delete"
		$item = &$this->ListOptions->add("delete");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canDelete();
		$item->OnLeft = FALSE;

		// List actions
		$item = &$this->ListOptions->add("listactions");
		$item->CssClass = "text-nowrap";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;
		$item->ShowInButtonGroup = FALSE;
		$item->ShowInDropDown = FALSE;

		// "checkbox"
		$item = &$this->ListOptions->add("checkbox");
		$item->Visible = FALSE;
		$item->OnLeft = FALSE;
		$item->Header = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" name=\"key\" id=\"key\" class=\"custom-control-input\" onclick=\"ew.selectAllKey(this);\"><label class=\"custom-control-label\" for=\"key\"></label></div>";
		$item->ShowInDropDown = FALSE;
		$item->ShowInButtonGroup = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$this->setupListOptionsExt();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// "view"
		$opt = $this->ListOptions["view"];
		$viewcaption = HtmlTitle($Language->phrase("ViewLink"));
		if ($Security->canView()) {
			$opt->Body = "<a class=\"ew-row-link ew-view\" title=\"" . $viewcaption . "\" data-caption=\"" . $viewcaption . "\" href=\"" . HtmlEncode($this->ViewUrl) . "\">" . $Language->phrase("ViewLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "edit"
		$opt = $this->ListOptions["edit"];
		$editcaption = HtmlTitle($Language->phrase("EditLink"));
		if ($Security->canEdit()) {
			$opt->Body = "<a class=\"ew-row-link ew-edit\" title=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" href=\"" . HtmlEncode($this->EditUrl) . "\">" . $Language->phrase("EditLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "copy"
		$opt = $this->ListOptions["copy"];
		$copycaption = HtmlTitle($Language->phrase("CopyLink"));
		if ($Security->canAdd()) {
			$opt->Body = "<a class=\"ew-row-link ew-copy\" title=\"" . $copycaption . "\" data-caption=\"" . $copycaption . "\" href=\"" . HtmlEncode($this->CopyUrl) . "\">" . $Language->phrase("CopyLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "delete"
		$opt = $this->ListOptions["delete"];
		if ($Security->canDelete())
			$opt->Body = "<a class=\"ew-row-link ew-delete\"" . "" . " title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" href=\"" . HtmlEncode($this->DeleteUrl) . "\">" . $Language->phrase("DeleteLink") . "</a>";
		else
			$opt->Body = "";

		// Set up list action buttons
		$opt = $this->ListOptions["listactions"];
		if ($opt && !$this->isExport() && !$this->CurrentAction) {
			$body = "";
			$links = [];
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_SINGLE && $listaction->Allow) {
					$action = $listaction->Action;
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode(str_replace(" ew-icon", "", $listaction->Icon)) . "\" data-caption=\"" . HtmlTitle($caption) . "\"></i> " : "";
					$links[] = "<li><a class=\"dropdown-item ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a></li>";
					if (count($links) == 1) // Single button
						$body = "<a class=\"ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a>";
				}
			}
			if (count($links) > 1) { // More than one buttons, use dropdown
				$body = "<button class=\"dropdown-toggle btn btn-default ew-actions\" title=\"" . HtmlTitle($Language->phrase("ListActionButton")) . "\" data-toggle=\"dropdown\">" . $Language->phrase("ListActionButton") . "</button>";
				$content = "";
				foreach ($links as $link)
					$content .= "<li>" . $link . "</li>";
				$body .= "<ul class=\"dropdown-menu" . ($opt->OnLeft ? "" : " dropdown-menu-right") . "\">". $content . "</ul>";
				$body = "<div class=\"btn-group btn-group-sm\">" . $body . "</div>";
			}
			if (count($links) > 0) {
				$opt->Body = $body;
				$opt->Visible = TRUE;
			}
		}

		// "checkbox"
		$opt = $this->ListOptions["checkbox"];
		$opt->Body = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" id=\"key_m_" . $this->RowCount . "\" name=\"key_m[]\" class=\"custom-control-input ew-multi-select\" value=\"" . HtmlEncode($this->slno->CurrentValue) . "\" onclick=\"ew.clickMultiCheckbox(event);\"><label class=\"custom-control-label\" for=\"key_m_" . $this->RowCount . "\"></label></div>";
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		$option = $options["addedit"];

		// Add
		$item = &$option->add("add");
		$addcaption = HtmlTitle($Language->phrase("AddLink"));
		$item->Body = "<a class=\"ew-add-edit ew-add\" title=\"" . $addcaption . "\" data-caption=\"" . $addcaption . "\" href=\"" . HtmlEncode($this->AddUrl) . "\">" . $Language->phrase("AddLink") . "</a>";
		$item->Visible = $this->AddUrl != "" && $Security->canAdd();
		$option = $options["action"];

		// Set up options default
		foreach ($options as $option) {
			$option->UseDropDownButton = FALSE;
			$option->UseButtonGroup = TRUE;

			//$option->ButtonClass = ""; // Class for button group
			$item = &$option->add($option->GroupOptionName);
			$item->Body = "";
			$item->Visible = FALSE;
		}
		$options["addedit"]->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$options["detail"]->DropDownButtonPhrase = $Language->phrase("ButtonDetails");
		$options["action"]->DropDownButtonPhrase = $Language->phrase("ButtonActions");

		// Filter button
		$item = &$this->FilterOptions->add("savecurrentfilter");
		$item->Body = "<a class=\"ew-save-filter\" data-form=\"fsaled_booklistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("SaveCurrentFilter") . "</a>";
		$item->Visible = TRUE;
		$item = &$this->FilterOptions->add("deletefilter");
		$item->Body = "<a class=\"ew-delete-filter\" data-form=\"fsaled_booklistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("DeleteFilter") . "</a>";
		$item->Visible = TRUE;
		$this->FilterOptions->UseDropDownButton = TRUE;
		$this->FilterOptions->UseButtonGroup = !$this->FilterOptions->UseDropDownButton;
		$this->FilterOptions->DropDownButtonPhrase = $Language->phrase("Filters");

		// Add group option item
		$item = &$this->FilterOptions->add($this->FilterOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
			$option = $options["action"];

			// Set up list action buttons
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_MULTIPLE) {
					$item = &$option->add("custom_" . $listaction->Action);
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode($listaction->Icon) . "\" data-caption=\"" . HtmlEncode($caption) . "\"></i> " . $caption : $caption;
					$item->Body = "<a class=\"ew-action ew-list-action\" title=\"" . HtmlEncode($caption) . "\" data-caption=\"" . HtmlEncode($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({f:document.fsaled_booklist}," . $listaction->toJson(TRUE) . "));\">" . $icon . "</a>";
					$item->Visible = $listaction->Allow;
				}
			}

			// Hide grid edit and other options
			if ($this->TotalRecords <= 0) {
				$option = $options["addedit"];
				$item = $option["gridedit"];
				if ($item)
					$item->Visible = FALSE;
				$option = $options["action"];
				$option->hideAllOptions();
			}
	}

	// Process list action
	protected function processListAction()
	{
		global $Language, $Security;
		$userlist = "";
		$user = "";
		$filter = $this->getFilterFromRecordKeys();
		$userAction = Post("useraction", "");
		if ($filter != "" && $userAction != "") {

			// Check permission first
			$actionCaption = $userAction;
			if (array_key_exists($userAction, $this->ListActions->Items)) {
				$actionCaption = $this->ListActions[$userAction]->Caption;
				if (!$this->ListActions[$userAction]->Allow) {
					$errmsg = str_replace('%s', $actionCaption, $Language->phrase("CustomActionNotAllowed"));
					if (Post("ajax") == $userAction) // Ajax
						echo "<p class=\"text-danger\">" . $errmsg . "</p>";
					else
						$this->setFailureMessage($errmsg);
					return FALSE;
				}
			}
			$this->CurrentFilter = $filter;
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$rs = $conn->execute($sql);
			$conn->raiseErrorFn = "";
			$this->CurrentAction = $userAction;

			// Call row action event
			if ($rs && !$rs->EOF) {
				$conn->beginTrans();
				$this->SelectedCount = $rs->RecordCount();
				$this->SelectedIndex = 0;
				while (!$rs->EOF) {
					$this->SelectedIndex++;
					$row = $rs->fields;
					$processed = $this->Row_CustomAction($userAction, $row);
					if (!$processed)
						break;
					$rs->moveNext();
				}
				if ($processed) {
					$conn->commitTrans(); // Commit the changes
					if ($this->getSuccessMessage() == "" && !ob_get_length()) // No output
						$this->setSuccessMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionCompleted"))); // Set up success message
				} else {
					$conn->rollbackTrans(); // Rollback changes

					// Set up error message
					if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

						// Use the message, do nothing
					} elseif ($this->CancelMessage != "") {
						$this->setFailureMessage($this->CancelMessage);
						$this->CancelMessage = "";
					} else {
						$this->setFailureMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionFailed")));
					}
				}
			}
			if ($rs)
				$rs->close();
			$this->CurrentAction = ""; // Clear action
			if (Post("ajax") == $userAction) { // Ajax
				if ($this->getSuccessMessage() != "") {
					echo "<p class=\"text-success\">" . $this->getSuccessMessage() . "</p>";
					$this->clearSuccessMessage(); // Clear message
				}
				if ($this->getFailureMessage() != "") {
					echo "<p class=\"text-danger\">" . $this->getFailureMessage() . "</p>";
					$this->clearFailureMessage(); // Clear message
				}
				return TRUE;
			}
		}
		return FALSE; // Not ajax request
	}

	// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{
	}

	// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
	}

	// Load basic search values
	protected function loadBasicSearchValues()
	{
		$this->BasicSearch->setKeyword(Get(Config("TABLE_BASIC_SEARCH"), ""), FALSE);
		if ($this->BasicSearch->Keyword != "" && $this->Command == "")
			$this->Command = "search";
		$this->BasicSearch->setType(Get(Config("TABLE_BASIC_SEARCH_TYPE"), ""), FALSE);
	}

	// Load search values for validation
	protected function loadSearchValues()
	{

		// Load search values
		$got = FALSE;

		// slno
		if (!$this->isAddOrEdit() && $this->slno->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->slno->AdvancedSearch->SearchValue != "" || $this->slno->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// date
		if (!$this->isAddOrEdit() && $this->date->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->date->AdvancedSearch->SearchValue != "" || $this->date->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// time
		if (!$this->isAddOrEdit() && $this->time->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->time->AdvancedSearch->SearchValue != "" || $this->time->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// customer_name
		if (!$this->isAddOrEdit() && $this->customer_name->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->customer_name->AdvancedSearch->SearchValue != "" || $this->customer_name->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// contact
		if (!$this->isAddOrEdit() && $this->contact->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->contact->AdvancedSearch->SearchValue != "" || $this->contact->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// dc-type
		if (!$this->isAddOrEdit() && $this->dc_type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->dc_type->AdvancedSearch->SearchValue != "" || $this->dc_type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// agency
		if (!$this->isAddOrEdit() && $this->agency->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->agency->AdvancedSearch->SearchValue != "" || $this->agency->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// serial_no
		if (!$this->isAddOrEdit() && $this->serial_no->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->serial_no->AdvancedSearch->SearchValue != "" || $this->serial_no->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// book_count
		if (!$this->isAddOrEdit() && $this->book_count->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->book_count->AdvancedSearch->SearchValue != "" || $this->book_count->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// ticket_name
		if (!$this->isAddOrEdit() && $this->ticket_name->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->ticket_name->AdvancedSearch->SearchValue != "" || $this->ticket_name->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// ticket_catagory
		if (!$this->isAddOrEdit() && $this->ticket_catagory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->ticket_catagory->AdvancedSearch->SearchValue != "" || $this->ticket_catagory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// no_of_ticket
		if (!$this->isAddOrEdit() && $this->no_of_ticket->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->no_of_ticket->AdvancedSearch->SearchValue != "" || $this->no_of_ticket->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// total_no_of_ticket
		if (!$this->isAddOrEdit() && $this->total_no_of_ticket->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->total_no_of_ticket->AdvancedSearch->SearchValue != "" || $this->total_no_of_ticket->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// draw_code
		if (!$this->isAddOrEdit() && $this->draw_code->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->draw_code->AdvancedSearch->SearchValue != "" || $this->draw_code->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// draw_date
		if (!$this->isAddOrEdit() && $this->draw_date->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->draw_date->AdvancedSearch->SearchValue != "" || $this->draw_date->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// rate
		if (!$this->isAddOrEdit() && $this->rate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->rate->AdvancedSearch->SearchValue != "" || $this->rate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// paid_amound
		if (!$this->isAddOrEdit() && $this->paid_amound->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->paid_amound->AdvancedSearch->SearchValue != "" || $this->paid_amound->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// pending
		if (!$this->isAddOrEdit() && $this->pending->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->pending->AdvancedSearch->SearchValue != "" || $this->pending->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// Total
		if (!$this->isAddOrEdit() && $this->Total->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->Total->AdvancedSearch->SearchValue != "" || $this->Total->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// add_user
		if (!$this->isAddOrEdit() && $this->add_user->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->add_user->AdvancedSearch->SearchValue != "" || $this->add_user->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// Edit_user
		if (!$this->isAddOrEdit() && $this->Edit_user->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->Edit_user->AdvancedSearch->SearchValue != "" || $this->Edit_user->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// pending_amount_paid_date
		if (!$this->isAddOrEdit() && $this->pending_amount_paid_date->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->pending_amount_paid_date->AdvancedSearch->SearchValue != "" || $this->pending_amount_paid_date->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}
		return $got;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderByList())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->slno->setDbValue($row['slno']);
		$this->date->setDbValue($row['date']);
		$this->time->setDbValue($row['time']);
		$this->customer_name->setDbValue($row['customer_name']);
		if (array_key_exists('EV__customer_name', $rs->fields)) {
			$this->customer_name->VirtualValue = $rs->fields('EV__customer_name'); // Set up virtual field value
		} else {
			$this->customer_name->VirtualValue = ""; // Clear value
		}
		$this->contact->setDbValue($row['contact']);
		$this->dc_type->setDbValue($row['dc-type']);
		$this->agency->setDbValue($row['agency']);
		$this->serial_no->setDbValue($row['serial_no']);
		$this->book_count->setDbValue($row['book_count']);
		$this->ticket_name->setDbValue($row['ticket_name']);
		$this->ticket_catagory->setDbValue($row['ticket_catagory']);
		$this->no_of_ticket->setDbValue($row['no_of_ticket']);
		$this->total_no_of_ticket->setDbValue($row['total_no_of_ticket']);
		$this->draw_code->setDbValue($row['draw_code']);
		$this->draw_date->setDbValue($row['draw_date']);
		$this->rate->setDbValue($row['rate']);
		$this->paid_amound->setDbValue($row['paid_amound']);
		$this->pending->setDbValue($row['pending']);
		$this->Total->setDbValue($row['Total']);
		$this->add_user->setDbValue($row['add_user']);
		$this->Edit_user->setDbValue($row['Edit_user']);
		$this->pending_amount_paid_date->setDbValue($row['pending_amount_paid_date']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['slno'] = NULL;
		$row['date'] = NULL;
		$row['time'] = NULL;
		$row['customer_name'] = NULL;
		$row['contact'] = NULL;
		$row['dc-type'] = NULL;
		$row['agency'] = NULL;
		$row['serial_no'] = NULL;
		$row['book_count'] = NULL;
		$row['ticket_name'] = NULL;
		$row['ticket_catagory'] = NULL;
		$row['no_of_ticket'] = NULL;
		$row['total_no_of_ticket'] = NULL;
		$row['draw_code'] = NULL;
		$row['draw_date'] = NULL;
		$row['rate'] = NULL;
		$row['paid_amound'] = NULL;
		$row['pending'] = NULL;
		$row['Total'] = NULL;
		$row['add_user'] = NULL;
		$row['Edit_user'] = NULL;
		$row['pending_amount_paid_date'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("slno")) != "")
			$this->slno->OldValue = $this->getKey("slno"); // slno
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->InlineEditUrl = $this->getInlineEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->InlineCopyUrl = $this->getInlineCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Convert decimal values if posted back
		if ($this->paid_amound->FormValue == $this->paid_amound->CurrentValue && is_numeric(ConvertToFloatString($this->paid_amound->CurrentValue)))
			$this->paid_amound->CurrentValue = ConvertToFloatString($this->paid_amound->CurrentValue);

		// Convert decimal values if posted back
		if ($this->pending->FormValue == $this->pending->CurrentValue && is_numeric(ConvertToFloatString($this->pending->CurrentValue)))
			$this->pending->CurrentValue = ConvertToFloatString($this->pending->CurrentValue);

		// Convert decimal values if posted back
		if ($this->Total->FormValue == $this->Total->CurrentValue && is_numeric(ConvertToFloatString($this->Total->CurrentValue)))
			$this->Total->CurrentValue = ConvertToFloatString($this->Total->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// slno
		// date
		// time
		// customer_name
		// contact
		// dc-type
		// agency
		// serial_no
		// book_count
		// ticket_name
		// ticket_catagory
		// no_of_ticket
		// total_no_of_ticket
		// draw_code
		// draw_date
		// rate
		// paid_amound
		// pending
		// Total
		// add_user
		// Edit_user
		// pending_amount_paid_date
		// Accumulate aggregate value

		if ($this->RowType != ROWTYPE_AGGREGATEINIT && $this->RowType != ROWTYPE_AGGREGATE) {
			$this->slno->Count++; // Increment count
			if (is_numeric($this->total_no_of_ticket->CurrentValue))
				$this->total_no_of_ticket->Total += $this->total_no_of_ticket->CurrentValue; // Accumulate total
			if (is_numeric($this->paid_amound->CurrentValue))
				$this->paid_amound->Total += $this->paid_amound->CurrentValue; // Accumulate total
			if (is_numeric($this->pending->CurrentValue))
				$this->pending->Total += $this->pending->CurrentValue; // Accumulate total
			if (is_numeric($this->Total->CurrentValue))
				$this->Total->Total += $this->Total->CurrentValue; // Accumulate total
		}
		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// slno
			$this->slno->ViewValue = $this->slno->CurrentValue;
			$this->slno->ViewCustomAttributes = "";

			// date
			$this->date->ViewValue = $this->date->CurrentValue;
			$this->date->ViewValue = FormatDateTime($this->date->ViewValue, 7);
			$this->date->ViewCustomAttributes = "";

			// time
			$this->time->ViewValue = $this->time->CurrentValue;
			$this->time->ViewValue = FormatDateTime($this->time->ViewValue, 3);
			$this->time->ViewCustomAttributes = "";

			// customer_name
			if ($this->customer_name->VirtualValue != "") {
				$this->customer_name->ViewValue = $this->customer_name->VirtualValue;
			} else {
				$curVal = strval($this->customer_name->CurrentValue);
				if ($curVal != "") {
					$this->customer_name->ViewValue = $this->customer_name->lookupCacheOption($curVal);
					if ($this->customer_name->ViewValue === NULL) { // Lookup from database
						$filterWrk = "`customer_name`" . SearchString("=", $curVal, DATATYPE_STRING, "");
						$sqlWrk = $this->customer_name->Lookup->getSql(FALSE, $filterWrk, '', $this);
						$rswrk = Conn()->execute($sqlWrk);
						if ($rswrk && !$rswrk->EOF) { // Lookup values found
							$arwrk = [];
							$arwrk[1] = $rswrk->fields('df');
							$this->customer_name->ViewValue = $this->customer_name->displayValue($arwrk);
							$rswrk->Close();
						} else {
							$this->customer_name->ViewValue = $this->customer_name->CurrentValue;
						}
					}
				} else {
					$this->customer_name->ViewValue = NULL;
				}
			}
			$this->customer_name->ViewCustomAttributes = "";

			// contact
			$this->contact->ViewValue = $this->contact->CurrentValue;
			$this->contact->ViewCustomAttributes = "";

			// dc-type
			$curVal = strval($this->dc_type->CurrentValue);
			if ($curVal != "") {
				$this->dc_type->ViewValue = $this->dc_type->lookupCacheOption($curVal);
				if ($this->dc_type->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`dc-type`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->dc_type->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->dc_type->ViewValue = $this->dc_type->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->dc_type->ViewValue = $this->dc_type->CurrentValue;
					}
				}
			} else {
				$this->dc_type->ViewValue = NULL;
			}
			$this->dc_type->ViewCustomAttributes = "";

			// agency
			$curVal = strval($this->agency->CurrentValue);
			if ($curVal != "") {
				$this->agency->ViewValue = $this->agency->lookupCacheOption($curVal);
				if ($this->agency->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`agency_number`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->agency->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->agency->ViewValue = $this->agency->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->agency->ViewValue = $this->agency->CurrentValue;
					}
				}
			} else {
				$this->agency->ViewValue = NULL;
			}
			$this->agency->ViewCustomAttributes = "";

			// serial_no
			$this->serial_no->ViewValue = $this->serial_no->CurrentValue;
			$this->serial_no->ViewCustomAttributes = "";

			// book_count
			$this->book_count->ViewValue = $this->book_count->CurrentValue;
			$this->book_count->ViewValue = FormatNumber($this->book_count->ViewValue, 0, -2, -2, -2);
			$this->book_count->ViewCustomAttributes = "";

			// ticket_name
			$curVal = strval($this->ticket_name->CurrentValue);
			if ($curVal != "") {
				$this->ticket_name->ViewValue = $this->ticket_name->lookupCacheOption($curVal);
				if ($this->ticket_name->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`ticket_name`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->ticket_name->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->ticket_name->ViewValue = $this->ticket_name->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->ticket_name->ViewValue = $this->ticket_name->CurrentValue;
					}
				}
			} else {
				$this->ticket_name->ViewValue = NULL;
			}
			$this->ticket_name->ViewCustomAttributes = "";

			// ticket_catagory
			$curVal = strval($this->ticket_catagory->CurrentValue);
			if ($curVal != "") {
				$this->ticket_catagory->ViewValue = $this->ticket_catagory->lookupCacheOption($curVal);
				if ($this->ticket_catagory->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`ticket_catagory`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->ticket_catagory->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->ticket_catagory->ViewValue = $this->ticket_catagory->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->ticket_catagory->ViewValue = $this->ticket_catagory->CurrentValue;
					}
				}
			} else {
				$this->ticket_catagory->ViewValue = NULL;
			}
			$this->ticket_catagory->ViewCustomAttributes = "";

			// no_of_ticket
			$this->no_of_ticket->ViewValue = $this->no_of_ticket->CurrentValue;
			$curVal = strval($this->no_of_ticket->CurrentValue);
			if ($curVal != "") {
				$this->no_of_ticket->ViewValue = $this->no_of_ticket->lookupCacheOption($curVal);
				if ($this->no_of_ticket->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`no_of_ticket`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->no_of_ticket->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = FormatNumber($rswrk->fields('df'), 0, -2, -2, -2);
						$this->no_of_ticket->ViewValue = $this->no_of_ticket->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->no_of_ticket->ViewValue = $this->no_of_ticket->CurrentValue;
					}
				}
			} else {
				$this->no_of_ticket->ViewValue = NULL;
			}
			$this->no_of_ticket->ViewCustomAttributes = "";

			// total_no_of_ticket
			$this->total_no_of_ticket->ViewValue = $this->total_no_of_ticket->CurrentValue;
			$this->total_no_of_ticket->ViewValue = FormatNumber($this->total_no_of_ticket->ViewValue, 0, -2, -2, -2);
			$this->total_no_of_ticket->ViewCustomAttributes = "";

			// draw_code
			$curVal = strval($this->draw_code->CurrentValue);
			if ($curVal != "") {
				$this->draw_code->ViewValue = $this->draw_code->lookupCacheOption($curVal);
				if ($this->draw_code->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`draw_code`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->draw_code->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->draw_code->ViewValue = $this->draw_code->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->draw_code->ViewValue = $this->draw_code->CurrentValue;
					}
				}
			} else {
				$this->draw_code->ViewValue = NULL;
			}
			$this->draw_code->ViewCustomAttributes = "";

			// draw_date
			$this->draw_date->ViewValue = $this->draw_date->CurrentValue;
			$curVal = strval($this->draw_date->CurrentValue);
			if ($curVal != "") {
				$this->draw_date->ViewValue = $this->draw_date->lookupCacheOption($curVal);
				if ($this->draw_date->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`draw_date`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->draw_date->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->draw_date->ViewValue = $this->draw_date->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->draw_date->ViewValue = $this->draw_date->CurrentValue;
					}
				}
			} else {
				$this->draw_date->ViewValue = NULL;
			}
			$this->draw_date->ViewCustomAttributes = "";

			// rate
			$this->rate->ViewValue = $this->rate->CurrentValue;
			$curVal = strval($this->rate->CurrentValue);
			if ($curVal != "") {
				$this->rate->ViewValue = $this->rate->lookupCacheOption($curVal);
				if ($this->rate->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`rate`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->rate->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = FormatNumber($rswrk->fields('df'), 2, -2, -2, -2);
						$this->rate->ViewValue = $this->rate->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->rate->ViewValue = $this->rate->CurrentValue;
					}
				}
			} else {
				$this->rate->ViewValue = NULL;
			}
			$this->rate->ViewCustomAttributes = "";

			// paid_amound
			$this->paid_amound->ViewValue = $this->paid_amound->CurrentValue;
			$this->paid_amound->ViewValue = FormatNumber($this->paid_amound->ViewValue, 2, -2, -2, -2);
			$this->paid_amound->ViewCustomAttributes = "";

			// pending
			$this->pending->ViewValue = $this->pending->CurrentValue;
			$this->pending->ViewValue = FormatNumber($this->pending->ViewValue, 2, -2, -2, -2);
			$this->pending->ViewCustomAttributes = "";

			// Total
			$this->Total->ViewValue = $this->Total->CurrentValue;
			$this->Total->ViewValue = FormatNumber($this->Total->ViewValue, 2, -2, -2, -2);
			$this->Total->ViewCustomAttributes = "";

			// add_user
			$this->add_user->ViewValue = $this->add_user->CurrentValue;
			$this->add_user->ViewCustomAttributes = "";

			// Edit_user
			$this->Edit_user->ViewValue = $this->Edit_user->CurrentValue;
			$this->Edit_user->ViewCustomAttributes = "";

			// pending_amount_paid_date
			$this->pending_amount_paid_date->ViewValue = $this->pending_amount_paid_date->CurrentValue;
			$this->pending_amount_paid_date->ViewValue = FormatDateTime($this->pending_amount_paid_date->ViewValue, 0);
			$this->pending_amount_paid_date->ViewCustomAttributes = "";

			// slno
			$this->slno->LinkCustomAttributes = "";
			$this->slno->HrefValue = "";
			$this->slno->TooltipValue = "";

			// date
			$this->date->LinkCustomAttributes = "";
			$this->date->HrefValue = "";
			$this->date->TooltipValue = "";

			// time
			$this->time->LinkCustomAttributes = "";
			$this->time->HrefValue = "";
			$this->time->TooltipValue = "";

			// customer_name
			$this->customer_name->LinkCustomAttributes = "";
			$this->customer_name->HrefValue = "";
			$this->customer_name->TooltipValue = "";

			// contact
			$this->contact->LinkCustomAttributes = "";
			$this->contact->HrefValue = "";
			$this->contact->TooltipValue = "";

			// dc-type
			$this->dc_type->LinkCustomAttributes = "";
			$this->dc_type->HrefValue = "";
			$this->dc_type->TooltipValue = "";

			// agency
			$this->agency->LinkCustomAttributes = "";
			$this->agency->HrefValue = "";
			$this->agency->TooltipValue = "";

			// serial_no
			$this->serial_no->LinkCustomAttributes = "";
			$this->serial_no->HrefValue = "";
			$this->serial_no->TooltipValue = "";

			// ticket_name
			$this->ticket_name->LinkCustomAttributes = "";
			$this->ticket_name->HrefValue = "";
			$this->ticket_name->TooltipValue = "";

			// ticket_catagory
			$this->ticket_catagory->LinkCustomAttributes = "";
			$this->ticket_catagory->HrefValue = "";
			$this->ticket_catagory->TooltipValue = "";

			// no_of_ticket
			$this->no_of_ticket->LinkCustomAttributes = "";
			$this->no_of_ticket->HrefValue = "";
			$this->no_of_ticket->TooltipValue = "";

			// total_no_of_ticket
			$this->total_no_of_ticket->LinkCustomAttributes = "";
			$this->total_no_of_ticket->HrefValue = "";
			$this->total_no_of_ticket->TooltipValue = "";

			// draw_date
			$this->draw_date->LinkCustomAttributes = "";
			$this->draw_date->HrefValue = "";
			$this->draw_date->TooltipValue = "";

			// paid_amound
			$this->paid_amound->LinkCustomAttributes = "";
			$this->paid_amound->HrefValue = "";
			$this->paid_amound->TooltipValue = "";

			// pending
			$this->pending->LinkCustomAttributes = "";
			$this->pending->HrefValue = "";
			$this->pending->TooltipValue = "";

			// Total
			$this->Total->LinkCustomAttributes = "";
			$this->Total->HrefValue = "";
			$this->Total->TooltipValue = "";

			// add_user
			$this->add_user->LinkCustomAttributes = "";
			$this->add_user->HrefValue = "";
			$this->add_user->TooltipValue = "";

			// Edit_user
			$this->Edit_user->LinkCustomAttributes = "";
			$this->Edit_user->HrefValue = "";
			$this->Edit_user->TooltipValue = "";

			// pending_amount_paid_date
			$this->pending_amount_paid_date->LinkCustomAttributes = "";
			$this->pending_amount_paid_date->HrefValue = "";
			$this->pending_amount_paid_date->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_SEARCH) { // Search row

			// slno
			$this->slno->EditAttrs["class"] = "form-control";
			$this->slno->EditCustomAttributes = "";
			$this->slno->EditValue = HtmlEncode($this->slno->AdvancedSearch->SearchValue);
			$this->slno->PlaceHolder = RemoveHtml($this->slno->caption());

			// date
			$this->date->EditAttrs["class"] = "form-control";
			$this->date->EditCustomAttributes = "";
			$this->date->EditValue = HtmlEncode(FormatDateTime(UnFormatDateTime($this->date->AdvancedSearch->SearchValue, 7), 7));
			$this->date->PlaceHolder = RemoveHtml($this->date->caption());
			$this->date->EditAttrs["class"] = "form-control";
			$this->date->EditCustomAttributes = "";
			$this->date->EditValue2 = HtmlEncode(FormatDateTime(UnFormatDateTime($this->date->AdvancedSearch->SearchValue2, 7), 7));
			$this->date->PlaceHolder = RemoveHtml($this->date->caption());

			// time
			$this->time->EditAttrs["class"] = "form-control";
			$this->time->EditCustomAttributes = "";
			$this->time->EditValue = HtmlEncode(UnFormatDateTime($this->time->AdvancedSearch->SearchValue, 3));
			$this->time->PlaceHolder = RemoveHtml($this->time->caption());

			// customer_name
			$this->customer_name->EditAttrs["class"] = "form-control";
			$this->customer_name->EditCustomAttributes = "";
			if (!$this->customer_name->Raw)
				$this->customer_name->AdvancedSearch->SearchValue = HtmlDecode($this->customer_name->AdvancedSearch->SearchValue);
			$this->customer_name->EditValue = HtmlEncode($this->customer_name->AdvancedSearch->SearchValue);
			$this->customer_name->PlaceHolder = RemoveHtml($this->customer_name->caption());

			// contact
			$this->contact->EditAttrs["class"] = "form-control";
			$this->contact->EditCustomAttributes = "";
			if (!$this->contact->Raw)
				$this->contact->AdvancedSearch->SearchValue = HtmlDecode($this->contact->AdvancedSearch->SearchValue);
			$this->contact->EditValue = HtmlEncode($this->contact->AdvancedSearch->SearchValue);
			$this->contact->PlaceHolder = RemoveHtml($this->contact->caption());
			$this->contact->EditAttrs["class"] = "form-control";
			$this->contact->EditCustomAttributes = "";
			if (!$this->contact->Raw)
				$this->contact->AdvancedSearch->SearchValue2 = HtmlDecode($this->contact->AdvancedSearch->SearchValue2);
			$this->contact->EditValue2 = HtmlEncode($this->contact->AdvancedSearch->SearchValue2);
			$this->contact->PlaceHolder = RemoveHtml($this->contact->caption());

			// dc-type
			$this->dc_type->EditCustomAttributes = "";
			$curVal = trim(strval($this->dc_type->AdvancedSearch->SearchValue));
			if ($curVal != "")
				$this->dc_type->AdvancedSearch->ViewValue = $this->dc_type->lookupCacheOption($curVal);
			else
				$this->dc_type->AdvancedSearch->ViewValue = $this->dc_type->Lookup !== NULL && is_array($this->dc_type->Lookup->Options) ? $curVal : NULL;
			if ($this->dc_type->AdvancedSearch->ViewValue !== NULL) { // Load from cache
				$this->dc_type->EditValue = array_values($this->dc_type->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`dc-type`" . SearchString("=", $this->dc_type->AdvancedSearch->SearchValue, DATATYPE_STRING, "");
				}
				$sqlWrk = $this->dc_type->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->dc_type->EditValue = $arwrk;
			}

			// agency
			$this->agency->EditAttrs["class"] = "form-control";
			$this->agency->EditCustomAttributes = "";
			$curVal = trim(strval($this->agency->AdvancedSearch->SearchValue));
			if ($curVal != "")
				$this->agency->AdvancedSearch->ViewValue = $this->agency->lookupCacheOption($curVal);
			else
				$this->agency->AdvancedSearch->ViewValue = $this->agency->Lookup !== NULL && is_array($this->agency->Lookup->Options) ? $curVal : NULL;
			if ($this->agency->AdvancedSearch->ViewValue !== NULL) { // Load from cache
				$this->agency->EditValue = array_values($this->agency->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`agency_number`" . SearchString("=", $this->agency->AdvancedSearch->SearchValue, DATATYPE_STRING, "");
				}
				$sqlWrk = $this->agency->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->agency->EditValue = $arwrk;
			}

			// serial_no
			$this->serial_no->EditAttrs["class"] = "form-control";
			$this->serial_no->EditCustomAttributes = "";
			$this->serial_no->EditValue = HtmlEncode($this->serial_no->AdvancedSearch->SearchValue);
			$this->serial_no->PlaceHolder = RemoveHtml($this->serial_no->caption());

			// ticket_name
			$this->ticket_name->EditAttrs["class"] = "form-control";
			$this->ticket_name->EditCustomAttributes = "";
			$curVal = trim(strval($this->ticket_name->AdvancedSearch->SearchValue));
			if ($curVal != "")
				$this->ticket_name->AdvancedSearch->ViewValue = $this->ticket_name->lookupCacheOption($curVal);
			else
				$this->ticket_name->AdvancedSearch->ViewValue = $this->ticket_name->Lookup !== NULL && is_array($this->ticket_name->Lookup->Options) ? $curVal : NULL;
			if ($this->ticket_name->AdvancedSearch->ViewValue !== NULL) { // Load from cache
				$this->ticket_name->EditValue = array_values($this->ticket_name->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`ticket_name`" . SearchString("=", $this->ticket_name->AdvancedSearch->SearchValue, DATATYPE_STRING, "");
				}
				$sqlWrk = $this->ticket_name->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->ticket_name->EditValue = $arwrk;
			}

			// ticket_catagory
			$this->ticket_catagory->EditAttrs["class"] = "form-control";
			$this->ticket_catagory->EditCustomAttributes = "";

			// no_of_ticket
			$this->no_of_ticket->EditAttrs["class"] = "form-control";
			$this->no_of_ticket->EditCustomAttributes = "";
			$this->no_of_ticket->EditValue = HtmlEncode($this->no_of_ticket->AdvancedSearch->SearchValue);
			$this->no_of_ticket->PlaceHolder = RemoveHtml($this->no_of_ticket->caption());

			// total_no_of_ticket
			$this->total_no_of_ticket->EditAttrs["class"] = "form-control";
			$this->total_no_of_ticket->EditCustomAttributes = "";
			$this->total_no_of_ticket->EditValue = HtmlEncode($this->total_no_of_ticket->AdvancedSearch->SearchValue);
			$this->total_no_of_ticket->PlaceHolder = RemoveHtml($this->total_no_of_ticket->caption());

			// draw_date
			$this->draw_date->EditAttrs["class"] = "form-control";
			$this->draw_date->EditCustomAttributes = "";
			if (!$this->draw_date->Raw)
				$this->draw_date->AdvancedSearch->SearchValue = HtmlDecode($this->draw_date->AdvancedSearch->SearchValue);
			$this->draw_date->EditValue = HtmlEncode($this->draw_date->AdvancedSearch->SearchValue);
			$curVal = strval($this->draw_date->AdvancedSearch->SearchValue);
			if ($curVal != "") {
				$this->draw_date->EditValue = $this->draw_date->lookupCacheOption($curVal);
				if ($this->draw_date->EditValue === NULL) { // Lookup from database
					$filterWrk = "`draw_date`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->draw_date->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$this->draw_date->EditValue = $this->draw_date->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->draw_date->EditValue = HtmlEncode($this->draw_date->AdvancedSearch->SearchValue);
					}
				}
			} else {
				$this->draw_date->EditValue = NULL;
			}
			$this->draw_date->PlaceHolder = RemoveHtml($this->draw_date->caption());

			// paid_amound
			$this->paid_amound->EditAttrs["class"] = "form-control";
			$this->paid_amound->EditCustomAttributes = "";
			$this->paid_amound->EditValue = HtmlEncode($this->paid_amound->AdvancedSearch->SearchValue);
			$this->paid_amound->PlaceHolder = RemoveHtml($this->paid_amound->caption());

			// pending
			$this->pending->EditAttrs["class"] = "form-control";
			$this->pending->EditCustomAttributes = "";
			$this->pending->EditValue = HtmlEncode($this->pending->AdvancedSearch->SearchValue);
			$this->pending->PlaceHolder = RemoveHtml($this->pending->caption());
			$this->pending->EditAttrs["class"] = "form-control";
			$this->pending->EditCustomAttributes = "";
			$this->pending->EditValue2 = HtmlEncode($this->pending->AdvancedSearch->SearchValue2);
			$this->pending->PlaceHolder = RemoveHtml($this->pending->caption());

			// Total
			$this->Total->EditAttrs["class"] = "form-control";
			$this->Total->EditCustomAttributes = "";
			$this->Total->EditValue = HtmlEncode($this->Total->AdvancedSearch->SearchValue);
			$this->Total->PlaceHolder = RemoveHtml($this->Total->caption());

			// add_user
			$this->add_user->EditAttrs["class"] = "form-control";
			$this->add_user->EditCustomAttributes = "";
			if (!$this->add_user->Raw)
				$this->add_user->AdvancedSearch->SearchValue = HtmlDecode($this->add_user->AdvancedSearch->SearchValue);
			$this->add_user->EditValue = HtmlEncode($this->add_user->AdvancedSearch->SearchValue);
			$this->add_user->PlaceHolder = RemoveHtml($this->add_user->caption());

			// Edit_user
			$this->Edit_user->EditAttrs["class"] = "form-control";
			$this->Edit_user->EditCustomAttributes = "";
			if (!$this->Edit_user->Raw)
				$this->Edit_user->AdvancedSearch->SearchValue = HtmlDecode($this->Edit_user->AdvancedSearch->SearchValue);
			$this->Edit_user->EditValue = HtmlEncode($this->Edit_user->AdvancedSearch->SearchValue);
			$this->Edit_user->PlaceHolder = RemoveHtml($this->Edit_user->caption());

			// pending_amount_paid_date
			$this->pending_amount_paid_date->EditAttrs["class"] = "form-control";
			$this->pending_amount_paid_date->EditCustomAttributes = "";
			$this->pending_amount_paid_date->EditValue = HtmlEncode(FormatDateTime(UnFormatDateTime($this->pending_amount_paid_date->AdvancedSearch->SearchValue, 0), 8));
			$this->pending_amount_paid_date->PlaceHolder = RemoveHtml($this->pending_amount_paid_date->caption());
		} elseif ($this->RowType == ROWTYPE_AGGREGATEINIT) { // Initialize aggregate row
			$this->slno->Count = 0; // Initialize count
			$this->total_no_of_ticket->Total = 0; // Initialize total
			$this->paid_amound->Total = 0; // Initialize total
			$this->pending->Total = 0; // Initialize total
			$this->Total->Total = 0; // Initialize total
		} elseif ($this->RowType == ROWTYPE_AGGREGATE) { // Aggregate row
			$this->slno->CurrentValue = $this->slno->Count;
			$this->slno->ViewValue = $this->slno->CurrentValue;
			$this->slno->ViewCustomAttributes = "";
			$this->slno->HrefValue = ""; // Clear href value
			$this->total_no_of_ticket->CurrentValue = $this->total_no_of_ticket->Total;
			$this->total_no_of_ticket->ViewValue = $this->total_no_of_ticket->CurrentValue;
			$this->total_no_of_ticket->ViewValue = FormatNumber($this->total_no_of_ticket->ViewValue, 0, -2, -2, -2);
			$this->total_no_of_ticket->ViewCustomAttributes = "";
			$this->total_no_of_ticket->HrefValue = ""; // Clear href value
			$this->paid_amound->CurrentValue = $this->paid_amound->Total;
			$this->paid_amound->ViewValue = $this->paid_amound->CurrentValue;
			$this->paid_amound->ViewValue = FormatNumber($this->paid_amound->ViewValue, 2, -2, -2, -2);
			$this->paid_amound->ViewCustomAttributes = "";
			$this->paid_amound->HrefValue = ""; // Clear href value
			$this->pending->CurrentValue = $this->pending->Total;
			$this->pending->ViewValue = $this->pending->CurrentValue;
			$this->pending->ViewValue = FormatNumber($this->pending->ViewValue, 2, -2, -2, -2);
			$this->pending->ViewCustomAttributes = "";
			$this->pending->HrefValue = ""; // Clear href value
			$this->Total->CurrentValue = $this->Total->Total;
			$this->Total->ViewValue = $this->Total->CurrentValue;
			$this->Total->ViewValue = FormatNumber($this->Total->ViewValue, 2, -2, -2, -2);
			$this->Total->ViewCustomAttributes = "";
			$this->Total->HrefValue = ""; // Clear href value
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate search
	protected function validateSearch()
	{
		global $SearchError;

		// Initialize
		$SearchError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return TRUE;
		if (!CheckInteger($this->slno->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->slno->errorMessage());
		}
		if (!CheckEuroDate($this->date->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->date->errorMessage());
		}
		if (!CheckEuroDate($this->date->AdvancedSearch->SearchValue2)) {
			AddMessage($SearchError, $this->date->errorMessage());
		}
		if (!CheckNumber($this->pending->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->pending->errorMessage());
		}
		if (!CheckNumber($this->pending->AdvancedSearch->SearchValue2)) {
			AddMessage($SearchError, $this->pending->errorMessage());
		}

		// Return validate result
		$validateSearch = ($SearchError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateSearch = $validateSearch && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($SearchError, $formCustomError);
		}
		return $validateSearch;
	}

	// Load advanced search
	public function loadAdvancedSearch()
	{
		$this->slno->AdvancedSearch->load();
		$this->date->AdvancedSearch->load();
		$this->time->AdvancedSearch->load();
		$this->customer_name->AdvancedSearch->load();
		$this->contact->AdvancedSearch->load();
		$this->dc_type->AdvancedSearch->load();
		$this->agency->AdvancedSearch->load();
		$this->serial_no->AdvancedSearch->load();
		$this->book_count->AdvancedSearch->load();
		$this->ticket_name->AdvancedSearch->load();
		$this->ticket_catagory->AdvancedSearch->load();
		$this->no_of_ticket->AdvancedSearch->load();
		$this->total_no_of_ticket->AdvancedSearch->load();
		$this->draw_code->AdvancedSearch->load();
		$this->draw_date->AdvancedSearch->load();
		$this->rate->AdvancedSearch->load();
		$this->paid_amound->AdvancedSearch->load();
		$this->pending->AdvancedSearch->load();
		$this->Total->AdvancedSearch->load();
		$this->add_user->AdvancedSearch->load();
		$this->Edit_user->AdvancedSearch->load();
		$this->pending_amount_paid_date->AdvancedSearch->load();
	}

	// Get export HTML tag
	protected function getExportTag($type, $custom = FALSE)
	{
		global $Language;
		if (SameText($type, "excel")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" onclick=\"return ew.export(document.fsaled_booklist, '" . $this->ExportExcelUrl . "', 'excel', true);\">" . $Language->phrase("ExportToExcel") . "</a>";
			else
				return "<a href=\"" . $this->ExportExcelUrl . "\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\">" . $Language->phrase("ExportToExcel") . "</a>";
		} elseif (SameText($type, "word")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" onclick=\"return ew.export(document.fsaled_booklist, '" . $this->ExportWordUrl . "', 'word', true);\">" . $Language->phrase("ExportToWord") . "</a>";
			else
				return "<a href=\"" . $this->ExportWordUrl . "\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\">" . $Language->phrase("ExportToWord") . "</a>";
		} elseif (SameText($type, "pdf")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" onclick=\"return ew.export(document.fsaled_booklist, '" . $this->ExportPdfUrl . "', 'pdf', true);\">" . $Language->phrase("ExportToPDF") . "</a>";
			else
				return "<a href=\"" . $this->ExportPdfUrl . "\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\">" . $Language->phrase("ExportToPDF") . "</a>";
		} elseif (SameText($type, "html")) {
			return "<a href=\"" . $this->ExportHtmlUrl . "\" class=\"ew-export-link ew-html\" title=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\">" . $Language->phrase("ExportToHtml") . "</a>";
		} elseif (SameText($type, "xml")) {
			return "<a href=\"" . $this->ExportXmlUrl . "\" class=\"ew-export-link ew-xml\" title=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\">" . $Language->phrase("ExportToXml") . "</a>";
		} elseif (SameText($type, "csv")) {
			return "<a href=\"" . $this->ExportCsvUrl . "\" class=\"ew-export-link ew-csv\" title=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\">" . $Language->phrase("ExportToCsv") . "</a>";
		} elseif (SameText($type, "email")) {
			$url = $custom ? ",url:'" . $this->pageUrl() . "export=email&amp;custom=1'" : "";
			return '<button id="emf_saled_book" class="ew-export-link ew-email" title="' . $Language->phrase("ExportToEmailText") . '" data-caption="' . $Language->phrase("ExportToEmailText") . '" onclick="ew.emailDialogShow({lnk:\'emf_saled_book\', hdr:ew.language.phrase(\'ExportToEmailText\'), f:document.fsaled_booklist, sel:false' . $url . '});">' . $Language->phrase("ExportToEmail") . '</button>';
		} elseif (SameText($type, "print")) {
			return "<a href=\"" . $this->ExportPrintUrl . "\" class=\"ew-export-link ew-print\" title=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\">" . $Language->phrase("PrinterFriendly") . "</a>";
		}
	}

	// Set up export options
	protected function setupExportOptions()
	{
		global $Language;

		// Printer friendly
		$item = &$this->ExportOptions->add("print");
		$item->Body = $this->getExportTag("print");
		$item->Visible = TRUE;

		// Export to Excel
		$item = &$this->ExportOptions->add("excel");
		$item->Body = $this->getExportTag("excel");
		$item->Visible = TRUE;

		// Export to Word
		$item = &$this->ExportOptions->add("word");
		$item->Body = $this->getExportTag("word");
		$item->Visible = TRUE;

		// Export to Html
		$item = &$this->ExportOptions->add("html");
		$item->Body = $this->getExportTag("html");
		$item->Visible = FALSE;

		// Export to Xml
		$item = &$this->ExportOptions->add("xml");
		$item->Body = $this->getExportTag("xml");
		$item->Visible = FALSE;

		// Export to Csv
		$item = &$this->ExportOptions->add("csv");
		$item->Body = $this->getExportTag("csv");
		$item->Visible = FALSE;

		// Export to Pdf
		$item = &$this->ExportOptions->add("pdf");
		$item->Body = $this->getExportTag("pdf");
		$item->Visible = FALSE;

		// Export to Email
		$item = &$this->ExportOptions->add("email");
		$item->Body = $this->getExportTag("email");
		$item->Visible = FALSE;

		// Drop down button for export
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseDropDownButton = TRUE;
		if ($this->ExportOptions->UseButtonGroup && IsMobile())
			$this->ExportOptions->UseDropDownButton = TRUE;
		$this->ExportOptions->DropDownButtonPhrase = $Language->phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Set up search options
	protected function setupSearchOptions()
	{
		global $Language;
		$this->SearchOptions = new ListOptions("div");
		$this->SearchOptions->TagClassName = "ew-search-option";

		// Search button
		$item = &$this->SearchOptions->add("searchtoggle");
		$searchToggleClass = ($this->SearchWhere != "") ? " active" : "";
		$item->Body = "<a class=\"btn btn-default ew-search-toggle" . $searchToggleClass . "\" href=\"#\" role=\"button\" title=\"" . $Language->phrase("SearchPanel") . "\" data-caption=\"" . $Language->phrase("SearchPanel") . "\" data-toggle=\"button\" data-form=\"fsaled_booklistsrch\">" . $Language->phrase("SearchLink") . "</a>";
		$item->Visible = TRUE;

		// Show all button
		$item = &$this->SearchOptions->add("showall");
		$item->Body = "<a class=\"btn btn-default ew-show-all\" title=\"" . $Language->phrase("ShowAll") . "\" data-caption=\"" . $Language->phrase("ShowAll") . "\" href=\"" . $this->pageUrl() . "cmd=reset\">" . $Language->phrase("ShowAllBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != $this->DefaultSearchWhere && $this->SearchWhere != "0=101");

		// Button group for search
		$this->SearchOptions->UseDropDownButton = FALSE;
		$this->SearchOptions->UseButtonGroup = TRUE;
		$this->SearchOptions->DropDownButtonPhrase = $Language->phrase("ButtonSearch");

		// Add group option item
		$item = &$this->SearchOptions->add($this->SearchOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide search options
		if ($this->isExport() || $this->CurrentAction)
			$this->SearchOptions->hideAllOptions();
		global $Security;
		if (!$Security->canSearch()) {
			$this->SearchOptions->hideAllOptions();
			$this->FilterOptions->hideAllOptions();
		}
	}

	/**
	 * Export data in HTML/CSV/Word/Excel/XML/Email/PDF format
	 *
	 * @param boolean $return Return the data rather than output it
	 * @return mixed 
	 */
	public function exportData($return = FALSE)
	{
		global $Language;
		$utf8 = SameText(Config("PROJECT_CHARSET"), "utf-8");
		$selectLimit = $this->UseSelectLimit;

		// Load recordset
		if ($selectLimit) {
			$this->TotalRecords = $this->listRecordCount();
		} else {
			if (!$this->Recordset)
				$this->Recordset = $this->loadRecordset();
			$rs = &$this->Recordset;
			if ($rs)
				$this->TotalRecords = $rs->RecordCount();
		}
		$this->StartRecord = 1;

		// Export all
		if ($this->ExportAll) {
			set_time_limit(Config("EXPORT_ALL_TIME_LIMIT"));
			$this->DisplayRecords = $this->TotalRecords;
			$this->StopRecord = $this->TotalRecords;
		} else { // Export one page only
			$this->setupStartRecord(); // Set up start record position

			// Set the last record to display
			if ($this->DisplayRecords <= 0) {
				$this->StopRecord = $this->TotalRecords;
			} else {
				$this->StopRecord = $this->StartRecord + $this->DisplayRecords - 1;
			}
		}
		if ($selectLimit)
			$rs = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords);
		$this->ExportDoc = GetExportDocument($this, "h");
		$doc = &$this->ExportDoc;
		if (!$doc)
			$this->setFailureMessage($Language->phrase("ExportClassNotFound")); // Export class not found
		if (!$rs || !$doc) {
			RemoveHeader("Content-Type"); // Remove header
			RemoveHeader("Content-Disposition");
			$this->showMessage();
			return;
		}
		if ($selectLimit) {
			$this->StartRecord = 1;
			$this->StopRecord = $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords;
		}

		// Call Page Exporting server event
		$this->ExportDoc->ExportCustom = !$this->Page_Exporting();
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		$doc->Text .= $header;
		$this->exportDocument($doc, $rs, $this->StartRecord, $this->StopRecord, "");
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		$doc->Text .= $footer;

		// Close recordset
		$rs->close();

		// Call Page Exported server event
		$this->Page_Exported();

		// Export header and footer
		$doc->exportHeaderAndFooter();

		// Clean output buffer (without destroying output buffer)
		$buffer = ob_get_contents(); // Save the output buffer
		if (!Config("DEBUG") && $buffer)
			ob_clean();

		// Write debug message if enabled
		if (Config("DEBUG") && !$this->isExport("pdf"))
			echo GetDebugMessage();

		// Output data
		if ($this->isExport("email")) {

			// Export-to-email disabled
		} else {
			$doc->export();
			if ($return) {
				RemoveHeader("Content-Type"); // Remove header
				RemoveHeader("Content-Disposition");
				$content = ob_get_contents();
				if ($content)
					ob_clean();
				if ($buffer)
					echo $buffer; // Resume the output buffer
				return $content;
			}
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', '', $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->add("list", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_customer_name":
					$conn = Conn("");
					break;
				case "x_dc_type":
					$conn = Conn("");
					break;
				case "x_agency":
					$conn = Conn("");
					break;
				case "x_ticket_name":
					$conn = Conn("");
					break;
				case "x_ticket_catagory":
					$conn = Conn("");
					break;
				case "x_no_of_ticket":
					$conn = Conn("");
					break;
				case "x_draw_code":
					$conn = Conn("");
					break;
				case "x_draw_date":
					$conn = Conn("");
					break;
				case "x_rate":
					$conn = Conn("");
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_customer_name":
							break;
						case "x_dc_type":
							break;
						case "x_agency":
							break;
						case "x_ticket_name":
							break;
						case "x_ticket_catagory":
							break;
						case "x_no_of_ticket":
							$row[1] = FormatNumber($row[1], 0, -2, -2, -2);
							$row['df'] = $row[1];
							break;
						case "x_draw_code":
							break;
						case "x_draw_date":
							break;
						case "x_rate":
							$row[1] = FormatNumber($row[1], 2, -2, -2, -2);
							$row['df'] = $row[1];
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			} elseif ($pageNo !== NULL) {
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}

	// Row Custom Action event
	function Row_CustomAction($action, $row) {

		// Return FALSE to abort
		return TRUE;
	}

	// Page Exporting event
	// $this->ExportDoc = export document object
	function Page_Exporting() {

		//$this->ExportDoc->Text = "my header"; // Export header
		//return FALSE; // Return FALSE to skip default export and use Row_Export event

		return TRUE; // Return TRUE to use default export and skip Row_Export event
	}

	// Row Export event
	// $this->ExportDoc = export document object
	function Row_Export($rs) {

		//$this->ExportDoc->Text .= "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
	}

	// Page Exported event
	// $this->ExportDoc = export document object
	function Page_Exported() {

		//$this->ExportDoc->Text .= "my footer"; // Export footer
		//echo $this->ExportDoc->Text;

	}

	// Page Importing event
	function Page_Importing($reader, &$options) {

		//var_dump($reader); // Import data reader
		//var_dump($options); // Show all options for importing
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Row Import event
	function Row_Import(&$row, $cnt) {

		//echo $cnt; // Import record count
		//var_dump($row); // Import row
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Page Imported event
	function Page_Imported($reader, $results) {

		//var_dump($reader); // Import data reader
		//var_dump($results); // Import results

	}
} // End class
?>