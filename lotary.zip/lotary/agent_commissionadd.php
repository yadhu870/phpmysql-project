<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agent_commission_add = new agent_commission_add();

// Run the page
$agent_commission_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agent_commission_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fagent_commissionadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fagent_commissionadd = currentForm = new ew.Form("fagent_commissionadd", "add");

	// Validate form
	fagent_commissionadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($agent_commission_add->date->Required) { ?>
				elm = this.getElements("x" + infix + "_date");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->date->caption(), $agent_commission_add->date->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->time->Required) { ?>
				elm = this.getElements("x" + infix + "_time");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->time->caption(), $agent_commission_add->time->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->dc_number->Required) { ?>
				elm = this.getElements("x" + infix + "_dc_number");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->dc_number->caption(), $agent_commission_add->dc_number->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dc_number");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($agent_commission_add->dc_number->errorMessage()) ?>");
			<?php if ($agent_commission_add->customer_name->Required) { ?>
				elm = this.getElements("x" + infix + "_customer_name");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->customer_name->caption(), $agent_commission_add->customer_name->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->ticket_name->Required) { ?>
				elm = this.getElements("x" + infix + "_ticket_name");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->ticket_name->caption(), $agent_commission_add->ticket_name->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->draw_date->Required) { ?>
				elm = this.getElements("x" + infix + "_draw_date");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->draw_date->caption(), $agent_commission_add->draw_date->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->ticket_catagory->Required) { ?>
				elm = this.getElements("x" + infix + "_ticket_catagory");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->ticket_catagory->caption(), $agent_commission_add->ticket_catagory->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->dc_type->Required) { ?>
				elm = this.getElements("x" + infix + "_dc_type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->dc_type->caption(), $agent_commission_add->dc_type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->serial_number->Required) { ?>
				elm = this.getElements("x" + infix + "_serial_number");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->serial_number->caption(), $agent_commission_add->serial_number->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->priced_serial_and_amount->Required) { ?>
				elm = this.getElements("x" + infix + "_priced_serial_and_amount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->priced_serial_and_amount->caption(), $agent_commission_add->priced_serial_and_amount->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agent_commission_add->commission_amount->Required) { ?>
				elm = this.getElements("x" + infix + "_commission_amount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->commission_amount->caption(), $agent_commission_add->commission_amount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_commission_amount");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($agent_commission_add->commission_amount->errorMessage()) ?>");
			<?php if ($agent_commission_add->agency_dc->Required) { ?>
				elm = this.getElements("x" + infix + "_agency_dc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->agency_dc->caption(), $agent_commission_add->agency_dc->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_agency_dc");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($agent_commission_add->agency_dc->errorMessage()) ?>");
			<?php if ($agent_commission_add->total_dc->Required) { ?>
				elm = this.getElements("x" + infix + "_total_dc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->total_dc->caption(), $agent_commission_add->total_dc->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_total_dc");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($agent_commission_add->total_dc->errorMessage()) ?>");
			<?php if ($agent_commission_add->add_user->Required) { ?>
				elm = this.getElements("x" + infix + "_add_user");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agent_commission_add->add_user->caption(), $agent_commission_add->add_user->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fagent_commissionadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fagent_commissionadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fagent_commissionadd.lists["x_dc_number"] = <?php echo $agent_commission_add->dc_number->Lookup->toClientList($agent_commission_add) ?>;
	fagent_commissionadd.lists["x_dc_number"].options = <?php echo JsonEncode($agent_commission_add->dc_number->lookupOptions()) ?>;
	fagent_commissionadd.autoSuggests["x_dc_number"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fagent_commissionadd.lists["x_customer_name"] = <?php echo $agent_commission_add->customer_name->Lookup->toClientList($agent_commission_add) ?>;
	fagent_commissionadd.lists["x_customer_name"].options = <?php echo JsonEncode($agent_commission_add->customer_name->lookupOptions()) ?>;
	fagent_commissionadd.autoSuggests["x_customer_name"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fagent_commissionadd.lists["x_ticket_name"] = <?php echo $agent_commission_add->ticket_name->Lookup->toClientList($agent_commission_add) ?>;
	fagent_commissionadd.lists["x_ticket_name"].options = <?php echo JsonEncode($agent_commission_add->ticket_name->lookupOptions()) ?>;
	fagent_commissionadd.autoSuggests["x_ticket_name"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fagent_commissionadd.lists["x_draw_date"] = <?php echo $agent_commission_add->draw_date->Lookup->toClientList($agent_commission_add) ?>;
	fagent_commissionadd.lists["x_draw_date"].options = <?php echo JsonEncode($agent_commission_add->draw_date->lookupOptions()) ?>;
	fagent_commissionadd.autoSuggests["x_draw_date"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fagent_commissionadd.lists["x_ticket_catagory"] = <?php echo $agent_commission_add->ticket_catagory->Lookup->toClientList($agent_commission_add) ?>;
	fagent_commissionadd.lists["x_ticket_catagory"].options = <?php echo JsonEncode($agent_commission_add->ticket_catagory->lookupOptions()) ?>;
	fagent_commissionadd.autoSuggests["x_ticket_catagory"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("fagent_commissionadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $agent_commission_add->showPageHeader(); ?>
<?php
$agent_commission_add->showMessage();
?>
<form name="fagent_commissionadd" id="fagent_commissionadd" class="<?php echo $agent_commission_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agent_commission">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$agent_commission_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($agent_commission_add->dc_number->Visible) { // dc_number ?>
	<div id="r_dc_number" class="form-group row">
		<label id="elh_agent_commission_dc_number" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->dc_number->caption() ?><?php echo $agent_commission_add->dc_number->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->dc_number->cellAttributes() ?>>
<span id="el_agent_commission_dc_number">
<?php
$onchange = $agent_commission_add->dc_number->EditAttrs->prepend("onchange", "ew.autoFill(this);");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_add->dc_number->EditAttrs["onchange"] = "";
?>
<span id="as_x_dc_number">
	<input type="text" class="form-control" name="sv_x_dc_number" id="sv_x_dc_number" value="<?php echo RemoveHtml($agent_commission_add->dc_number->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_add->dc_number->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_add->dc_number->getPlaceHolder()) ?>"<?php echo $agent_commission_add->dc_number->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_dc_number" data-value-separator="<?php echo $agent_commission_add->dc_number->displayValueSeparatorAttribute() ?>" name="x_dc_number" id="x_dc_number" value="<?php echo HtmlEncode($agent_commission_add->dc_number->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionadd"], function() {
	fagent_commissionadd.createAutoSuggest({"id":"x_dc_number","forceSelect":true});
});
</script>
<?php echo $agent_commission_add->dc_number->Lookup->getParamTag($agent_commission_add, "p_x_dc_number") ?>
</span>
<?php echo $agent_commission_add->dc_number->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->customer_name->Visible) { // customer_name ?>
	<div id="r_customer_name" class="form-group row">
		<label id="elh_agent_commission_customer_name" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->customer_name->caption() ?><?php echo $agent_commission_add->customer_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->customer_name->cellAttributes() ?>>
<span id="el_agent_commission_customer_name">
<?php
$onchange = $agent_commission_add->customer_name->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_add->customer_name->EditAttrs["onchange"] = "";
?>
<span id="as_x_customer_name">
	<input type="text" class="form-control" readonly="sv_x_customer_name" name="sv_x_customer_name" id="sv_x_customer_name" value="<?php echo RemoveHtml($agent_commission_add->customer_name->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_add->customer_name->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_add->customer_name->getPlaceHolder()) ?>"<?php echo $agent_commission_add->customer_name->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_customer_name" data-value-separator="<?php echo $agent_commission_add->customer_name->displayValueSeparatorAttribute() ?>" name="x_customer_name" id="x_customer_name" value="<?php echo HtmlEncode($agent_commission_add->customer_name->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionadd"], function() {
	fagent_commissionadd.createAutoSuggest({"id":"x_customer_name","forceSelect":false});
});
</script>
<?php echo $agent_commission_add->customer_name->Lookup->getParamTag($agent_commission_add, "p_x_customer_name") ?>
</span>
<?php echo $agent_commission_add->customer_name->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->ticket_name->Visible) { // ticket_name ?>
	<div id="r_ticket_name" class="form-group row">
		<label id="elh_agent_commission_ticket_name" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->ticket_name->caption() ?><?php echo $agent_commission_add->ticket_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->ticket_name->cellAttributes() ?>>
<span id="el_agent_commission_ticket_name">
<?php
$onchange = $agent_commission_add->ticket_name->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_add->ticket_name->EditAttrs["onchange"] = "";
?>
<span id="as_x_ticket_name">
	<input type="text" class="form-control" readonly="sv_x_ticket_name" name="sv_x_ticket_name" id="sv_x_ticket_name" value="<?php echo RemoveHtml($agent_commission_add->ticket_name->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_add->ticket_name->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_add->ticket_name->getPlaceHolder()) ?>"<?php echo $agent_commission_add->ticket_name->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_ticket_name" data-value-separator="<?php echo $agent_commission_add->ticket_name->displayValueSeparatorAttribute() ?>" name="x_ticket_name" id="x_ticket_name" value="<?php echo HtmlEncode($agent_commission_add->ticket_name->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionadd"], function() {
	fagent_commissionadd.createAutoSuggest({"id":"x_ticket_name","forceSelect":true});
});
</script>
<?php echo $agent_commission_add->ticket_name->Lookup->getParamTag($agent_commission_add, "p_x_ticket_name") ?>
</span>
<?php echo $agent_commission_add->ticket_name->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->draw_date->Visible) { // draw_date ?>
	<div id="r_draw_date" class="form-group row">
		<label id="elh_agent_commission_draw_date" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->draw_date->caption() ?><?php echo $agent_commission_add->draw_date->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->draw_date->cellAttributes() ?>>
<span id="el_agent_commission_draw_date">
<?php
$onchange = $agent_commission_add->draw_date->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_add->draw_date->EditAttrs["onchange"] = "";
?>
<span id="as_x_draw_date">
	<input type="text" class="form-control" readonly="sv_x_draw_date" name="sv_x_draw_date" id="sv_x_draw_date" value="<?php echo RemoveHtml($agent_commission_add->draw_date->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_add->draw_date->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_add->draw_date->getPlaceHolder()) ?>"<?php echo $agent_commission_add->draw_date->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_draw_date" data-value-separator="<?php echo $agent_commission_add->draw_date->displayValueSeparatorAttribute() ?>" name="x_draw_date" id="x_draw_date" value="<?php echo HtmlEncode($agent_commission_add->draw_date->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionadd"], function() {
	fagent_commissionadd.createAutoSuggest({"id":"x_draw_date","forceSelect":true});
});
</script>
<?php echo $agent_commission_add->draw_date->Lookup->getParamTag($agent_commission_add, "p_x_draw_date") ?>
<?php if (!$agent_commission_add->draw_date->ReadOnly && !$agent_commission_add->draw_date->Disabled && !isset($agent_commission_add->draw_date->EditAttrs["readonly"]) && !isset($agent_commission_add->draw_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagent_commissionadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fagent_commissionadd", "x_draw_date", {"ignoreReadonly":true,"useCurrent":false,"format":7});
});
</script>
<?php } ?>
</span>
<?php echo $agent_commission_add->draw_date->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->ticket_catagory->Visible) { // ticket_catagory ?>
	<div id="r_ticket_catagory" class="form-group row">
		<label id="elh_agent_commission_ticket_catagory" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->ticket_catagory->caption() ?><?php echo $agent_commission_add->ticket_catagory->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->ticket_catagory->cellAttributes() ?>>
<span id="el_agent_commission_ticket_catagory">
<?php
$onchange = $agent_commission_add->ticket_catagory->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_add->ticket_catagory->EditAttrs["onchange"] = "";
?>
<span id="as_x_ticket_catagory">
	<input type="text" class="form-control" readonly="sv_x_ticket_catagory" name="sv_x_ticket_catagory" id="sv_x_ticket_catagory" value="<?php echo RemoveHtml($agent_commission_add->ticket_catagory->EditValue) ?>" size="30" maxlength="11" placeholder="<?php echo HtmlEncode($agent_commission_add->ticket_catagory->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_add->ticket_catagory->getPlaceHolder()) ?>"<?php echo $agent_commission_add->ticket_catagory->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_ticket_catagory" data-value-separator="<?php echo $agent_commission_add->ticket_catagory->displayValueSeparatorAttribute() ?>" name="x_ticket_catagory" id="x_ticket_catagory" value="<?php echo HtmlEncode($agent_commission_add->ticket_catagory->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionadd"], function() {
	fagent_commissionadd.createAutoSuggest({"id":"x_ticket_catagory","forceSelect":false});
});
</script>
<?php echo $agent_commission_add->ticket_catagory->Lookup->getParamTag($agent_commission_add, "p_x_ticket_catagory") ?>
</span>
<?php echo $agent_commission_add->ticket_catagory->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->dc_type->Visible) { // dc_type ?>
	<div id="r_dc_type" class="form-group row">
		<label id="elh_agent_commission_dc_type" for="x_dc_type" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->dc_type->caption() ?><?php echo $agent_commission_add->dc_type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->dc_type->cellAttributes() ?>>
<span id="el_agent_commission_dc_type">
<input type="text" data-table="agent_commission" readonly="x_dc_type" data-field="x_dc_type" name="x_dc_type" id="x_dc_type" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_add->dc_type->getPlaceHolder()) ?>" value="<?php echo $agent_commission_add->dc_type->EditValue ?>"<?php echo $agent_commission_add->dc_type->editAttributes() ?>>
</span>
<?php echo $agent_commission_add->dc_type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->serial_number->Visible) { // serial_number ?>
	<div id="r_serial_number" class="form-group row">
		<label id="elh_agent_commission_serial_number" for="x_serial_number" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->serial_number->caption() ?><?php echo $agent_commission_add->serial_number->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->serial_number->cellAttributes() ?>>
<span id="el_agent_commission_serial_number">
<textarea data-table="agent_commission" data-field="x_serial_number" readonly="x_serial_number" name="x_serial_number" id="x_serial_number" cols="35" rows="4" placeholder="<?php echo HtmlEncode($agent_commission_add->serial_number->getPlaceHolder()) ?>"<?php echo $agent_commission_add->serial_number->editAttributes() ?>><?php echo $agent_commission_add->serial_number->EditValue ?></textarea>
</span>
<?php echo $agent_commission_add->serial_number->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->priced_serial_and_amount->Visible) { // priced_serial_and_amount ?>
	<div id="r_priced_serial_and_amount" class="form-group row">
		<label id="elh_agent_commission_priced_serial_and_amount" for="x_priced_serial_and_amount" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->priced_serial_and_amount->caption() ?><?php echo $agent_commission_add->priced_serial_and_amount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->priced_serial_and_amount->cellAttributes() ?>>
<span id="el_agent_commission_priced_serial_and_amount">
<textarea data-table="agent_commission" data-field="x_priced_serial_and_amount" name="x_priced_serial_and_amount" id="x_priced_serial_and_amount" cols="35" rows="4" placeholder="<?php echo HtmlEncode($agent_commission_add->priced_serial_and_amount->getPlaceHolder()) ?>"<?php echo $agent_commission_add->priced_serial_and_amount->editAttributes() ?>><?php echo $agent_commission_add->priced_serial_and_amount->EditValue ?></textarea>
</span>
<?php echo $agent_commission_add->priced_serial_and_amount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->commission_amount->Visible) { // commission_amount ?>
	<div id="r_commission_amount" class="form-group row">
		<label id="elh_agent_commission_commission_amount" for="x_commission_amount" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->commission_amount->caption() ?><?php echo $agent_commission_add->commission_amount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->commission_amount->cellAttributes() ?>>
<span id="el_agent_commission_commission_amount">
<input type="text" data-table="agent_commission" data-field="x_commission_amount" onkeyup="return getMainAmount1()" onchange="return getMainAmount1()" name="x_commission_amount" id="x_commission_amount" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($agent_commission_add->commission_amount->getPlaceHolder()) ?>" value="<?php echo $agent_commission_add->commission_amount->EditValue ?>"<?php echo $agent_commission_add->commission_amount->editAttributes() ?>>
</span>
<?php echo $agent_commission_add->commission_amount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->agency_dc->Visible) { // agency_dc ?>
	<div id="r_agency_dc" class="form-group row">
		<label id="elh_agent_commission_agency_dc" for="x_agency_dc" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->agency_dc->caption() ?><?php echo $agent_commission_add->agency_dc->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->agency_dc->cellAttributes() ?>>
<span id="el_agent_commission_agency_dc">
<input type="text" data-table="agent_commission" data-field="x_agency_dc" onkeyup="return getMainAmount1()" onchange="return getMainAmount1()" name="x_agency_dc" id="x_agency_dc" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_add->agency_dc->getPlaceHolder()) ?>" value="<?php echo $agent_commission_add->agency_dc->EditValue ?>"<?php echo $agent_commission_add->agency_dc->editAttributes() ?>>
</span>
<?php echo $agent_commission_add->agency_dc->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agent_commission_add->total_dc->Visible) { // total_dc ?>
	<div id="r_total_dc" class="form-group row">
		<label id="elh_agent_commission_total_dc" for="x_total_dc" class="<?php echo $agent_commission_add->LeftColumnClass ?>"><?php echo $agent_commission_add->total_dc->caption() ?><?php echo $agent_commission_add->total_dc->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agent_commission_add->RightColumnClass ?>"><div <?php echo $agent_commission_add->total_dc->cellAttributes() ?>>
<span id="el_agent_commission_total_dc">
<input type="text" data-table="agent_commission" readonly="x_total_dc" data-field="x_total_dc" name="x_total_dc" id="x_total_dc" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_add->total_dc->getPlaceHolder()) ?>" value="<?php echo $agent_commission_add->total_dc->EditValue ?>"<?php echo $agent_commission_add->total_dc->editAttributes() ?>>
</span>
<?php echo $agent_commission_add->total_dc->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$agent_commission_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $agent_commission_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $agent_commission_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$agent_commission_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<script type="text/javascript">
	function getMainAmount1()
	{
	    var comm=$("#x_commission_amount").val();
		var dc=$("#x_agency_dc").val();	
		var tot= parseFloat(comm) + parseFloat(dc);
		$("#x_total_dc").val(tot);
		}
		</script>
<?php include_once "footer.php"; ?>
<?php
$agent_commission_add->terminate();
?>