<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agency_list = new agency_list();

// Run the page
$agency_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agency_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$agency_list->isExport()) { ?>
<script>
var fagencylist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fagencylist = currentForm = new ew.Form("fagencylist", "list");
	fagencylist.formKeyCountName = '<?php echo $agency_list->FormKeyCountName ?>';
	loadjs.done("fagencylist");
});
var fagencylistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fagencylistsrch = currentSearchForm = new ew.Form("fagencylistsrch");

	// Dynamic selection lists
	// Filters

	fagencylistsrch.filterList = <?php echo $agency_list->getFilterList() ?>;

	// Init search panel as collapsed
	fagencylistsrch.initSearchPanel = true;
	loadjs.done("fagencylistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$agency_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($agency_list->TotalRecords > 0 && $agency_list->ExportOptions->visible()) { ?>
<?php $agency_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($agency_list->ImportOptions->visible()) { ?>
<?php $agency_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($agency_list->SearchOptions->visible()) { ?>
<?php $agency_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($agency_list->FilterOptions->visible()) { ?>
<?php $agency_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$agency_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$agency_list->isExport() && !$agency->CurrentAction) { ?>
<form name="fagencylistsrch" id="fagencylistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fagencylistsrch-search-panel" class="<?php echo $agency_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="agency">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $agency_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($agency_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($agency_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $agency_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($agency_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($agency_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($agency_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($agency_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $agency_list->showPageHeader(); ?>
<?php
$agency_list->showMessage();
?>
<?php if ($agency_list->TotalRecords > 0 || $agency->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($agency_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> agency">
<?php if (!$agency_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$agency_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $agency_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $agency_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="fagencylist" id="fagencylist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agency">
<div id="gmp_agency" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($agency_list->TotalRecords > 0 || $agency_list->isGridEdit()) { ?>
<table id="tbl_agencylist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$agency->RowType = ROWTYPE_HEADER;

// Render list options
$agency_list->renderListOptions();

// Render list options (header, left)
$agency_list->ListOptions->render("header", "left");
?>
<?php if ($agency_list->slno->Visible) { // slno ?>
	<?php if ($agency_list->SortUrl($agency_list->slno) == "") { ?>
		<th data-name="slno" class="<?php echo $agency_list->slno->headerCellClass() ?>"><div id="elh_agency_slno" class="agency_slno"><div class="ew-table-header-caption"><?php echo $agency_list->slno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="slno" class="<?php echo $agency_list->slno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_list->SortUrl($agency_list->slno) ?>', 1);"><div id="elh_agency_slno" class="agency_slno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_list->slno->caption() ?></span><span class="ew-table-header-sort"><?php if ($agency_list->slno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_list->slno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_list->agency_name->Visible) { // agency_name ?>
	<?php if ($agency_list->SortUrl($agency_list->agency_name) == "") { ?>
		<th data-name="agency_name" class="<?php echo $agency_list->agency_name->headerCellClass() ?>"><div id="elh_agency_agency_name" class="agency_agency_name"><div class="ew-table-header-caption"><?php echo $agency_list->agency_name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="agency_name" class="<?php echo $agency_list->agency_name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_list->SortUrl($agency_list->agency_name) ?>', 1);"><div id="elh_agency_agency_name" class="agency_agency_name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_list->agency_name->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agency_list->agency_name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_list->agency_name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_list->agency_number->Visible) { // agency_number ?>
	<?php if ($agency_list->SortUrl($agency_list->agency_number) == "") { ?>
		<th data-name="agency_number" class="<?php echo $agency_list->agency_number->headerCellClass() ?>"><div id="elh_agency_agency_number" class="agency_agency_number"><div class="ew-table-header-caption"><?php echo $agency_list->agency_number->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="agency_number" class="<?php echo $agency_list->agency_number->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_list->SortUrl($agency_list->agency_number) ?>', 1);"><div id="elh_agency_agency_number" class="agency_agency_number">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_list->agency_number->caption() ?></span><span class="ew-table-header-sort"><?php if ($agency_list->agency_number->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_list->agency_number->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$agency_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($agency_list->ExportAll && $agency_list->isExport()) {
	$agency_list->StopRecord = $agency_list->TotalRecords;
} else {

	// Set the last record to display
	if ($agency_list->TotalRecords > $agency_list->StartRecord + $agency_list->DisplayRecords - 1)
		$agency_list->StopRecord = $agency_list->StartRecord + $agency_list->DisplayRecords - 1;
	else
		$agency_list->StopRecord = $agency_list->TotalRecords;
}
$agency_list->RecordCount = $agency_list->StartRecord - 1;
if ($agency_list->Recordset && !$agency_list->Recordset->EOF) {
	$agency_list->Recordset->moveFirst();
	$selectLimit = $agency_list->UseSelectLimit;
	if (!$selectLimit && $agency_list->StartRecord > 1)
		$agency_list->Recordset->move($agency_list->StartRecord - 1);
} elseif (!$agency->AllowAddDeleteRow && $agency_list->StopRecord == 0) {
	$agency_list->StopRecord = $agency->GridAddRowCount;
}

// Initialize aggregate
$agency->RowType = ROWTYPE_AGGREGATEINIT;
$agency->resetAttributes();
$agency_list->renderRow();
while ($agency_list->RecordCount < $agency_list->StopRecord) {
	$agency_list->RecordCount++;
	if ($agency_list->RecordCount >= $agency_list->StartRecord) {
		$agency_list->RowCount++;

		// Set up key count
		$agency_list->KeyCount = $agency_list->RowIndex;

		// Init row class and style
		$agency->resetAttributes();
		$agency->CssClass = "";
		if ($agency_list->isGridAdd()) {
		} else {
			$agency_list->loadRowValues($agency_list->Recordset); // Load row values
		}
		$agency->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$agency->RowAttrs->merge(["data-rowindex" => $agency_list->RowCount, "id" => "r" . $agency_list->RowCount . "_agency", "data-rowtype" => $agency->RowType]);

		// Render row
		$agency_list->renderRow();

		// Render list options
		$agency_list->renderListOptions();
?>
	<tr <?php echo $agency->rowAttributes() ?>>
<?php

// Render list options (body, left)
$agency_list->ListOptions->render("body", "left", $agency_list->RowCount);
?>
	<?php if ($agency_list->slno->Visible) { // slno ?>
		<td data-name="slno" <?php echo $agency_list->slno->cellAttributes() ?>>
<span id="el<?php echo $agency_list->RowCount ?>_agency_slno">
<span<?php echo $agency_list->slno->viewAttributes() ?>><?php echo $agency_list->slno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_list->agency_name->Visible) { // agency_name ?>
		<td data-name="agency_name" <?php echo $agency_list->agency_name->cellAttributes() ?>>
<span id="el<?php echo $agency_list->RowCount ?>_agency_agency_name">
<span<?php echo $agency_list->agency_name->viewAttributes() ?>><?php echo $agency_list->agency_name->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_list->agency_number->Visible) { // agency_number ?>
		<td data-name="agency_number" <?php echo $agency_list->agency_number->cellAttributes() ?>>
<span id="el<?php echo $agency_list->RowCount ?>_agency_agency_number">
<span<?php echo $agency_list->agency_number->viewAttributes() ?>><?php echo $agency_list->agency_number->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$agency_list->ListOptions->render("body", "right", $agency_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$agency_list->isGridAdd())
		$agency_list->Recordset->moveNext();
}
?>
</tbody>
<?php

// Render aggregate row
$agency->RowType = ROWTYPE_AGGREGATE;
$agency->resetAttributes();
$agency_list->renderRow();
?>
<?php if ($agency_list->TotalRecords > 0 && !$agency_list->isGridAdd() && !$agency_list->isGridEdit()) { ?>
<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options
$agency_list->renderListOptions();

// Render list options (footer, left)
$agency_list->ListOptions->render("footer", "left");
?>
	<?php if ($agency_list->slno->Visible) { // slno ?>
		<td data-name="slno" class="<?php echo $agency_list->slno->footerCellClass() ?>"><span id="elf_agency_slno" class="agency_slno">
		<span class="ew-aggregate"><?php echo $Language->phrase("COUNT") ?></span><span class="ew-aggregate-value">
		<?php echo $agency_list->slno->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($agency_list->agency_name->Visible) { // agency_name ?>
		<td data-name="agency_name" class="<?php echo $agency_list->agency_name->footerCellClass() ?>"><span id="elf_agency_agency_name" class="agency_agency_name">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agency_list->agency_number->Visible) { // agency_number ?>
		<td data-name="agency_number" class="<?php echo $agency_list->agency_number->footerCellClass() ?>"><span id="elf_agency_agency_number" class="agency_agency_number">
		&nbsp;
		</span></td>
	<?php } ?>
<?php

// Render list options (footer, right)
$agency_list->ListOptions->render("footer", "right");
?>
	</tr>
</tfoot>
<?php } ?>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$agency->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($agency_list->Recordset)
	$agency_list->Recordset->Close();
?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($agency_list->TotalRecords == 0 && !$agency->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $agency_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$agency_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$agency_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$agency_list->terminate();
?>