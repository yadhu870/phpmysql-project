<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agency_commission_view = new agency_commission_view();

// Run the page
$agency_commission_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agency_commission_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$agency_commission_view->isExport()) { ?>
<script>
var fagency_commissionview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fagency_commissionview = currentForm = new ew.Form("fagency_commissionview", "view");
	loadjs.done("fagency_commissionview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$agency_commission_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $agency_commission_view->ExportOptions->render("body") ?>
<?php $agency_commission_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $agency_commission_view->showPageHeader(); ?>
<?php
$agency_commission_view->showMessage();
?>
<?php if (!$agency_commission_view->IsModal) { ?>
<?php if (!$agency_commission_view->isExport()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $agency_commission_view->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<?php } ?>
<form name="fagency_commissionview" id="fagency_commissionview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agency_commission">
<input type="hidden" name="modal" value="<?php echo (int)$agency_commission_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($agency_commission_view->slno->Visible) { // slno ?>
	<tr id="r_slno">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_slno"><?php echo $agency_commission_view->slno->caption() ?></span></td>
		<td data-name="slno" <?php echo $agency_commission_view->slno->cellAttributes() ?>>
<span id="el_agency_commission_slno">
<span<?php echo $agency_commission_view->slno->viewAttributes() ?>><?php echo $agency_commission_view->slno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->agent->Visible) { // agent ?>
	<tr id="r_agent">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_agent"><?php echo $agency_commission_view->agent->caption() ?></span></td>
		<td data-name="agent" <?php echo $agency_commission_view->agent->cellAttributes() ?>>
<span id="el_agency_commission_agent">
<span<?php echo $agency_commission_view->agent->viewAttributes() ?>><?php echo $agency_commission_view->agent->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->draw_code->Visible) { // draw_code ?>
	<tr id="r_draw_code">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_draw_code"><?php echo $agency_commission_view->draw_code->caption() ?></span></td>
		<td data-name="draw_code" <?php echo $agency_commission_view->draw_code->cellAttributes() ?>>
<span id="el_agency_commission_draw_code">
<span<?php echo $agency_commission_view->draw_code->viewAttributes() ?>><?php echo $agency_commission_view->draw_code->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->ticket_name->Visible) { // ticket_name ?>
	<tr id="r_ticket_name">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_ticket_name"><?php echo $agency_commission_view->ticket_name->caption() ?></span></td>
		<td data-name="ticket_name" <?php echo $agency_commission_view->ticket_name->cellAttributes() ?>>
<span id="el_agency_commission_ticket_name">
<span<?php echo $agency_commission_view->ticket_name->viewAttributes() ?>><?php echo $agency_commission_view->ticket_name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->draw_date->Visible) { // draw_date ?>
	<tr id="r_draw_date">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_draw_date"><?php echo $agency_commission_view->draw_date->caption() ?></span></td>
		<td data-name="draw_date" <?php echo $agency_commission_view->draw_date->cellAttributes() ?>>
<span id="el_agency_commission_draw_date">
<span<?php echo $agency_commission_view->draw_date->viewAttributes() ?>><?php echo $agency_commission_view->draw_date->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->serial_no->Visible) { // serial_no ?>
	<tr id="r_serial_no">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_serial_no"><?php echo $agency_commission_view->serial_no->caption() ?></span></td>
		<td data-name="serial_no" <?php echo $agency_commission_view->serial_no->cellAttributes() ?>>
<span id="el_agency_commission_serial_no">
<span<?php echo $agency_commission_view->serial_no->viewAttributes() ?>><?php echo $agency_commission_view->serial_no->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->priced_serial->Visible) { // priced_serial ?>
	<tr id="r_priced_serial">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_priced_serial"><?php echo $agency_commission_view->priced_serial->caption() ?></span></td>
		<td data-name="priced_serial" <?php echo $agency_commission_view->priced_serial->cellAttributes() ?>>
<span id="el_agency_commission_priced_serial">
<span<?php echo $agency_commission_view->priced_serial->viewAttributes() ?>><?php echo $agency_commission_view->priced_serial->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->commission->Visible) { // commission ?>
	<tr id="r_commission">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_commission"><?php echo $agency_commission_view->commission->caption() ?></span></td>
		<td data-name="commission" <?php echo $agency_commission_view->commission->cellAttributes() ?>>
<span id="el_agency_commission_commission">
<span<?php echo $agency_commission_view->commission->viewAttributes() ?>><?php echo $agency_commission_view->commission->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->add_date->Visible) { // add_date ?>
	<tr id="r_add_date">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_add_date"><?php echo $agency_commission_view->add_date->caption() ?></span></td>
		<td data-name="add_date" <?php echo $agency_commission_view->add_date->cellAttributes() ?>>
<span id="el_agency_commission_add_date">
<span<?php echo $agency_commission_view->add_date->viewAttributes() ?>><?php echo $agency_commission_view->add_date->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agency_commission_view->add_user->Visible) { // add_user ?>
	<tr id="r_add_user">
		<td class="<?php echo $agency_commission_view->TableLeftColumnClass ?>"><span id="elh_agency_commission_add_user"><?php echo $agency_commission_view->add_user->caption() ?></span></td>
		<td data-name="add_user" <?php echo $agency_commission_view->add_user->cellAttributes() ?>>
<span id="el_agency_commission_add_user">
<span<?php echo $agency_commission_view->add_user->viewAttributes() ?>><?php echo $agency_commission_view->add_user->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$agency_commission_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$agency_commission_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$agency_commission_view->terminate();
?>