<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agency_commission_delete = new agency_commission_delete();

// Run the page
$agency_commission_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agency_commission_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fagency_commissiondelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fagency_commissiondelete = currentForm = new ew.Form("fagency_commissiondelete", "delete");
	loadjs.done("fagency_commissiondelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $agency_commission_delete->showPageHeader(); ?>
<?php
$agency_commission_delete->showMessage();
?>
<form name="fagency_commissiondelete" id="fagency_commissiondelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agency_commission">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($agency_commission_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($agency_commission_delete->slno->Visible) { // slno ?>
		<th class="<?php echo $agency_commission_delete->slno->headerCellClass() ?>"><span id="elh_agency_commission_slno" class="agency_commission_slno"><?php echo $agency_commission_delete->slno->caption() ?></span></th>
<?php } ?>
<?php if ($agency_commission_delete->agent->Visible) { // agent ?>
		<th class="<?php echo $agency_commission_delete->agent->headerCellClass() ?>"><span id="elh_agency_commission_agent" class="agency_commission_agent"><?php echo $agency_commission_delete->agent->caption() ?></span></th>
<?php } ?>
<?php if ($agency_commission_delete->draw_code->Visible) { // draw_code ?>
		<th class="<?php echo $agency_commission_delete->draw_code->headerCellClass() ?>"><span id="elh_agency_commission_draw_code" class="agency_commission_draw_code"><?php echo $agency_commission_delete->draw_code->caption() ?></span></th>
<?php } ?>
<?php if ($agency_commission_delete->ticket_name->Visible) { // ticket_name ?>
		<th class="<?php echo $agency_commission_delete->ticket_name->headerCellClass() ?>"><span id="elh_agency_commission_ticket_name" class="agency_commission_ticket_name"><?php echo $agency_commission_delete->ticket_name->caption() ?></span></th>
<?php } ?>
<?php if ($agency_commission_delete->draw_date->Visible) { // draw_date ?>
		<th class="<?php echo $agency_commission_delete->draw_date->headerCellClass() ?>"><span id="elh_agency_commission_draw_date" class="agency_commission_draw_date"><?php echo $agency_commission_delete->draw_date->caption() ?></span></th>
<?php } ?>
<?php if ($agency_commission_delete->commission->Visible) { // commission ?>
		<th class="<?php echo $agency_commission_delete->commission->headerCellClass() ?>"><span id="elh_agency_commission_commission" class="agency_commission_commission"><?php echo $agency_commission_delete->commission->caption() ?></span></th>
<?php } ?>
<?php if ($agency_commission_delete->add_date->Visible) { // add_date ?>
		<th class="<?php echo $agency_commission_delete->add_date->headerCellClass() ?>"><span id="elh_agency_commission_add_date" class="agency_commission_add_date"><?php echo $agency_commission_delete->add_date->caption() ?></span></th>
<?php } ?>
<?php if ($agency_commission_delete->add_user->Visible) { // add_user ?>
		<th class="<?php echo $agency_commission_delete->add_user->headerCellClass() ?>"><span id="elh_agency_commission_add_user" class="agency_commission_add_user"><?php echo $agency_commission_delete->add_user->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$agency_commission_delete->RecordCount = 0;
$i = 0;
while (!$agency_commission_delete->Recordset->EOF) {
	$agency_commission_delete->RecordCount++;
	$agency_commission_delete->RowCount++;

	// Set row properties
	$agency_commission->resetAttributes();
	$agency_commission->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$agency_commission_delete->loadRowValues($agency_commission_delete->Recordset);

	// Render row
	$agency_commission_delete->renderRow();
?>
	<tr <?php echo $agency_commission->rowAttributes() ?>>
<?php if ($agency_commission_delete->slno->Visible) { // slno ?>
		<td <?php echo $agency_commission_delete->slno->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_slno" class="agency_commission_slno">
<span<?php echo $agency_commission_delete->slno->viewAttributes() ?>><?php echo $agency_commission_delete->slno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_commission_delete->agent->Visible) { // agent ?>
		<td <?php echo $agency_commission_delete->agent->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_agent" class="agency_commission_agent">
<span<?php echo $agency_commission_delete->agent->viewAttributes() ?>><?php echo $agency_commission_delete->agent->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_commission_delete->draw_code->Visible) { // draw_code ?>
		<td <?php echo $agency_commission_delete->draw_code->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_draw_code" class="agency_commission_draw_code">
<span<?php echo $agency_commission_delete->draw_code->viewAttributes() ?>><?php echo $agency_commission_delete->draw_code->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_commission_delete->ticket_name->Visible) { // ticket_name ?>
		<td <?php echo $agency_commission_delete->ticket_name->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_ticket_name" class="agency_commission_ticket_name">
<span<?php echo $agency_commission_delete->ticket_name->viewAttributes() ?>><?php echo $agency_commission_delete->ticket_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_commission_delete->draw_date->Visible) { // draw_date ?>
		<td <?php echo $agency_commission_delete->draw_date->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_draw_date" class="agency_commission_draw_date">
<span<?php echo $agency_commission_delete->draw_date->viewAttributes() ?>><?php echo $agency_commission_delete->draw_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_commission_delete->commission->Visible) { // commission ?>
		<td <?php echo $agency_commission_delete->commission->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_commission" class="agency_commission_commission">
<span<?php echo $agency_commission_delete->commission->viewAttributes() ?>><?php echo $agency_commission_delete->commission->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_commission_delete->add_date->Visible) { // add_date ?>
		<td <?php echo $agency_commission_delete->add_date->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_add_date" class="agency_commission_add_date">
<span<?php echo $agency_commission_delete->add_date->viewAttributes() ?>><?php echo $agency_commission_delete->add_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_commission_delete->add_user->Visible) { // add_user ?>
		<td <?php echo $agency_commission_delete->add_user->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_delete->RowCount ?>_agency_commission_add_user" class="agency_commission_add_user">
<span<?php echo $agency_commission_delete->add_user->viewAttributes() ?>><?php echo $agency_commission_delete->add_user->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$agency_commission_delete->Recordset->moveNext();
}
$agency_commission_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $agency_commission_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$agency_commission_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$agency_commission_delete->terminate();
?>