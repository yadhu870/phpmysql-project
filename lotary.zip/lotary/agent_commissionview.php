<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agent_commission_view = new agent_commission_view();

// Run the page
$agent_commission_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agent_commission_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$agent_commission_view->isExport()) { ?>
<script>
var fagent_commissionview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fagent_commissionview = currentForm = new ew.Form("fagent_commissionview", "view");
	loadjs.done("fagent_commissionview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$agent_commission_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $agent_commission_view->ExportOptions->render("body") ?>
<?php $agent_commission_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $agent_commission_view->showPageHeader(); ?>
<?php
$agent_commission_view->showMessage();
?>
<?php if (!$agent_commission_view->IsModal) { ?>
<?php if (!$agent_commission_view->isExport()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $agent_commission_view->Pager->render() ?>
<div class="clearfix"></div>
</form>
<?php } ?>
<?php } ?>
<form name="fagent_commissionview" id="fagent_commissionview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agent_commission">
<input type="hidden" name="modal" value="<?php echo (int)$agent_commission_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($agent_commission_view->slno->Visible) { // slno ?>
	<tr id="r_slno">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_slno"><?php echo $agent_commission_view->slno->caption() ?></span></td>
		<td data-name="slno" <?php echo $agent_commission_view->slno->cellAttributes() ?>>
<span id="el_agent_commission_slno">
<span<?php echo $agent_commission_view->slno->viewAttributes() ?>><?php echo $agent_commission_view->slno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->date->Visible) { // date ?>
	<tr id="r_date">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_date"><?php echo $agent_commission_view->date->caption() ?></span></td>
		<td data-name="date" <?php echo $agent_commission_view->date->cellAttributes() ?>>
<span id="el_agent_commission_date">
<span<?php echo $agent_commission_view->date->viewAttributes() ?>><?php echo $agent_commission_view->date->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->time->Visible) { // time ?>
	<tr id="r_time">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_time"><?php echo $agent_commission_view->time->caption() ?></span></td>
		<td data-name="time" <?php echo $agent_commission_view->time->cellAttributes() ?>>
<span id="el_agent_commission_time">
<span<?php echo $agent_commission_view->time->viewAttributes() ?>><?php echo $agent_commission_view->time->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->dc_number->Visible) { // dc_number ?>
	<tr id="r_dc_number">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_dc_number"><?php echo $agent_commission_view->dc_number->caption() ?></span></td>
		<td data-name="dc_number" <?php echo $agent_commission_view->dc_number->cellAttributes() ?>>
<span id="el_agent_commission_dc_number">
<span<?php echo $agent_commission_view->dc_number->viewAttributes() ?>><?php echo $agent_commission_view->dc_number->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->customer_name->Visible) { // customer_name ?>
	<tr id="r_customer_name">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_customer_name"><?php echo $agent_commission_view->customer_name->caption() ?></span></td>
		<td data-name="customer_name" <?php echo $agent_commission_view->customer_name->cellAttributes() ?>>
<span id="el_agent_commission_customer_name">
<span<?php echo $agent_commission_view->customer_name->viewAttributes() ?>><?php echo $agent_commission_view->customer_name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->ticket_name->Visible) { // ticket_name ?>
	<tr id="r_ticket_name">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_ticket_name"><?php echo $agent_commission_view->ticket_name->caption() ?></span></td>
		<td data-name="ticket_name" <?php echo $agent_commission_view->ticket_name->cellAttributes() ?>>
<span id="el_agent_commission_ticket_name">
<span<?php echo $agent_commission_view->ticket_name->viewAttributes() ?>><?php echo $agent_commission_view->ticket_name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->draw_date->Visible) { // draw_date ?>
	<tr id="r_draw_date">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_draw_date"><?php echo $agent_commission_view->draw_date->caption() ?></span></td>
		<td data-name="draw_date" <?php echo $agent_commission_view->draw_date->cellAttributes() ?>>
<span id="el_agent_commission_draw_date">
<span<?php echo $agent_commission_view->draw_date->viewAttributes() ?>><?php echo $agent_commission_view->draw_date->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->ticket_catagory->Visible) { // ticket_catagory ?>
	<tr id="r_ticket_catagory">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_ticket_catagory"><?php echo $agent_commission_view->ticket_catagory->caption() ?></span></td>
		<td data-name="ticket_catagory" <?php echo $agent_commission_view->ticket_catagory->cellAttributes() ?>>
<span id="el_agent_commission_ticket_catagory">
<span<?php echo $agent_commission_view->ticket_catagory->viewAttributes() ?>><?php echo $agent_commission_view->ticket_catagory->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->dc_type->Visible) { // dc_type ?>
	<tr id="r_dc_type">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_dc_type"><?php echo $agent_commission_view->dc_type->caption() ?></span></td>
		<td data-name="dc_type" <?php echo $agent_commission_view->dc_type->cellAttributes() ?>>
<span id="el_agent_commission_dc_type">
<span<?php echo $agent_commission_view->dc_type->viewAttributes() ?>><?php echo $agent_commission_view->dc_type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->serial_number->Visible) { // serial_number ?>
	<tr id="r_serial_number">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_serial_number"><?php echo $agent_commission_view->serial_number->caption() ?></span></td>
		<td data-name="serial_number" <?php echo $agent_commission_view->serial_number->cellAttributes() ?>>
<span id="el_agent_commission_serial_number">
<span<?php echo $agent_commission_view->serial_number->viewAttributes() ?>><?php echo $agent_commission_view->serial_number->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->priced_serial_and_amount->Visible) { // priced_serial_and_amount ?>
	<tr id="r_priced_serial_and_amount">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_priced_serial_and_amount"><?php echo $agent_commission_view->priced_serial_and_amount->caption() ?></span></td>
		<td data-name="priced_serial_and_amount" <?php echo $agent_commission_view->priced_serial_and_amount->cellAttributes() ?>>
<span id="el_agent_commission_priced_serial_and_amount">
<span<?php echo $agent_commission_view->priced_serial_and_amount->viewAttributes() ?>><?php echo $agent_commission_view->priced_serial_and_amount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->commission_amount->Visible) { // commission_amount ?>
	<tr id="r_commission_amount">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_commission_amount"><?php echo $agent_commission_view->commission_amount->caption() ?></span></td>
		<td data-name="commission_amount" <?php echo $agent_commission_view->commission_amount->cellAttributes() ?>>
<span id="el_agent_commission_commission_amount">
<span<?php echo $agent_commission_view->commission_amount->viewAttributes() ?>><?php echo $agent_commission_view->commission_amount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->agency_dc->Visible) { // agency_dc ?>
	<tr id="r_agency_dc">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_agency_dc"><?php echo $agent_commission_view->agency_dc->caption() ?></span></td>
		<td data-name="agency_dc" <?php echo $agent_commission_view->agency_dc->cellAttributes() ?>>
<span id="el_agent_commission_agency_dc">
<span<?php echo $agent_commission_view->agency_dc->viewAttributes() ?>><?php echo $agent_commission_view->agency_dc->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->total_dc->Visible) { // total_dc ?>
	<tr id="r_total_dc">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_total_dc"><?php echo $agent_commission_view->total_dc->caption() ?></span></td>
		<td data-name="total_dc" <?php echo $agent_commission_view->total_dc->cellAttributes() ?>>
<span id="el_agent_commission_total_dc">
<span<?php echo $agent_commission_view->total_dc->viewAttributes() ?>><?php echo $agent_commission_view->total_dc->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($agent_commission_view->add_user->Visible) { // add_user ?>
	<tr id="r_add_user">
		<td class="<?php echo $agent_commission_view->TableLeftColumnClass ?>"><span id="elh_agent_commission_add_user"><?php echo $agent_commission_view->add_user->caption() ?></span></td>
		<td data-name="add_user" <?php echo $agent_commission_view->add_user->cellAttributes() ?>>
<span id="el_agent_commission_add_user">
<span<?php echo $agent_commission_view->add_user->viewAttributes() ?>><?php echo $agent_commission_view->add_user->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$agent_commission_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$agent_commission_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$agent_commission_view->terminate();
?>