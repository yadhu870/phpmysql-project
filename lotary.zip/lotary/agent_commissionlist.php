<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agent_commission_list = new agent_commission_list();

// Run the page
$agent_commission_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agent_commission_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$agent_commission_list->isExport()) { ?>
<script>
var fagent_commissionlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fagent_commissionlist = currentForm = new ew.Form("fagent_commissionlist", "list");
	fagent_commissionlist.formKeyCountName = '<?php echo $agent_commission_list->FormKeyCountName ?>';
	loadjs.done("fagent_commissionlist");
});
var fagent_commissionlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fagent_commissionlistsrch = currentSearchForm = new ew.Form("fagent_commissionlistsrch");

	// Validate function for search
	fagent_commissionlistsrch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_date");
		if (elm && !ew.checkEuroDate(elm.value))
			return this.onError(elm, "<?php echo JsEncode($agent_commission_list->date->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fagent_commissionlistsrch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fagent_commissionlistsrch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fagent_commissionlistsrch.lists["x_customer_name"] = <?php echo $agent_commission_list->customer_name->Lookup->toClientList($agent_commission_list) ?>;
	fagent_commissionlistsrch.lists["x_customer_name"].options = <?php echo JsonEncode($agent_commission_list->customer_name->lookupOptions()) ?>;
	fagent_commissionlistsrch.autoSuggests["x_customer_name"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fagent_commissionlistsrch.lists["x_ticket_name"] = <?php echo $agent_commission_list->ticket_name->Lookup->toClientList($agent_commission_list) ?>;
	fagent_commissionlistsrch.lists["x_ticket_name"].options = <?php echo JsonEncode($agent_commission_list->ticket_name->lookupOptions()) ?>;
	fagent_commissionlistsrch.autoSuggests["x_ticket_name"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fagent_commissionlistsrch.lists["x_draw_date"] = <?php echo $agent_commission_list->draw_date->Lookup->toClientList($agent_commission_list) ?>;
	fagent_commissionlistsrch.lists["x_draw_date"].options = <?php echo JsonEncode($agent_commission_list->draw_date->lookupOptions()) ?>;
	fagent_commissionlistsrch.autoSuggests["x_draw_date"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;

	// Filters
	fagent_commissionlistsrch.filterList = <?php echo $agent_commission_list->getFilterList() ?>;

	// Init search panel as collapsed
	fagent_commissionlistsrch.initSearchPanel = true;
	loadjs.done("fagent_commissionlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$agent_commission_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($agent_commission_list->TotalRecords > 0 && $agent_commission_list->ExportOptions->visible()) { ?>
<?php $agent_commission_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($agent_commission_list->ImportOptions->visible()) { ?>
<?php $agent_commission_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($agent_commission_list->SearchOptions->visible()) { ?>
<?php $agent_commission_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($agent_commission_list->FilterOptions->visible()) { ?>
<?php $agent_commission_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$agent_commission_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$agent_commission_list->isExport() && !$agent_commission->CurrentAction) { ?>
<form name="fagent_commissionlistsrch" id="fagent_commissionlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fagent_commissionlistsrch-search-panel" class="<?php echo $agent_commission_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="agent_commission">
	<div class="ew-extended-search">
<?php

// Render search row
$agent_commission->RowType = ROWTYPE_SEARCH;
$agent_commission->resetAttributes();
$agent_commission_list->renderRow();
?>
<?php if ($agent_commission_list->date->Visible) { // date ?>
	<?php
		$agent_commission_list->SearchColumnCount++;
		if (($agent_commission_list->SearchColumnCount - 1) % $agent_commission_list->SearchFieldsPerRow == 0) {
			$agent_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agent_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_date" class="ew-cell form-group">
		<label for="x_date" class="ew-search-caption ew-label"><?php echo $agent_commission_list->date->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_date" id="z_date" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="IS NULL"<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == "IS NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NULL") ?></option>
<option value="IS NOT NULL"<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == "IS NOT NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NOT NULL") ?></option>
<option value="BETWEEN"<?php echo $agent_commission_list->date->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_agent_commission_date" class="ew-search-field">
<input type="text" data-table="agent_commission" data-field="x_date" data-format="7" name="x_date" id="x_date" maxlength="10" placeholder="<?php echo HtmlEncode($agent_commission_list->date->getPlaceHolder()) ?>" value="<?php echo $agent_commission_list->date->EditValue ?>"<?php echo $agent_commission_list->date->editAttributes() ?>>
<?php if (!$agent_commission_list->date->ReadOnly && !$agent_commission_list->date->Disabled && !isset($agent_commission_list->date->EditAttrs["readonly"]) && !isset($agent_commission_list->date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagent_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagent_commissionlistsrch", "x_date", {"ignoreReadonly":true,"useCurrent":false,"format":7});
});
</script>
<?php } ?>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el_agent_commission_date_2" class="ew-search-field2 d-none">
<input type="text" data-table="agent_commission" data-field="x_date" data-format="7" name="y_date" id="y_date" maxlength="10" placeholder="<?php echo HtmlEncode($agent_commission_list->date->getPlaceHolder()) ?>" value="<?php echo $agent_commission_list->date->EditValue2 ?>"<?php echo $agent_commission_list->date->editAttributes() ?>>
<?php if (!$agent_commission_list->date->ReadOnly && !$agent_commission_list->date->Disabled && !isset($agent_commission_list->date->EditAttrs["readonly"]) && !isset($agent_commission_list->date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagent_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagent_commissionlistsrch", "y_date", {"ignoreReadonly":true,"useCurrent":false,"format":7});
});
</script>
<?php } ?>
</span>
	</div>
	<?php if ($agent_commission_list->SearchColumnCount % $agent_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->customer_name->Visible) { // customer_name ?>
	<?php
		$agent_commission_list->SearchColumnCount++;
		if (($agent_commission_list->SearchColumnCount - 1) % $agent_commission_list->SearchFieldsPerRow == 0) {
			$agent_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agent_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_customer_name" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $agent_commission_list->customer_name->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_customer_name" id="z_customer_name" value="LIKE">
</span>
		<span id="el_agent_commission_customer_name" class="ew-search-field">
<?php
$onchange = $agent_commission_list->customer_name->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_list->customer_name->EditAttrs["onchange"] = "";
?>
<span id="as_x_customer_name">
	<input type="text" class="form-control" name="sv_x_customer_name" id="sv_x_customer_name" value="<?php echo RemoveHtml($agent_commission_list->customer_name->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_list->customer_name->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_list->customer_name->getPlaceHolder()) ?>"<?php echo $agent_commission_list->customer_name->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_customer_name" data-value-separator="<?php echo $agent_commission_list->customer_name->displayValueSeparatorAttribute() ?>" name="x_customer_name" id="x_customer_name" value="<?php echo HtmlEncode($agent_commission_list->customer_name->AdvancedSearch->SearchValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionlistsrch"], function() {
	fagent_commissionlistsrch.createAutoSuggest({"id":"x_customer_name","forceSelect":false});
});
</script>
<?php echo $agent_commission_list->customer_name->Lookup->getParamTag($agent_commission_list, "p_x_customer_name") ?>
</span>
	</div>
	<?php if ($agent_commission_list->SearchColumnCount % $agent_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->ticket_name->Visible) { // ticket_name ?>
	<?php
		$agent_commission_list->SearchColumnCount++;
		if (($agent_commission_list->SearchColumnCount - 1) % $agent_commission_list->SearchFieldsPerRow == 0) {
			$agent_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agent_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_ticket_name" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $agent_commission_list->ticket_name->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_ticket_name" id="z_ticket_name" value="LIKE">
</span>
		<span id="el_agent_commission_ticket_name" class="ew-search-field">
<?php
$onchange = $agent_commission_list->ticket_name->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_list->ticket_name->EditAttrs["onchange"] = "";
?>
<span id="as_x_ticket_name">
	<input type="text" class="form-control" name="sv_x_ticket_name" id="sv_x_ticket_name" value="<?php echo RemoveHtml($agent_commission_list->ticket_name->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_list->ticket_name->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_list->ticket_name->getPlaceHolder()) ?>"<?php echo $agent_commission_list->ticket_name->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_ticket_name" data-value-separator="<?php echo $agent_commission_list->ticket_name->displayValueSeparatorAttribute() ?>" name="x_ticket_name" id="x_ticket_name" value="<?php echo HtmlEncode($agent_commission_list->ticket_name->AdvancedSearch->SearchValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionlistsrch"], function() {
	fagent_commissionlistsrch.createAutoSuggest({"id":"x_ticket_name","forceSelect":true});
});
</script>
<?php echo $agent_commission_list->ticket_name->Lookup->getParamTag($agent_commission_list, "p_x_ticket_name") ?>
</span>
	</div>
	<?php if ($agent_commission_list->SearchColumnCount % $agent_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->draw_date->Visible) { // draw_date ?>
	<?php
		$agent_commission_list->SearchColumnCount++;
		if (($agent_commission_list->SearchColumnCount - 1) % $agent_commission_list->SearchFieldsPerRow == 0) {
			$agent_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agent_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_draw_date" class="ew-cell form-group">
		<label class="ew-search-caption ew-label"><?php echo $agent_commission_list->draw_date->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_draw_date" id="z_draw_date" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="LIKE"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "LIKE" ? " selected" : "" ?>><?php echo $Language->phrase("LIKE") ?></option>
<option value="NOT LIKE"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "NOT LIKE" ? " selected" : "" ?>><?php echo $Language->phrase("NOT LIKE") ?></option>
<option value="STARTS WITH"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "STARTS WITH" ? " selected" : "" ?>><?php echo $Language->phrase("STARTS WITH") ?></option>
<option value="ENDS WITH"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "ENDS WITH" ? " selected" : "" ?>><?php echo $Language->phrase("ENDS WITH") ?></option>
<option value="IS NULL"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "IS NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NULL") ?></option>
<option value="IS NOT NULL"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "IS NOT NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NOT NULL") ?></option>
<option value="BETWEEN"<?php echo $agent_commission_list->draw_date->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_agent_commission_draw_date" class="ew-search-field">
<?php
$onchange = $agent_commission_list->draw_date->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_list->draw_date->EditAttrs["onchange"] = "";
?>
<span id="as_x_draw_date">
	<input type="text" class="form-control" name="sv_x_draw_date" id="sv_x_draw_date" value="<?php echo RemoveHtml($agent_commission_list->draw_date->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_list->draw_date->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_list->draw_date->getPlaceHolder()) ?>"<?php echo $agent_commission_list->draw_date->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_draw_date" data-value-separator="<?php echo $agent_commission_list->draw_date->displayValueSeparatorAttribute() ?>" name="x_draw_date" id="x_draw_date" value="<?php echo HtmlEncode($agent_commission_list->draw_date->AdvancedSearch->SearchValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionlistsrch"], function() {
	fagent_commissionlistsrch.createAutoSuggest({"id":"x_draw_date","forceSelect":true});
});
</script>
<?php echo $agent_commission_list->draw_date->Lookup->getParamTag($agent_commission_list, "p_x_draw_date") ?>
<?php if (!$agent_commission_list->draw_date->ReadOnly && !$agent_commission_list->draw_date->Disabled && !isset($agent_commission_list->draw_date->EditAttrs["readonly"]) && !isset($agent_commission_list->draw_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagent_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagent_commissionlistsrch", "x_draw_date", {"ignoreReadonly":true,"useCurrent":false,"format":7});
});
</script>
<?php } ?>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el_agent_commission_draw_date_2" class="ew-search-field2 d-none">
<?php
$onchange = $agent_commission_list->draw_date->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agent_commission_list->draw_date->EditAttrs["onchange"] = "";
?>
<span id="as_y_draw_date">
	<input type="text" class="form-control" name="sv_y_draw_date" id="sv_y_draw_date" value="<?php echo RemoveHtml($agent_commission_list->draw_date->EditValue2) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agent_commission_list->draw_date->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agent_commission_list->draw_date->getPlaceHolder()) ?>"<?php echo $agent_commission_list->draw_date->editAttributes() ?>>
</span>
<input type="hidden" data-table="agent_commission" data-field="x_draw_date" data-value-separator="<?php echo $agent_commission_list->draw_date->displayValueSeparatorAttribute() ?>" name="y_draw_date" id="y_draw_date" value="<?php echo HtmlEncode($agent_commission_list->draw_date->AdvancedSearch->SearchValue2) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagent_commissionlistsrch"], function() {
	fagent_commissionlistsrch.createAutoSuggest({"id":"y_draw_date","forceSelect":true});
});
</script>
<?php echo $agent_commission_list->draw_date->Lookup->getParamTag($agent_commission_list, "p_y_draw_date") ?>
<?php if (!$agent_commission_list->draw_date->ReadOnly && !$agent_commission_list->draw_date->Disabled && !isset($agent_commission_list->draw_date->EditAttrs["readonly"]) && !isset($agent_commission_list->draw_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagent_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagent_commissionlistsrch", "y_draw_date", {"ignoreReadonly":true,"useCurrent":false,"format":7});
});
</script>
<?php } ?>
</span>
	</div>
	<?php if ($agent_commission_list->SearchColumnCount % $agent_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($agent_commission_list->SearchColumnCount % $agent_commission_list->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $agent_commission_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($agent_commission_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($agent_commission_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $agent_commission_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($agent_commission_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($agent_commission_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($agent_commission_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($agent_commission_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $agent_commission_list->showPageHeader(); ?>
<?php
$agent_commission_list->showMessage();
?>
<?php if ($agent_commission_list->TotalRecords > 0 || $agent_commission->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($agent_commission_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> agent_commission">
<?php if (!$agent_commission_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$agent_commission_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $agent_commission_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $agent_commission_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="fagent_commissionlist" id="fagent_commissionlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agent_commission">
<div id="gmp_agent_commission" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($agent_commission_list->TotalRecords > 0 || $agent_commission_list->isGridEdit()) { ?>
<table id="tbl_agent_commissionlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$agent_commission->RowType = ROWTYPE_HEADER;

// Render list options
$agent_commission_list->renderListOptions();

// Render list options (header, left)
$agent_commission_list->ListOptions->render("header", "left");
?>
<?php if ($agent_commission_list->slno->Visible) { // slno ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->slno) == "") { ?>
		<th data-name="slno" class="<?php echo $agent_commission_list->slno->headerCellClass() ?>"><div id="elh_agent_commission_slno" class="agent_commission_slno"><div class="ew-table-header-caption"><?php echo $agent_commission_list->slno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="slno" class="<?php echo $agent_commission_list->slno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->slno) ?>', 1);"><div id="elh_agent_commission_slno" class="agent_commission_slno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->slno->caption() ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->slno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->slno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->date->Visible) { // date ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->date) == "") { ?>
		<th data-name="date" class="<?php echo $agent_commission_list->date->headerCellClass() ?>"><div id="elh_agent_commission_date" class="agent_commission_date"><div class="ew-table-header-caption"><?php echo $agent_commission_list->date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="date" class="<?php echo $agent_commission_list->date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->date) ?>', 1);"><div id="elh_agent_commission_date" class="agent_commission_date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->date->caption() ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->date->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->date->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->time->Visible) { // time ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->time) == "") { ?>
		<th data-name="time" class="<?php echo $agent_commission_list->time->headerCellClass() ?>"><div id="elh_agent_commission_time" class="agent_commission_time"><div class="ew-table-header-caption"><?php echo $agent_commission_list->time->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="time" class="<?php echo $agent_commission_list->time->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->time) ?>', 1);"><div id="elh_agent_commission_time" class="agent_commission_time">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->time->caption() ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->time->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->time->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->dc_number->Visible) { // dc_number ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->dc_number) == "") { ?>
		<th data-name="dc_number" class="<?php echo $agent_commission_list->dc_number->headerCellClass() ?>"><div id="elh_agent_commission_dc_number" class="agent_commission_dc_number"><div class="ew-table-header-caption"><?php echo $agent_commission_list->dc_number->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dc_number" class="<?php echo $agent_commission_list->dc_number->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->dc_number) ?>', 1);"><div id="elh_agent_commission_dc_number" class="agent_commission_dc_number">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->dc_number->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->dc_number->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->dc_number->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->customer_name->Visible) { // customer_name ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->customer_name) == "") { ?>
		<th data-name="customer_name" class="<?php echo $agent_commission_list->customer_name->headerCellClass() ?>"><div id="elh_agent_commission_customer_name" class="agent_commission_customer_name"><div class="ew-table-header-caption"><?php echo $agent_commission_list->customer_name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="customer_name" class="<?php echo $agent_commission_list->customer_name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->customer_name) ?>', 1);"><div id="elh_agent_commission_customer_name" class="agent_commission_customer_name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->customer_name->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->customer_name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->customer_name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->ticket_name->Visible) { // ticket_name ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->ticket_name) == "") { ?>
		<th data-name="ticket_name" class="<?php echo $agent_commission_list->ticket_name->headerCellClass() ?>"><div id="elh_agent_commission_ticket_name" class="agent_commission_ticket_name"><div class="ew-table-header-caption"><?php echo $agent_commission_list->ticket_name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ticket_name" class="<?php echo $agent_commission_list->ticket_name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->ticket_name) ?>', 1);"><div id="elh_agent_commission_ticket_name" class="agent_commission_ticket_name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->ticket_name->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->ticket_name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->ticket_name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->draw_date->Visible) { // draw_date ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->draw_date) == "") { ?>
		<th data-name="draw_date" class="<?php echo $agent_commission_list->draw_date->headerCellClass() ?>"><div id="elh_agent_commission_draw_date" class="agent_commission_draw_date"><div class="ew-table-header-caption"><?php echo $agent_commission_list->draw_date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="draw_date" class="<?php echo $agent_commission_list->draw_date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->draw_date) ?>', 1);"><div id="elh_agent_commission_draw_date" class="agent_commission_draw_date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->draw_date->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->draw_date->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->draw_date->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->ticket_catagory->Visible) { // ticket_catagory ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->ticket_catagory) == "") { ?>
		<th data-name="ticket_catagory" class="<?php echo $agent_commission_list->ticket_catagory->headerCellClass() ?>"><div id="elh_agent_commission_ticket_catagory" class="agent_commission_ticket_catagory"><div class="ew-table-header-caption"><?php echo $agent_commission_list->ticket_catagory->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ticket_catagory" class="<?php echo $agent_commission_list->ticket_catagory->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->ticket_catagory) ?>', 1);"><div id="elh_agent_commission_ticket_catagory" class="agent_commission_ticket_catagory">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->ticket_catagory->caption() ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->ticket_catagory->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->ticket_catagory->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->dc_type->Visible) { // dc_type ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->dc_type) == "") { ?>
		<th data-name="dc_type" class="<?php echo $agent_commission_list->dc_type->headerCellClass() ?>"><div id="elh_agent_commission_dc_type" class="agent_commission_dc_type"><div class="ew-table-header-caption"><?php echo $agent_commission_list->dc_type->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dc_type" class="<?php echo $agent_commission_list->dc_type->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->dc_type) ?>', 1);"><div id="elh_agent_commission_dc_type" class="agent_commission_dc_type">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->dc_type->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->dc_type->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->dc_type->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->commission_amount->Visible) { // commission_amount ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->commission_amount) == "") { ?>
		<th data-name="commission_amount" class="<?php echo $agent_commission_list->commission_amount->headerCellClass() ?>"><div id="elh_agent_commission_commission_amount" class="agent_commission_commission_amount"><div class="ew-table-header-caption"><?php echo $agent_commission_list->commission_amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="commission_amount" class="<?php echo $agent_commission_list->commission_amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->commission_amount) ?>', 1);"><div id="elh_agent_commission_commission_amount" class="agent_commission_commission_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->commission_amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->commission_amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->commission_amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->agency_dc->Visible) { // agency_dc ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->agency_dc) == "") { ?>
		<th data-name="agency_dc" class="<?php echo $agent_commission_list->agency_dc->headerCellClass() ?>"><div id="elh_agent_commission_agency_dc" class="agent_commission_agency_dc"><div class="ew-table-header-caption"><?php echo $agent_commission_list->agency_dc->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="agency_dc" class="<?php echo $agent_commission_list->agency_dc->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->agency_dc) ?>', 1);"><div id="elh_agent_commission_agency_dc" class="agent_commission_agency_dc">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->agency_dc->caption() ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->agency_dc->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->agency_dc->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->total_dc->Visible) { // total_dc ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->total_dc) == "") { ?>
		<th data-name="total_dc" class="<?php echo $agent_commission_list->total_dc->headerCellClass() ?>"><div id="elh_agent_commission_total_dc" class="agent_commission_total_dc"><div class="ew-table-header-caption"><?php echo $agent_commission_list->total_dc->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="total_dc" class="<?php echo $agent_commission_list->total_dc->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->total_dc) ?>', 1);"><div id="elh_agent_commission_total_dc" class="agent_commission_total_dc">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->total_dc->caption() ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->total_dc->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->total_dc->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agent_commission_list->add_user->Visible) { // add_user ?>
	<?php if ($agent_commission_list->SortUrl($agent_commission_list->add_user) == "") { ?>
		<th data-name="add_user" class="<?php echo $agent_commission_list->add_user->headerCellClass() ?>"><div id="elh_agent_commission_add_user" class="agent_commission_add_user"><div class="ew-table-header-caption"><?php echo $agent_commission_list->add_user->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="add_user" class="<?php echo $agent_commission_list->add_user->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agent_commission_list->SortUrl($agent_commission_list->add_user) ?>', 1);"><div id="elh_agent_commission_add_user" class="agent_commission_add_user">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agent_commission_list->add_user->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agent_commission_list->add_user->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agent_commission_list->add_user->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$agent_commission_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($agent_commission_list->ExportAll && $agent_commission_list->isExport()) {
	$agent_commission_list->StopRecord = $agent_commission_list->TotalRecords;
} else {

	// Set the last record to display
	if ($agent_commission_list->TotalRecords > $agent_commission_list->StartRecord + $agent_commission_list->DisplayRecords - 1)
		$agent_commission_list->StopRecord = $agent_commission_list->StartRecord + $agent_commission_list->DisplayRecords - 1;
	else
		$agent_commission_list->StopRecord = $agent_commission_list->TotalRecords;
}
$agent_commission_list->RecordCount = $agent_commission_list->StartRecord - 1;
if ($agent_commission_list->Recordset && !$agent_commission_list->Recordset->EOF) {
	$agent_commission_list->Recordset->moveFirst();
	$selectLimit = $agent_commission_list->UseSelectLimit;
	if (!$selectLimit && $agent_commission_list->StartRecord > 1)
		$agent_commission_list->Recordset->move($agent_commission_list->StartRecord - 1);
} elseif (!$agent_commission->AllowAddDeleteRow && $agent_commission_list->StopRecord == 0) {
	$agent_commission_list->StopRecord = $agent_commission->GridAddRowCount;
}

// Initialize aggregate
$agent_commission->RowType = ROWTYPE_AGGREGATEINIT;
$agent_commission->resetAttributes();
$agent_commission_list->renderRow();
while ($agent_commission_list->RecordCount < $agent_commission_list->StopRecord) {
	$agent_commission_list->RecordCount++;
	if ($agent_commission_list->RecordCount >= $agent_commission_list->StartRecord) {
		$agent_commission_list->RowCount++;

		// Set up key count
		$agent_commission_list->KeyCount = $agent_commission_list->RowIndex;

		// Init row class and style
		$agent_commission->resetAttributes();
		$agent_commission->CssClass = "";
		if ($agent_commission_list->isGridAdd()) {
		} else {
			$agent_commission_list->loadRowValues($agent_commission_list->Recordset); // Load row values
		}
		$agent_commission->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$agent_commission->RowAttrs->merge(["data-rowindex" => $agent_commission_list->RowCount, "id" => "r" . $agent_commission_list->RowCount . "_agent_commission", "data-rowtype" => $agent_commission->RowType]);

		// Render row
		$agent_commission_list->renderRow();

		// Render list options
		$agent_commission_list->renderListOptions();
?>
	<tr <?php echo $agent_commission->rowAttributes() ?>>
<?php

// Render list options (body, left)
$agent_commission_list->ListOptions->render("body", "left", $agent_commission_list->RowCount);
?>
	<?php if ($agent_commission_list->slno->Visible) { // slno ?>
		<td data-name="slno" <?php echo $agent_commission_list->slno->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_slno">
<span<?php echo $agent_commission_list->slno->viewAttributes() ?>><?php echo $agent_commission_list->slno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->date->Visible) { // date ?>
		<td data-name="date" <?php echo $agent_commission_list->date->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_date">
<span<?php echo $agent_commission_list->date->viewAttributes() ?>><?php echo $agent_commission_list->date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->time->Visible) { // time ?>
		<td data-name="time" <?php echo $agent_commission_list->time->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_time">
<span<?php echo $agent_commission_list->time->viewAttributes() ?>><?php echo $agent_commission_list->time->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->dc_number->Visible) { // dc_number ?>
		<td data-name="dc_number" <?php echo $agent_commission_list->dc_number->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_dc_number">
<span<?php echo $agent_commission_list->dc_number->viewAttributes() ?>><?php echo $agent_commission_list->dc_number->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->customer_name->Visible) { // customer_name ?>
		<td data-name="customer_name" <?php echo $agent_commission_list->customer_name->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_customer_name">
<span<?php echo $agent_commission_list->customer_name->viewAttributes() ?>><?php echo $agent_commission_list->customer_name->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->ticket_name->Visible) { // ticket_name ?>
		<td data-name="ticket_name" <?php echo $agent_commission_list->ticket_name->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_ticket_name">
<span<?php echo $agent_commission_list->ticket_name->viewAttributes() ?>><?php echo $agent_commission_list->ticket_name->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->draw_date->Visible) { // draw_date ?>
		<td data-name="draw_date" <?php echo $agent_commission_list->draw_date->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_draw_date">
<span<?php echo $agent_commission_list->draw_date->viewAttributes() ?>><?php echo $agent_commission_list->draw_date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->ticket_catagory->Visible) { // ticket_catagory ?>
		<td data-name="ticket_catagory" <?php echo $agent_commission_list->ticket_catagory->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_ticket_catagory">
<span<?php echo $agent_commission_list->ticket_catagory->viewAttributes() ?>><?php echo $agent_commission_list->ticket_catagory->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->dc_type->Visible) { // dc_type ?>
		<td data-name="dc_type" <?php echo $agent_commission_list->dc_type->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_dc_type">
<span<?php echo $agent_commission_list->dc_type->viewAttributes() ?>><?php echo $agent_commission_list->dc_type->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->commission_amount->Visible) { // commission_amount ?>
		<td data-name="commission_amount" <?php echo $agent_commission_list->commission_amount->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_commission_amount">
<span<?php echo $agent_commission_list->commission_amount->viewAttributes() ?>><?php echo $agent_commission_list->commission_amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->agency_dc->Visible) { // agency_dc ?>
		<td data-name="agency_dc" <?php echo $agent_commission_list->agency_dc->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_agency_dc">
<span<?php echo $agent_commission_list->agency_dc->viewAttributes() ?>><?php echo $agent_commission_list->agency_dc->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->total_dc->Visible) { // total_dc ?>
		<td data-name="total_dc" <?php echo $agent_commission_list->total_dc->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_total_dc">
<span<?php echo $agent_commission_list->total_dc->viewAttributes() ?>><?php echo $agent_commission_list->total_dc->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agent_commission_list->add_user->Visible) { // add_user ?>
		<td data-name="add_user" <?php echo $agent_commission_list->add_user->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_list->RowCount ?>_agent_commission_add_user">
<span<?php echo $agent_commission_list->add_user->viewAttributes() ?>><?php echo $agent_commission_list->add_user->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$agent_commission_list->ListOptions->render("body", "right", $agent_commission_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$agent_commission_list->isGridAdd())
		$agent_commission_list->Recordset->moveNext();
}
?>
</tbody>
<?php

// Render aggregate row
$agent_commission->RowType = ROWTYPE_AGGREGATE;
$agent_commission->resetAttributes();
$agent_commission_list->renderRow();
?>
<?php if ($agent_commission_list->TotalRecords > 0 && !$agent_commission_list->isGridAdd() && !$agent_commission_list->isGridEdit()) { ?>
<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options
$agent_commission_list->renderListOptions();

// Render list options (footer, left)
$agent_commission_list->ListOptions->render("footer", "left");
?>
	<?php if ($agent_commission_list->slno->Visible) { // slno ?>
		<td data-name="slno" class="<?php echo $agent_commission_list->slno->footerCellClass() ?>"><span id="elf_agent_commission_slno" class="agent_commission_slno">
		<span class="ew-aggregate"><?php echo $Language->phrase("COUNT") ?></span><span class="ew-aggregate-value">
		<?php echo $agent_commission_list->slno->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->date->Visible) { // date ?>
		<td data-name="date" class="<?php echo $agent_commission_list->date->footerCellClass() ?>"><span id="elf_agent_commission_date" class="agent_commission_date">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->time->Visible) { // time ?>
		<td data-name="time" class="<?php echo $agent_commission_list->time->footerCellClass() ?>"><span id="elf_agent_commission_time" class="agent_commission_time">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->dc_number->Visible) { // dc_number ?>
		<td data-name="dc_number" class="<?php echo $agent_commission_list->dc_number->footerCellClass() ?>"><span id="elf_agent_commission_dc_number" class="agent_commission_dc_number">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->customer_name->Visible) { // customer_name ?>
		<td data-name="customer_name" class="<?php echo $agent_commission_list->customer_name->footerCellClass() ?>"><span id="elf_agent_commission_customer_name" class="agent_commission_customer_name">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->ticket_name->Visible) { // ticket_name ?>
		<td data-name="ticket_name" class="<?php echo $agent_commission_list->ticket_name->footerCellClass() ?>"><span id="elf_agent_commission_ticket_name" class="agent_commission_ticket_name">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->draw_date->Visible) { // draw_date ?>
		<td data-name="draw_date" class="<?php echo $agent_commission_list->draw_date->footerCellClass() ?>"><span id="elf_agent_commission_draw_date" class="agent_commission_draw_date">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->ticket_catagory->Visible) { // ticket_catagory ?>
		<td data-name="ticket_catagory" class="<?php echo $agent_commission_list->ticket_catagory->footerCellClass() ?>"><span id="elf_agent_commission_ticket_catagory" class="agent_commission_ticket_catagory">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->dc_type->Visible) { // dc_type ?>
		<td data-name="dc_type" class="<?php echo $agent_commission_list->dc_type->footerCellClass() ?>"><span id="elf_agent_commission_dc_type" class="agent_commission_dc_type">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->commission_amount->Visible) { // commission_amount ?>
		<td data-name="commission_amount" class="<?php echo $agent_commission_list->commission_amount->footerCellClass() ?>"><span id="elf_agent_commission_commission_amount" class="agent_commission_commission_amount">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $agent_commission_list->commission_amount->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->agency_dc->Visible) { // agency_dc ?>
		<td data-name="agency_dc" class="<?php echo $agent_commission_list->agency_dc->footerCellClass() ?>"><span id="elf_agent_commission_agency_dc" class="agent_commission_agency_dc">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $agent_commission_list->agency_dc->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->total_dc->Visible) { // total_dc ?>
		<td data-name="total_dc" class="<?php echo $agent_commission_list->total_dc->footerCellClass() ?>"><span id="elf_agent_commission_total_dc" class="agent_commission_total_dc">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $agent_commission_list->total_dc->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($agent_commission_list->add_user->Visible) { // add_user ?>
		<td data-name="add_user" class="<?php echo $agent_commission_list->add_user->footerCellClass() ?>"><span id="elf_agent_commission_add_user" class="agent_commission_add_user">
		&nbsp;
		</span></td>
	<?php } ?>
<?php

// Render list options (footer, right)
$agent_commission_list->ListOptions->render("footer", "right");
?>
	</tr>
</tfoot>
<?php } ?>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$agent_commission->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($agent_commission_list->Recordset)
	$agent_commission_list->Recordset->Close();
?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($agent_commission_list->TotalRecords == 0 && !$agent_commission->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $agent_commission_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$agent_commission_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$agent_commission_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$agent_commission_list->terminate();
?>