<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agency_commission_list = new agency_commission_list();

// Run the page
$agency_commission_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agency_commission_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$agency_commission_list->isExport()) { ?>
<script>
var fagency_commissionlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fagency_commissionlist = currentForm = new ew.Form("fagency_commissionlist", "list");
	fagency_commissionlist.formKeyCountName = '<?php echo $agency_commission_list->FormKeyCountName ?>';
	loadjs.done("fagency_commissionlist");
});
var fagency_commissionlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fagency_commissionlistsrch = currentSearchForm = new ew.Form("fagency_commissionlistsrch");

	// Validate function for search
	fagency_commissionlistsrch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_draw_date");
		if (elm && !ew.checkEuroDate(elm.value))
			return this.onError(elm, "<?php echo JsEncode($agency_commission_list->draw_date->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_add_date");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($agency_commission_list->add_date->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fagency_commissionlistsrch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fagency_commissionlistsrch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fagency_commissionlistsrch.lists["x_agent"] = <?php echo $agency_commission_list->agent->Lookup->toClientList($agency_commission_list) ?>;
	fagency_commissionlistsrch.lists["x_agent"].options = <?php echo JsonEncode($agency_commission_list->agent->lookupOptions()) ?>;

	// Filters
	fagency_commissionlistsrch.filterList = <?php echo $agency_commission_list->getFilterList() ?>;

	// Init search panel as collapsed
	fagency_commissionlistsrch.initSearchPanel = true;
	loadjs.done("fagency_commissionlistsrch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$agency_commission_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($agency_commission_list->TotalRecords > 0 && $agency_commission_list->ExportOptions->visible()) { ?>
<?php $agency_commission_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($agency_commission_list->ImportOptions->visible()) { ?>
<?php $agency_commission_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($agency_commission_list->SearchOptions->visible()) { ?>
<?php $agency_commission_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($agency_commission_list->FilterOptions->visible()) { ?>
<?php $agency_commission_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$agency_commission_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$agency_commission_list->isExport() && !$agency_commission->CurrentAction) { ?>
<form name="fagency_commissionlistsrch" id="fagency_commissionlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fagency_commissionlistsrch-search-panel" class="<?php echo $agency_commission_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="agency_commission">
	<div class="ew-extended-search">
<?php

// Render search row
$agency_commission->RowType = ROWTYPE_SEARCH;
$agency_commission->resetAttributes();
$agency_commission_list->renderRow();
?>
<?php if ($agency_commission_list->agent->Visible) { // agent ?>
	<?php
		$agency_commission_list->SearchColumnCount++;
		if (($agency_commission_list->SearchColumnCount - 1) % $agency_commission_list->SearchFieldsPerRow == 0) {
			$agency_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agency_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_agent" class="ew-cell form-group">
		<label for="x_agent" class="ew-search-caption ew-label"><?php echo $agency_commission_list->agent->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_agent" id="z_agent" value="LIKE">
</span>
		<span id="el_agency_commission_agent" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="agency_commission" data-field="x_agent" data-value-separator="<?php echo $agency_commission_list->agent->displayValueSeparatorAttribute() ?>" id="x_agent" name="x_agent"<?php echo $agency_commission_list->agent->editAttributes() ?>>
			<?php echo $agency_commission_list->agent->selectOptionListHtml("x_agent") ?>
		</select>
</div>
<?php echo $agency_commission_list->agent->Lookup->getParamTag($agency_commission_list, "p_x_agent") ?>
</span>
	</div>
	<?php if ($agency_commission_list->SearchColumnCount % $agency_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->ticket_name->Visible) { // ticket_name ?>
	<?php
		$agency_commission_list->SearchColumnCount++;
		if (($agency_commission_list->SearchColumnCount - 1) % $agency_commission_list->SearchFieldsPerRow == 0) {
			$agency_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agency_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_ticket_name" class="ew-cell form-group">
		<label for="x_ticket_name" class="ew-search-caption ew-label"><?php echo $agency_commission_list->ticket_name->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_ticket_name" id="z_ticket_name" value="LIKE">
</span>
		<span id="el_agency_commission_ticket_name" class="ew-search-field">
<input type="text" data-table="agency_commission" data-field="x_ticket_name" name="x_ticket_name" id="x_ticket_name" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agency_commission_list->ticket_name->getPlaceHolder()) ?>" value="<?php echo $agency_commission_list->ticket_name->EditValue ?>"<?php echo $agency_commission_list->ticket_name->editAttributes() ?>>
</span>
	</div>
	<?php if ($agency_commission_list->SearchColumnCount % $agency_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->draw_date->Visible) { // draw_date ?>
	<?php
		$agency_commission_list->SearchColumnCount++;
		if (($agency_commission_list->SearchColumnCount - 1) % $agency_commission_list->SearchFieldsPerRow == 0) {
			$agency_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agency_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_draw_date" class="ew-cell form-group">
		<label for="x_draw_date" class="ew-search-caption ew-label"><?php echo $agency_commission_list->draw_date->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_draw_date" id="z_draw_date" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $agency_commission_list->draw_date->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $agency_commission_list->draw_date->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $agency_commission_list->draw_date->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $agency_commission_list->draw_date->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $agency_commission_list->draw_date->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $agency_commission_list->draw_date->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="BETWEEN"<?php echo $agency_commission_list->draw_date->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_agency_commission_draw_date" class="ew-search-field">
<input type="text" data-table="agency_commission" data-field="x_draw_date" data-format="7" name="x_draw_date" id="x_draw_date" maxlength="10" placeholder="<?php echo HtmlEncode($agency_commission_list->draw_date->getPlaceHolder()) ?>" value="<?php echo $agency_commission_list->draw_date->EditValue ?>"<?php echo $agency_commission_list->draw_date->editAttributes() ?>>
<?php if (!$agency_commission_list->draw_date->ReadOnly && !$agency_commission_list->draw_date->Disabled && !isset($agency_commission_list->draw_date->EditAttrs["readonly"]) && !isset($agency_commission_list->draw_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagency_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagency_commissionlistsrch", "x_draw_date", {"ignoreReadonly":true,"useCurrent":false,"format":7});
});
</script>
<?php } ?>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el_agency_commission_draw_date_2" class="ew-search-field2 d-none">
<input type="text" data-table="agency_commission" data-field="x_draw_date" data-format="7" name="y_draw_date" id="y_draw_date" maxlength="10" placeholder="<?php echo HtmlEncode($agency_commission_list->draw_date->getPlaceHolder()) ?>" value="<?php echo $agency_commission_list->draw_date->EditValue2 ?>"<?php echo $agency_commission_list->draw_date->editAttributes() ?>>
<?php if (!$agency_commission_list->draw_date->ReadOnly && !$agency_commission_list->draw_date->Disabled && !isset($agency_commission_list->draw_date->EditAttrs["readonly"]) && !isset($agency_commission_list->draw_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagency_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagency_commissionlistsrch", "y_draw_date", {"ignoreReadonly":true,"useCurrent":false,"format":7});
});
</script>
<?php } ?>
</span>
	</div>
	<?php if ($agency_commission_list->SearchColumnCount % $agency_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->add_date->Visible) { // add_date ?>
	<?php
		$agency_commission_list->SearchColumnCount++;
		if (($agency_commission_list->SearchColumnCount - 1) % $agency_commission_list->SearchFieldsPerRow == 0) {
			$agency_commission_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $agency_commission_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_add_date" class="ew-cell form-group">
		<label for="x_add_date" class="ew-search-caption ew-label"><?php echo $agency_commission_list->add_date->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_add_date" id="z_add_date" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $agency_commission_list->add_date->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $agency_commission_list->add_date->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $agency_commission_list->add_date->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $agency_commission_list->add_date->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $agency_commission_list->add_date->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $agency_commission_list->add_date->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="BETWEEN"<?php echo $agency_commission_list->add_date->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_agency_commission_add_date" class="ew-search-field">
<input type="text" data-table="agency_commission" data-field="x_add_date" name="x_add_date" id="x_add_date" maxlength="10" placeholder="<?php echo HtmlEncode($agency_commission_list->add_date->getPlaceHolder()) ?>" value="<?php echo $agency_commission_list->add_date->EditValue ?>"<?php echo $agency_commission_list->add_date->editAttributes() ?>>
<?php if (!$agency_commission_list->add_date->ReadOnly && !$agency_commission_list->add_date->Disabled && !isset($agency_commission_list->add_date->EditAttrs["readonly"]) && !isset($agency_commission_list->add_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagency_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagency_commissionlistsrch", "x_add_date", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el_agency_commission_add_date_2" class="ew-search-field2 d-none">
<input type="text" data-table="agency_commission" data-field="x_add_date" name="y_add_date" id="y_add_date" maxlength="10" placeholder="<?php echo HtmlEncode($agency_commission_list->add_date->getPlaceHolder()) ?>" value="<?php echo $agency_commission_list->add_date->EditValue2 ?>"<?php echo $agency_commission_list->add_date->editAttributes() ?>>
<?php if (!$agency_commission_list->add_date->ReadOnly && !$agency_commission_list->add_date->Disabled && !isset($agency_commission_list->add_date->EditAttrs["readonly"]) && !isset($agency_commission_list->add_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fagency_commissionlistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fagency_commissionlistsrch", "y_add_date", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
	</div>
	<?php if ($agency_commission_list->SearchColumnCount % $agency_commission_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($agency_commission_list->SearchColumnCount % $agency_commission_list->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $agency_commission_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($agency_commission_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($agency_commission_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $agency_commission_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($agency_commission_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($agency_commission_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($agency_commission_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($agency_commission_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $agency_commission_list->showPageHeader(); ?>
<?php
$agency_commission_list->showMessage();
?>
<?php if ($agency_commission_list->TotalRecords > 0 || $agency_commission->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($agency_commission_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> agency_commission">
<?php if (!$agency_commission_list->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$agency_commission_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $agency_commission_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $agency_commission_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="fagency_commissionlist" id="fagency_commissionlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agency_commission">
<div id="gmp_agency_commission" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($agency_commission_list->TotalRecords > 0 || $agency_commission_list->isGridEdit()) { ?>
<table id="tbl_agency_commissionlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$agency_commission->RowType = ROWTYPE_HEADER;

// Render list options
$agency_commission_list->renderListOptions();

// Render list options (header, left)
$agency_commission_list->ListOptions->render("header", "left");
?>
<?php if ($agency_commission_list->slno->Visible) { // slno ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->slno) == "") { ?>
		<th data-name="slno" class="<?php echo $agency_commission_list->slno->headerCellClass() ?>"><div id="elh_agency_commission_slno" class="agency_commission_slno"><div class="ew-table-header-caption"><?php echo $agency_commission_list->slno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="slno" class="<?php echo $agency_commission_list->slno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->slno) ?>', 1);"><div id="elh_agency_commission_slno" class="agency_commission_slno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->slno->caption() ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->slno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->slno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->agent->Visible) { // agent ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->agent) == "") { ?>
		<th data-name="agent" class="<?php echo $agency_commission_list->agent->headerCellClass() ?>"><div id="elh_agency_commission_agent" class="agency_commission_agent"><div class="ew-table-header-caption"><?php echo $agency_commission_list->agent->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="agent" class="<?php echo $agency_commission_list->agent->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->agent) ?>', 1);"><div id="elh_agency_commission_agent" class="agency_commission_agent">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->agent->caption() ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->agent->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->agent->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->draw_code->Visible) { // draw_code ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->draw_code) == "") { ?>
		<th data-name="draw_code" class="<?php echo $agency_commission_list->draw_code->headerCellClass() ?>"><div id="elh_agency_commission_draw_code" class="agency_commission_draw_code"><div class="ew-table-header-caption"><?php echo $agency_commission_list->draw_code->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="draw_code" class="<?php echo $agency_commission_list->draw_code->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->draw_code) ?>', 1);"><div id="elh_agency_commission_draw_code" class="agency_commission_draw_code">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->draw_code->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->draw_code->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->draw_code->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->ticket_name->Visible) { // ticket_name ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->ticket_name) == "") { ?>
		<th data-name="ticket_name" class="<?php echo $agency_commission_list->ticket_name->headerCellClass() ?>"><div id="elh_agency_commission_ticket_name" class="agency_commission_ticket_name"><div class="ew-table-header-caption"><?php echo $agency_commission_list->ticket_name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ticket_name" class="<?php echo $agency_commission_list->ticket_name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->ticket_name) ?>', 1);"><div id="elh_agency_commission_ticket_name" class="agency_commission_ticket_name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->ticket_name->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->ticket_name->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->ticket_name->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->draw_date->Visible) { // draw_date ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->draw_date) == "") { ?>
		<th data-name="draw_date" class="<?php echo $agency_commission_list->draw_date->headerCellClass() ?>"><div id="elh_agency_commission_draw_date" class="agency_commission_draw_date"><div class="ew-table-header-caption"><?php echo $agency_commission_list->draw_date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="draw_date" class="<?php echo $agency_commission_list->draw_date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->draw_date) ?>', 1);"><div id="elh_agency_commission_draw_date" class="agency_commission_draw_date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->draw_date->caption() ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->draw_date->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->draw_date->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->commission->Visible) { // commission ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->commission) == "") { ?>
		<th data-name="commission" class="<?php echo $agency_commission_list->commission->headerCellClass() ?>"><div id="elh_agency_commission_commission" class="agency_commission_commission"><div class="ew-table-header-caption"><?php echo $agency_commission_list->commission->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="commission" class="<?php echo $agency_commission_list->commission->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->commission) ?>', 1);"><div id="elh_agency_commission_commission" class="agency_commission_commission">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->commission->caption() ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->commission->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->commission->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->add_date->Visible) { // add_date ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->add_date) == "") { ?>
		<th data-name="add_date" class="<?php echo $agency_commission_list->add_date->headerCellClass() ?>"><div id="elh_agency_commission_add_date" class="agency_commission_add_date"><div class="ew-table-header-caption"><?php echo $agency_commission_list->add_date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="add_date" class="<?php echo $agency_commission_list->add_date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->add_date) ?>', 1);"><div id="elh_agency_commission_add_date" class="agency_commission_add_date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->add_date->caption() ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->add_date->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->add_date->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($agency_commission_list->add_user->Visible) { // add_user ?>
	<?php if ($agency_commission_list->SortUrl($agency_commission_list->add_user) == "") { ?>
		<th data-name="add_user" class="<?php echo $agency_commission_list->add_user->headerCellClass() ?>"><div id="elh_agency_commission_add_user" class="agency_commission_add_user"><div class="ew-table-header-caption"><?php echo $agency_commission_list->add_user->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="add_user" class="<?php echo $agency_commission_list->add_user->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $agency_commission_list->SortUrl($agency_commission_list->add_user) ?>', 1);"><div id="elh_agency_commission_add_user" class="agency_commission_add_user">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $agency_commission_list->add_user->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($agency_commission_list->add_user->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($agency_commission_list->add_user->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$agency_commission_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($agency_commission_list->ExportAll && $agency_commission_list->isExport()) {
	$agency_commission_list->StopRecord = $agency_commission_list->TotalRecords;
} else {

	// Set the last record to display
	if ($agency_commission_list->TotalRecords > $agency_commission_list->StartRecord + $agency_commission_list->DisplayRecords - 1)
		$agency_commission_list->StopRecord = $agency_commission_list->StartRecord + $agency_commission_list->DisplayRecords - 1;
	else
		$agency_commission_list->StopRecord = $agency_commission_list->TotalRecords;
}
$agency_commission_list->RecordCount = $agency_commission_list->StartRecord - 1;
if ($agency_commission_list->Recordset && !$agency_commission_list->Recordset->EOF) {
	$agency_commission_list->Recordset->moveFirst();
	$selectLimit = $agency_commission_list->UseSelectLimit;
	if (!$selectLimit && $agency_commission_list->StartRecord > 1)
		$agency_commission_list->Recordset->move($agency_commission_list->StartRecord - 1);
} elseif (!$agency_commission->AllowAddDeleteRow && $agency_commission_list->StopRecord == 0) {
	$agency_commission_list->StopRecord = $agency_commission->GridAddRowCount;
}

// Initialize aggregate
$agency_commission->RowType = ROWTYPE_AGGREGATEINIT;
$agency_commission->resetAttributes();
$agency_commission_list->renderRow();
while ($agency_commission_list->RecordCount < $agency_commission_list->StopRecord) {
	$agency_commission_list->RecordCount++;
	if ($agency_commission_list->RecordCount >= $agency_commission_list->StartRecord) {
		$agency_commission_list->RowCount++;

		// Set up key count
		$agency_commission_list->KeyCount = $agency_commission_list->RowIndex;

		// Init row class and style
		$agency_commission->resetAttributes();
		$agency_commission->CssClass = "";
		if ($agency_commission_list->isGridAdd()) {
		} else {
			$agency_commission_list->loadRowValues($agency_commission_list->Recordset); // Load row values
		}
		$agency_commission->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$agency_commission->RowAttrs->merge(["data-rowindex" => $agency_commission_list->RowCount, "id" => "r" . $agency_commission_list->RowCount . "_agency_commission", "data-rowtype" => $agency_commission->RowType]);

		// Render row
		$agency_commission_list->renderRow();

		// Render list options
		$agency_commission_list->renderListOptions();
?>
	<tr <?php echo $agency_commission->rowAttributes() ?>>
<?php

// Render list options (body, left)
$agency_commission_list->ListOptions->render("body", "left", $agency_commission_list->RowCount);
?>
	<?php if ($agency_commission_list->slno->Visible) { // slno ?>
		<td data-name="slno" <?php echo $agency_commission_list->slno->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_slno">
<span<?php echo $agency_commission_list->slno->viewAttributes() ?>><?php echo $agency_commission_list->slno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_commission_list->agent->Visible) { // agent ?>
		<td data-name="agent" <?php echo $agency_commission_list->agent->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_agent">
<span<?php echo $agency_commission_list->agent->viewAttributes() ?>><?php echo $agency_commission_list->agent->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_commission_list->draw_code->Visible) { // draw_code ?>
		<td data-name="draw_code" <?php echo $agency_commission_list->draw_code->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_draw_code">
<span<?php echo $agency_commission_list->draw_code->viewAttributes() ?>><?php echo $agency_commission_list->draw_code->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_commission_list->ticket_name->Visible) { // ticket_name ?>
		<td data-name="ticket_name" <?php echo $agency_commission_list->ticket_name->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_ticket_name">
<span<?php echo $agency_commission_list->ticket_name->viewAttributes() ?>><?php echo $agency_commission_list->ticket_name->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_commission_list->draw_date->Visible) { // draw_date ?>
		<td data-name="draw_date" <?php echo $agency_commission_list->draw_date->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_draw_date">
<span<?php echo $agency_commission_list->draw_date->viewAttributes() ?>><?php echo $agency_commission_list->draw_date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_commission_list->commission->Visible) { // commission ?>
		<td data-name="commission" <?php echo $agency_commission_list->commission->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_commission">
<span<?php echo $agency_commission_list->commission->viewAttributes() ?>><?php echo $agency_commission_list->commission->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_commission_list->add_date->Visible) { // add_date ?>
		<td data-name="add_date" <?php echo $agency_commission_list->add_date->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_add_date">
<span<?php echo $agency_commission_list->add_date->viewAttributes() ?>><?php echo $agency_commission_list->add_date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($agency_commission_list->add_user->Visible) { // add_user ?>
		<td data-name="add_user" <?php echo $agency_commission_list->add_user->cellAttributes() ?>>
<span id="el<?php echo $agency_commission_list->RowCount ?>_agency_commission_add_user">
<span<?php echo $agency_commission_list->add_user->viewAttributes() ?>><?php echo $agency_commission_list->add_user->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$agency_commission_list->ListOptions->render("body", "right", $agency_commission_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$agency_commission_list->isGridAdd())
		$agency_commission_list->Recordset->moveNext();
}
?>
</tbody>
<?php

// Render aggregate row
$agency_commission->RowType = ROWTYPE_AGGREGATE;
$agency_commission->resetAttributes();
$agency_commission_list->renderRow();
?>
<?php if ($agency_commission_list->TotalRecords > 0 && !$agency_commission_list->isGridAdd() && !$agency_commission_list->isGridEdit()) { ?>
<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options
$agency_commission_list->renderListOptions();

// Render list options (footer, left)
$agency_commission_list->ListOptions->render("footer", "left");
?>
	<?php if ($agency_commission_list->slno->Visible) { // slno ?>
		<td data-name="slno" class="<?php echo $agency_commission_list->slno->footerCellClass() ?>"><span id="elf_agency_commission_slno" class="agency_commission_slno">
		<span class="ew-aggregate"><?php echo $Language->phrase("COUNT") ?></span><span class="ew-aggregate-value">
		<?php echo $agency_commission_list->slno->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($agency_commission_list->agent->Visible) { // agent ?>
		<td data-name="agent" class="<?php echo $agency_commission_list->agent->footerCellClass() ?>"><span id="elf_agency_commission_agent" class="agency_commission_agent">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agency_commission_list->draw_code->Visible) { // draw_code ?>
		<td data-name="draw_code" class="<?php echo $agency_commission_list->draw_code->footerCellClass() ?>"><span id="elf_agency_commission_draw_code" class="agency_commission_draw_code">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agency_commission_list->ticket_name->Visible) { // ticket_name ?>
		<td data-name="ticket_name" class="<?php echo $agency_commission_list->ticket_name->footerCellClass() ?>"><span id="elf_agency_commission_ticket_name" class="agency_commission_ticket_name">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agency_commission_list->draw_date->Visible) { // draw_date ?>
		<td data-name="draw_date" class="<?php echo $agency_commission_list->draw_date->footerCellClass() ?>"><span id="elf_agency_commission_draw_date" class="agency_commission_draw_date">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agency_commission_list->commission->Visible) { // commission ?>
		<td data-name="commission" class="<?php echo $agency_commission_list->commission->footerCellClass() ?>"><span id="elf_agency_commission_commission" class="agency_commission_commission">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $agency_commission_list->commission->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($agency_commission_list->add_date->Visible) { // add_date ?>
		<td data-name="add_date" class="<?php echo $agency_commission_list->add_date->footerCellClass() ?>"><span id="elf_agency_commission_add_date" class="agency_commission_add_date">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($agency_commission_list->add_user->Visible) { // add_user ?>
		<td data-name="add_user" class="<?php echo $agency_commission_list->add_user->footerCellClass() ?>"><span id="elf_agency_commission_add_user" class="agency_commission_add_user">
		&nbsp;
		</span></td>
	<?php } ?>
<?php

// Render list options (footer, right)
$agency_commission_list->ListOptions->render("footer", "right");
?>
	</tr>
</tfoot>
<?php } ?>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$agency_commission->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($agency_commission_list->Recordset)
	$agency_commission_list->Recordset->Close();
?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($agency_commission_list->TotalRecords == 0 && !$agency_commission->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $agency_commission_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$agency_commission_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$agency_commission_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$agency_commission_list->terminate();
?>