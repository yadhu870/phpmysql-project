<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agency_commission_edit = new agency_commission_edit();

// Run the page
$agency_commission_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agency_commission_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fagency_commissionedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fagency_commissionedit = currentForm = new ew.Form("fagency_commissionedit", "edit");

	// Validate form
	fagency_commissionedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "F")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($agency_commission_edit->slno->Required) { ?>
				elm = this.getElements("x" + infix + "_slno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->slno->caption(), $agency_commission_edit->slno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agency_commission_edit->agent->Required) { ?>
				elm = this.getElements("x" + infix + "_agent");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->agent->caption(), $agency_commission_edit->agent->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agency_commission_edit->draw_code->Required) { ?>
				elm = this.getElements("x" + infix + "_draw_code");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->draw_code->caption(), $agency_commission_edit->draw_code->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agency_commission_edit->ticket_name->Required) { ?>
				elm = this.getElements("x" + infix + "_ticket_name");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->ticket_name->caption(), $agency_commission_edit->ticket_name->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agency_commission_edit->draw_date->Required) { ?>
				elm = this.getElements("x" + infix + "_draw_date");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->draw_date->caption(), $agency_commission_edit->draw_date->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_draw_date");
				if (elm && !ew.checkEuroDate(elm.value))
					return this.onError(elm, "<?php echo JsEncode($agency_commission_edit->draw_date->errorMessage()) ?>");
			<?php if ($agency_commission_edit->serial_no->Required) { ?>
				elm = this.getElements("x" + infix + "_serial_no");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->serial_no->caption(), $agency_commission_edit->serial_no->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agency_commission_edit->priced_serial->Required) { ?>
				elm = this.getElements("x" + infix + "_priced_serial");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->priced_serial->caption(), $agency_commission_edit->priced_serial->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agency_commission_edit->commission->Required) { ?>
				elm = this.getElements("x" + infix + "_commission");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->commission->caption(), $agency_commission_edit->commission->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_commission");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($agency_commission_edit->commission->errorMessage()) ?>");
			<?php if ($agency_commission_edit->add_date->Required) { ?>
				elm = this.getElements("x" + infix + "_add_date");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->add_date->caption(), $agency_commission_edit->add_date->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($agency_commission_edit->add_user->Required) { ?>
				elm = this.getElements("x" + infix + "_add_user");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $agency_commission_edit->add_user->caption(), $agency_commission_edit->add_user->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fagency_commissionedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fagency_commissionedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fagency_commissionedit.lists["x_agent"] = <?php echo $agency_commission_edit->agent->Lookup->toClientList($agency_commission_edit) ?>;
	fagency_commissionedit.lists["x_agent"].options = <?php echo JsonEncode($agency_commission_edit->agent->lookupOptions()) ?>;
	fagency_commissionedit.lists["x_draw_code"] = <?php echo $agency_commission_edit->draw_code->Lookup->toClientList($agency_commission_edit) ?>;
	fagency_commissionedit.lists["x_draw_code"].options = <?php echo JsonEncode($agency_commission_edit->draw_code->lookupOptions()) ?>;
	fagency_commissionedit.autoSuggests["x_draw_code"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("fagency_commissionedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $agency_commission_edit->showPageHeader(); ?>
<?php
$agency_commission_edit->showMessage();
?>
<form name="fagency_commissionedit" id="fagency_commissionedit" class="<?php echo $agency_commission_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agency_commission">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$agency_commission_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($agency_commission_edit->slno->Visible) { // slno ?>
	<div id="r_slno" class="form-group row">
		<label id="elh_agency_commission_slno" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->slno->caption() ?><?php echo $agency_commission_edit->slno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->slno->cellAttributes() ?>>
<span id="el_agency_commission_slno">
<span<?php echo $agency_commission_edit->slno->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($agency_commission_edit->slno->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="agency_commission" data-field="x_slno" name="x_slno" id="x_slno" value="<?php echo HtmlEncode($agency_commission_edit->slno->CurrentValue) ?>">
<?php echo $agency_commission_edit->slno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agency_commission_edit->agent->Visible) { // agent ?>
	<div id="r_agent" class="form-group row">
		<label id="elh_agency_commission_agent" for="x_agent" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->agent->caption() ?><?php echo $agency_commission_edit->agent->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->agent->cellAttributes() ?>>
<span id="el_agency_commission_agent">
<?php $agency_commission_edit->agent->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="agency_commission" data-field="x_agent" data-value-separator="<?php echo $agency_commission_edit->agent->displayValueSeparatorAttribute() ?>" id="x_agent" name="x_agent"<?php echo $agency_commission_edit->agent->editAttributes() ?>>
			<?php echo $agency_commission_edit->agent->selectOptionListHtml("x_agent") ?>
		</select>
</div>
<?php echo $agency_commission_edit->agent->Lookup->getParamTag($agency_commission_edit, "p_x_agent") ?>
</span>
<?php echo $agency_commission_edit->agent->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agency_commission_edit->draw_code->Visible) { // draw_code ?>
	<div id="r_draw_code" class="form-group row">
		<label id="elh_agency_commission_draw_code" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->draw_code->caption() ?><?php echo $agency_commission_edit->draw_code->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->draw_code->cellAttributes() ?>>
<span id="el_agency_commission_draw_code">
<?php
$onchange = $agency_commission_edit->draw_code->EditAttrs->prepend("onchange", "ew.autoFill(this);");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$agency_commission_edit->draw_code->EditAttrs["onchange"] = "";
?>
<span id="as_x_draw_code">
	<input type="text" class="form-control" name="sv_x_draw_code" id="sv_x_draw_code" value="<?php echo RemoveHtml($agency_commission_edit->draw_code->EditValue) ?>" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agency_commission_edit->draw_code->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($agency_commission_edit->draw_code->getPlaceHolder()) ?>"<?php echo $agency_commission_edit->draw_code->editAttributes() ?>>
</span>
<input type="hidden" data-table="agency_commission" data-field="x_draw_code" data-value-separator="<?php echo $agency_commission_edit->draw_code->displayValueSeparatorAttribute() ?>" name="x_draw_code" id="x_draw_code" value="<?php echo HtmlEncode($agency_commission_edit->draw_code->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fagency_commissionedit"], function() {
	fagency_commissionedit.createAutoSuggest({"id":"x_draw_code","forceSelect":true});
});
</script>
<?php echo $agency_commission_edit->draw_code->Lookup->getParamTag($agency_commission_edit, "p_x_draw_code") ?>
</span>
<?php echo $agency_commission_edit->draw_code->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agency_commission_edit->ticket_name->Visible) { // ticket_name ?>
	<div id="r_ticket_name" class="form-group row">
		<label id="elh_agency_commission_ticket_name" for="x_ticket_name" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->ticket_name->caption() ?><?php echo $agency_commission_edit->ticket_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->ticket_name->cellAttributes() ?>>
<span id="el_agency_commission_ticket_name">
<input type="text" data-table="agency_commission" readonly="x_ticket_name" data-field="x_ticket_name" name="x_ticket_name" id="x_ticket_name" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($agency_commission_edit->ticket_name->getPlaceHolder()) ?>" value="<?php echo $agency_commission_edit->ticket_name->EditValue ?>"<?php echo $agency_commission_edit->ticket_name->editAttributes() ?>>
</span>
<?php echo $agency_commission_edit->ticket_name->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agency_commission_edit->draw_date->Visible) { // draw_date ?>
	<div id="r_draw_date" class="form-group row">
		<label id="elh_agency_commission_draw_date" for="x_draw_date" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->draw_date->caption() ?><?php echo $agency_commission_edit->draw_date->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->draw_date->cellAttributes() ?>>
<span id="el_agency_commission_draw_date">
<input type="text" data-table="agency_commission" readonly="x_draw_date" data-field="x_draw_date" data-format="7" name="x_draw_date" id="x_draw_date" maxlength="10" placeholder="<?php echo HtmlEncode($agency_commission_edit->draw_date->getPlaceHolder()) ?>" value="<?php echo $agency_commission_edit->draw_date->EditValue ?>"<?php echo $agency_commission_edit->draw_date->editAttributes() ?>>
</span>
<?php echo $agency_commission_edit->draw_date->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agency_commission_edit->serial_no->Visible) { // serial_no ?>
	<div id="r_serial_no" class="form-group row">
		<label id="elh_agency_commission_serial_no" for="x_serial_no" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->serial_no->caption() ?><?php echo $agency_commission_edit->serial_no->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->serial_no->cellAttributes() ?>>
<span id="el_agency_commission_serial_no">
<textarea data-table="agency_commission" data-field="x_serial_no" readonly="x_serial_no" name="x_serial_no" id="x_serial_no" cols="35" rows="4" placeholder="<?php echo HtmlEncode($agency_commission_edit->serial_no->getPlaceHolder()) ?>"<?php echo $agency_commission_edit->serial_no->editAttributes() ?>><?php echo $agency_commission_edit->serial_no->EditValue ?></textarea>
</span>
<?php echo $agency_commission_edit->serial_no->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agency_commission_edit->priced_serial->Visible) { // priced_serial ?>
	<div id="r_priced_serial" class="form-group row">
		<label id="elh_agency_commission_priced_serial" for="x_priced_serial" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->priced_serial->caption() ?><?php echo $agency_commission_edit->priced_serial->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->priced_serial->cellAttributes() ?>>
<span id="el_agency_commission_priced_serial">
<textarea data-table="agency_commission" data-field="x_priced_serial" name="x_priced_serial" id="x_priced_serial" cols="35" rows="4" placeholder="<?php echo HtmlEncode($agency_commission_edit->priced_serial->getPlaceHolder()) ?>"<?php echo $agency_commission_edit->priced_serial->editAttributes() ?>><?php echo $agency_commission_edit->priced_serial->EditValue ?></textarea>
</span>
<?php echo $agency_commission_edit->priced_serial->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($agency_commission_edit->commission->Visible) { // commission ?>
	<div id="r_commission" class="form-group row">
		<label id="elh_agency_commission_commission" for="x_commission" class="<?php echo $agency_commission_edit->LeftColumnClass ?>"><?php echo $agency_commission_edit->commission->caption() ?><?php echo $agency_commission_edit->commission->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $agency_commission_edit->RightColumnClass ?>"><div <?php echo $agency_commission_edit->commission->cellAttributes() ?>>
<span id="el_agency_commission_commission">
<input type="text" data-table="agency_commission" data-field="x_commission" name="x_commission" id="x_commission" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($agency_commission_edit->commission->getPlaceHolder()) ?>" value="<?php echo $agency_commission_edit->commission->EditValue ?>"<?php echo $agency_commission_edit->commission->editAttributes() ?>>
</span>
<?php echo $agency_commission_edit->commission->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$agency_commission_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $agency_commission_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $agency_commission_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$agency_commission_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$agency_commission_edit->terminate();
?>