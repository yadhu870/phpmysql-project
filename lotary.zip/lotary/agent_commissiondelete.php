<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agent_commission_delete = new agent_commission_delete();

// Run the page
$agent_commission_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agent_commission_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fagent_commissiondelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fagent_commissiondelete = currentForm = new ew.Form("fagent_commissiondelete", "delete");
	loadjs.done("fagent_commissiondelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $agent_commission_delete->showPageHeader(); ?>
<?php
$agent_commission_delete->showMessage();
?>
<form name="fagent_commissiondelete" id="fagent_commissiondelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agent_commission">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($agent_commission_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($agent_commission_delete->slno->Visible) { // slno ?>
		<th class="<?php echo $agent_commission_delete->slno->headerCellClass() ?>"><span id="elh_agent_commission_slno" class="agent_commission_slno"><?php echo $agent_commission_delete->slno->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->date->Visible) { // date ?>
		<th class="<?php echo $agent_commission_delete->date->headerCellClass() ?>"><span id="elh_agent_commission_date" class="agent_commission_date"><?php echo $agent_commission_delete->date->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->time->Visible) { // time ?>
		<th class="<?php echo $agent_commission_delete->time->headerCellClass() ?>"><span id="elh_agent_commission_time" class="agent_commission_time"><?php echo $agent_commission_delete->time->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->dc_number->Visible) { // dc_number ?>
		<th class="<?php echo $agent_commission_delete->dc_number->headerCellClass() ?>"><span id="elh_agent_commission_dc_number" class="agent_commission_dc_number"><?php echo $agent_commission_delete->dc_number->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->customer_name->Visible) { // customer_name ?>
		<th class="<?php echo $agent_commission_delete->customer_name->headerCellClass() ?>"><span id="elh_agent_commission_customer_name" class="agent_commission_customer_name"><?php echo $agent_commission_delete->customer_name->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->ticket_name->Visible) { // ticket_name ?>
		<th class="<?php echo $agent_commission_delete->ticket_name->headerCellClass() ?>"><span id="elh_agent_commission_ticket_name" class="agent_commission_ticket_name"><?php echo $agent_commission_delete->ticket_name->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->draw_date->Visible) { // draw_date ?>
		<th class="<?php echo $agent_commission_delete->draw_date->headerCellClass() ?>"><span id="elh_agent_commission_draw_date" class="agent_commission_draw_date"><?php echo $agent_commission_delete->draw_date->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->ticket_catagory->Visible) { // ticket_catagory ?>
		<th class="<?php echo $agent_commission_delete->ticket_catagory->headerCellClass() ?>"><span id="elh_agent_commission_ticket_catagory" class="agent_commission_ticket_catagory"><?php echo $agent_commission_delete->ticket_catagory->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->dc_type->Visible) { // dc_type ?>
		<th class="<?php echo $agent_commission_delete->dc_type->headerCellClass() ?>"><span id="elh_agent_commission_dc_type" class="agent_commission_dc_type"><?php echo $agent_commission_delete->dc_type->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->commission_amount->Visible) { // commission_amount ?>
		<th class="<?php echo $agent_commission_delete->commission_amount->headerCellClass() ?>"><span id="elh_agent_commission_commission_amount" class="agent_commission_commission_amount"><?php echo $agent_commission_delete->commission_amount->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->agency_dc->Visible) { // agency_dc ?>
		<th class="<?php echo $agent_commission_delete->agency_dc->headerCellClass() ?>"><span id="elh_agent_commission_agency_dc" class="agent_commission_agency_dc"><?php echo $agent_commission_delete->agency_dc->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->total_dc->Visible) { // total_dc ?>
		<th class="<?php echo $agent_commission_delete->total_dc->headerCellClass() ?>"><span id="elh_agent_commission_total_dc" class="agent_commission_total_dc"><?php echo $agent_commission_delete->total_dc->caption() ?></span></th>
<?php } ?>
<?php if ($agent_commission_delete->add_user->Visible) { // add_user ?>
		<th class="<?php echo $agent_commission_delete->add_user->headerCellClass() ?>"><span id="elh_agent_commission_add_user" class="agent_commission_add_user"><?php echo $agent_commission_delete->add_user->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$agent_commission_delete->RecordCount = 0;
$i = 0;
while (!$agent_commission_delete->Recordset->EOF) {
	$agent_commission_delete->RecordCount++;
	$agent_commission_delete->RowCount++;

	// Set row properties
	$agent_commission->resetAttributes();
	$agent_commission->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$agent_commission_delete->loadRowValues($agent_commission_delete->Recordset);

	// Render row
	$agent_commission_delete->renderRow();
?>
	<tr <?php echo $agent_commission->rowAttributes() ?>>
<?php if ($agent_commission_delete->slno->Visible) { // slno ?>
		<td <?php echo $agent_commission_delete->slno->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_slno" class="agent_commission_slno">
<span<?php echo $agent_commission_delete->slno->viewAttributes() ?>><?php echo $agent_commission_delete->slno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->date->Visible) { // date ?>
		<td <?php echo $agent_commission_delete->date->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_date" class="agent_commission_date">
<span<?php echo $agent_commission_delete->date->viewAttributes() ?>><?php echo $agent_commission_delete->date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->time->Visible) { // time ?>
		<td <?php echo $agent_commission_delete->time->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_time" class="agent_commission_time">
<span<?php echo $agent_commission_delete->time->viewAttributes() ?>><?php echo $agent_commission_delete->time->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->dc_number->Visible) { // dc_number ?>
		<td <?php echo $agent_commission_delete->dc_number->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_dc_number" class="agent_commission_dc_number">
<span<?php echo $agent_commission_delete->dc_number->viewAttributes() ?>><?php echo $agent_commission_delete->dc_number->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->customer_name->Visible) { // customer_name ?>
		<td <?php echo $agent_commission_delete->customer_name->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_customer_name" class="agent_commission_customer_name">
<span<?php echo $agent_commission_delete->customer_name->viewAttributes() ?>><?php echo $agent_commission_delete->customer_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->ticket_name->Visible) { // ticket_name ?>
		<td <?php echo $agent_commission_delete->ticket_name->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_ticket_name" class="agent_commission_ticket_name">
<span<?php echo $agent_commission_delete->ticket_name->viewAttributes() ?>><?php echo $agent_commission_delete->ticket_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->draw_date->Visible) { // draw_date ?>
		<td <?php echo $agent_commission_delete->draw_date->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_draw_date" class="agent_commission_draw_date">
<span<?php echo $agent_commission_delete->draw_date->viewAttributes() ?>><?php echo $agent_commission_delete->draw_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->ticket_catagory->Visible) { // ticket_catagory ?>
		<td <?php echo $agent_commission_delete->ticket_catagory->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_ticket_catagory" class="agent_commission_ticket_catagory">
<span<?php echo $agent_commission_delete->ticket_catagory->viewAttributes() ?>><?php echo $agent_commission_delete->ticket_catagory->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->dc_type->Visible) { // dc_type ?>
		<td <?php echo $agent_commission_delete->dc_type->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_dc_type" class="agent_commission_dc_type">
<span<?php echo $agent_commission_delete->dc_type->viewAttributes() ?>><?php echo $agent_commission_delete->dc_type->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->commission_amount->Visible) { // commission_amount ?>
		<td <?php echo $agent_commission_delete->commission_amount->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_commission_amount" class="agent_commission_commission_amount">
<span<?php echo $agent_commission_delete->commission_amount->viewAttributes() ?>><?php echo $agent_commission_delete->commission_amount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->agency_dc->Visible) { // agency_dc ?>
		<td <?php echo $agent_commission_delete->agency_dc->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_agency_dc" class="agent_commission_agency_dc">
<span<?php echo $agent_commission_delete->agency_dc->viewAttributes() ?>><?php echo $agent_commission_delete->agency_dc->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->total_dc->Visible) { // total_dc ?>
		<td <?php echo $agent_commission_delete->total_dc->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_total_dc" class="agent_commission_total_dc">
<span<?php echo $agent_commission_delete->total_dc->viewAttributes() ?>><?php echo $agent_commission_delete->total_dc->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agent_commission_delete->add_user->Visible) { // add_user ?>
		<td <?php echo $agent_commission_delete->add_user->cellAttributes() ?>>
<span id="el<?php echo $agent_commission_delete->RowCount ?>_agent_commission_add_user" class="agent_commission_add_user">
<span<?php echo $agent_commission_delete->add_user->viewAttributes() ?>><?php echo $agent_commission_delete->add_user->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$agent_commission_delete->Recordset->moveNext();
}
$agent_commission_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $agent_commission_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$agent_commission_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$agent_commission_delete->terminate();
?>