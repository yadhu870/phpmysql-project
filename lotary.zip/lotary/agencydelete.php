<?php
namespace PHPMaker2020\project5;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$agency_delete = new agency_delete();

// Run the page
$agency_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$agency_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fagencydelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fagencydelete = currentForm = new ew.Form("fagencydelete", "delete");
	loadjs.done("fagencydelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $agency_delete->showPageHeader(); ?>
<?php
$agency_delete->showMessage();
?>
<form name="fagencydelete" id="fagencydelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="agency">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($agency_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($agency_delete->slno->Visible) { // slno ?>
		<th class="<?php echo $agency_delete->slno->headerCellClass() ?>"><span id="elh_agency_slno" class="agency_slno"><?php echo $agency_delete->slno->caption() ?></span></th>
<?php } ?>
<?php if ($agency_delete->agency_name->Visible) { // agency_name ?>
		<th class="<?php echo $agency_delete->agency_name->headerCellClass() ?>"><span id="elh_agency_agency_name" class="agency_agency_name"><?php echo $agency_delete->agency_name->caption() ?></span></th>
<?php } ?>
<?php if ($agency_delete->agency_number->Visible) { // agency_number ?>
		<th class="<?php echo $agency_delete->agency_number->headerCellClass() ?>"><span id="elh_agency_agency_number" class="agency_agency_number"><?php echo $agency_delete->agency_number->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$agency_delete->RecordCount = 0;
$i = 0;
while (!$agency_delete->Recordset->EOF) {
	$agency_delete->RecordCount++;
	$agency_delete->RowCount++;

	// Set row properties
	$agency->resetAttributes();
	$agency->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$agency_delete->loadRowValues($agency_delete->Recordset);

	// Render row
	$agency_delete->renderRow();
?>
	<tr <?php echo $agency->rowAttributes() ?>>
<?php if ($agency_delete->slno->Visible) { // slno ?>
		<td <?php echo $agency_delete->slno->cellAttributes() ?>>
<span id="el<?php echo $agency_delete->RowCount ?>_agency_slno" class="agency_slno">
<span<?php echo $agency_delete->slno->viewAttributes() ?>><?php echo $agency_delete->slno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_delete->agency_name->Visible) { // agency_name ?>
		<td <?php echo $agency_delete->agency_name->cellAttributes() ?>>
<span id="el<?php echo $agency_delete->RowCount ?>_agency_agency_name" class="agency_agency_name">
<span<?php echo $agency_delete->agency_name->viewAttributes() ?>><?php echo $agency_delete->agency_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($agency_delete->agency_number->Visible) { // agency_number ?>
		<td <?php echo $agency_delete->agency_number->cellAttributes() ?>>
<span id="el<?php echo $agency_delete->RowCount ?>_agency_agency_number" class="agency_agency_number">
<span<?php echo $agency_delete->agency_number->viewAttributes() ?>><?php echo $agency_delete->agency_number->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$agency_delete->Recordset->moveNext();
}
$agency_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $agency_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$agency_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$agency_delete->terminate();
?>